#!/usr/bin/env bash
# Reproduces the viva demonstration end to end. Run from the project root:
#   bash scripts/demo.sh
set -u
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
PY="${PYTHON:-python3}"
step() { printf '\n==================== %s ====================\n' "$1"; }

step "1. Static check of the NOC-order pipeline (expect ADJ001)"
$PY -m adjcheck check examples/unsafe.adj

step "2. Safe rewrite, then re-check the rewritten script"
$PY -m adjcheck fix examples/unsafe.adj -o outputs/unsafe_fixed.adj
$PY -m adjcheck check outputs/unsafe_fixed.adj

step "3. Run the corrected pipeline (n-grams + provenance certificates)"
$PY -m adjcheck run outputs/unsafe_fixed.adj --certs outputs/fixed_certificates.json

step "4. Independent verification of those certificates"
$PY -m adjcheck verify outputs/fixed_certificates.json --source data/sample.txt

step "5. Same safe script, deliberately faulty executor (ignore-gaps)"
$PY -m adjcheck check examples/safe.adj
$PY -m adjcheck run examples/safe.adj --fault ignore-gaps --certs outputs/faulty_certificates.json
$PY -m adjcheck verify outputs/faulty_certificates.json --source data/sample.txt --show 6

step "6. Unsafe pipeline forced to run, and lost provenance"
$PY -m adjcheck run examples/unsafe.adj --allow-unsafe --certs outputs/unsafe_certificates.json
$PY -m adjcheck verify outputs/unsafe_certificates.json --source data/sample.txt --show 5
$PY -m adjcheck run examples/untracked.adj --certs outputs/untracked_certificates.json
$PY -m adjcheck verify outputs/untracked_certificates.json --source data/sample.txt --show 3

step "7. Measured fault matrix and policy experiment"
$PY -m adjcheck faults --out outputs/fault_matrix.md | tail -6
$PY -m adjcheck experiment --out outputs/experiment.md | sed -n '5,12p'
echo
echo "Full results: outputs/fault_matrix.md, outputs/experiment.md"
