# AdjCheck

**Static Adjacency Analysis and Certified N-gram Provenance for Text-Mining Pipelines**

AdjCheck is a small compiler for a text-pipeline language (`.adj`). It answers one question
twice:

> Can this pipeline report an n-gram whose words were never next to each other in the source?

- **AdjCheck (static analysis)** answers *before* running, for every possible input, by
  data-flow analysis over the compiled pipeline. Example: removing stop words and then
  forming bigrams turns "the **use** of the **term**" into *use term*.
- **PhraseProof (independent checker)** answers *after* running, for the actual output:
  every n-gram occurrence carries a provenance certificate (document hash + character
  spans + views), which a separate checker verifies against the original text under a
  declared phrase policy.

The project builds on the N-Gram Over Context (NOC) reference: the reference's documented
module order (stop-word removal, then n-gram identification, then LDA) is the motivating
example in `examples/unsafe.adj`. The reference *code* was not available, so no claim is
made about what that implementation actually outputs. No novelty claim is made either;
the parts (static analysis, provenance, certifying checks) are established techniques.

## Setup

Requires Python 3.11+. The runtime uses only the standard library; tests need pytest.

```bash
cd adjcheck
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -e ".[test]"
```

Without installing: `export PYTHONPATH=src` (Windows: `set PYTHONPATH=src`) and use
`python -m adjcheck ...`. Run all commands from the project root; paths in scripts are
relative to it.

## Web interface

A local browser interface runs the **same** compiler, executor and PhraseProof verifier as
the command line on text you type, paste or upload. Nothing is mocked: every diagnostic,
stream state, verdict and count on the page comes from those components.

### Install and start (Windows PowerShell, in VS Code)

Open the `adjcheck` folder in VS Code, open a terminal (**Terminal → New Terminal**,
PowerShell), then:

```powershell
py -3.11 -m venv .venv                       # or: python -m venv .venv
.\.venv\Scripts\Activate.ps1                  # if blocked: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
python -m pip install --upgrade pip
python -m pip install -e ".[test,web]"
python -m pytest                              # 212 tests
adjcheck-web                                  # or: python -m adjcheck.webapp
```

Open <http://127.0.0.1:5000>. Stop the server with **Ctrl+C**. Another port:
`adjcheck-web --port 8080`. In VS Code, choose the interpreter
`.venv\Scripts\python.exe` (**Ctrl+Shift+P → Python: Select Interpreter**) so the Testing
panel and Run button use the same environment.

macOS/Linux: `python3 -m venv .venv && source .venv/bin/activate`, then the same
`pip install` and `adjcheck-web`.

Flask is the only new dependency, and it is optional (`[web]` extra). Without it, the
command line and the core test suite work as before; the web tests are skipped.

### Using it

1. **Your text.** Type, paste, or upload a UTF-8 `.txt` file. Blank lines separate
   documents. Limits: 50,000 characters; uploads up to 200 KB.
2. **Pipeline.** Pick an example (gap-aware, NOC order, connector-aware, branches and
   merge, lost provenance) and edit the script if you like. `load("input.txt")` always
   means the text in the box.
3. **Run analysis.** The page shows:
   - **Static check:** real diagnostics (ADJ001, ADJ002, syntax and semantic errors) with
     line and column, the state of every stream (SAFE, MARKED, BROKEN, UNTRACKED), and —
     for hazards — the safe rewrite produced by `adjcheck fix`, which you can load with one
     click.
   - **Occurrences:** every n-gram occurrence with PhraseProof's verdict and the check that
     failed. Search and filter by status. Selecting one shows the exact source text with
     the phrase words marked and any text between them struck through.
   - **Phrases:** reported count per phrase next to accepted, rejected and uncertified
     occurrences.
   - **Documents:** your text exactly as the pipeline read it (NFC, split at blank lines),
     with SHA-256 hashes.
   - **Topics:** output of a `topics(...)` sink, labelled as not evaluated.
   - **Downloads:** each sink's CSV, `certificates.json`, `verification-report.json`,
     `occurrence-verdicts.csv`, the script and the input text.

If the static check reports an error, the pipeline is not run unless you tick **Run even
if the static check fails** (the same rule as `adjcheck run --allow-unsafe`). The NOC-order
and branches examples tick it for you, so you can see what PhraseProof rejects.

The downloaded certificates can be re-verified on the command line:
`python -m adjcheck verify certificates.json --source input.txt`.

### How the web layer is built

```
browser (static/app.js)  ──JSON──►  Flask routes (web/__init__.py)
                                         │
                                  web/service.py: validate input, sandbox, limits
                                         │
            compile_source ─► rewrite (suggested fix) ─► Executor ─► verify (PhraseProof)
                         (unchanged project modules; validator still imports only contract.py)
```

| Route | Purpose |
| --- | --- |
| `GET /` | the page |
| `GET /api/examples` | example scripts (actual DSL) and sample text |
| `POST /api/analyze` | `{text, script, allow_unsafe}` → full result |
| `POST /api/upload` | multipart `.txt` → validated text |
| `POST /api/fix` | `{script}` → safe-rewrite suggestion |

Safety measures:
- Each run gets a fresh temporary folder that is deleted afterwards. The project's `data/`
  and `outputs/` folders are never read or written by the web interface.
- `load(...)` must read `"input.txt"` (WEB001), which is bound to your text.
- Every sink's output path is replaced by a file inside the temporary folder.
- The DSL has no eval, imports or shell access.
- Limits: text 50,000 characters, script 4,000, request 512 KB, at most 6 sinks, and
  `topics` k ≤ 10, iterations ≤ 300, top ≤ 20 (WEB002, WEB003).
- Uploads must be `.txt`, valid UTF-8, and contain no NUL bytes.
- The server keeps no results between requests; downloads are built in your browser.
- The page sets a strict Content-Security-Policy, and user text is never inserted as HTML.
- It binds to 127.0.0.1 by default. It uses Flask's development server and has no
  authentication, so do not expose it to the internet.

## Commands

```bash
python -m adjcheck parse  examples/unsafe.adj            # AST (add --tokens for the token stream)
python -m adjcheck check  examples/unsafe.adj            # diagnostics + per-stream states; exit 1 on errors
python -m adjcheck fix    examples/unsafe.adj -o outputs/fixed.adj   # keep_gaps rewrite, re-checked
python -m adjcheck run    examples/safe.adj              # writes CSVs + outputs/safe_certificates.json
python -m adjcheck verify outputs/safe_certificates.json --source data/sample.txt
python -m adjcheck faults                                # fault-injection matrix -> outputs/fault_matrix.md
python -m adjcheck experiment                            # policy experiment -> outputs/experiment.md
python -m pytest                                         # test suite
bash scripts/demo.sh                                     # the full viva demonstration
```

`run` refuses scripts with static errors unless `--allow-unsafe` is given. `run --fault NAME`
enables one deliberate executor fault (testing only; see `executor.FAULTS`). Faulty runs
write to the same sink paths as normal runs.

## The language

```text
policy strict;                                   # or: policy connectors(of, the);
let raw   = load("data/sample.txt");
let toks  = raw | tokenize | lower;
let clean = toks | remove(stopwords, keep_gaps);
let grams = clean | ngrams(1, 2);
topics(grams, k = 5) -> "outputs/safe_topics.csv";
phrases(grams) -> "outputs/safe_phrases.csv";
```

Operations: `load`, `tokenize`, `lower`, `stem`, `remove(stopwords|numbers|"w1 w2"[, keep_gaps])`,
`expand_contractions`, `merge(a, b)`, `ngrams(min[, max])`. Sinks: `topics(g, k = N)`,
`phrases(g)`, `features(g)`. Grammar, types, lattice and certificate schema are in
[`docs/DESIGN.md`](docs/DESIGN.md).

Examples: `unsafe.adj` (NOC order), `safe.adj` (gap-aware, strict), `connectors.adj`
(*denial of service* kept as a real phrase), `branches.adj` (branches, merge, feature-only
severity), `untracked.adj` (lost provenance).

## Architecture

```
 .adj script ─► lexer ─► parser ─► AST ─► semantic checks + lowering ─► stream IR (DAG)
                                                                            │
                                     data-flow analysis (SAFE ⊑ MARKED ⊑ BROKEN ⊑ UNTRACKED)
                                         │                      │
                              diagnostics / keep_gaps rewrite   executor (offset-carrying tokens)
                                                                 │
                                       CSV outputs  +  certificates (one per occurrence)
                                                                 │
                    source documents ─────────────►  PhraseProof checker (imports contract.py only)
                                                                 │
                                         ACCEPTED / REJECTED / UNCERTIFIED + count checks
```

```
src/adjcheck/
  lexer.py  parser.py  ast_nodes.py     front end
  ir.py                                  semantic analysis, symbol table, IR lowering
  analysis.py                            lattice, transfer functions, ADJ001/ADJ002
  rewrite.py                             keep_gaps rewrite + re-check
  compiler.py  diagnostics.py            driver, error codes
  contract.py                            trusted base shared by executor and checker
  executor.py  lda.py  provenance.py     execution, topic model, certificates
  validator.py                           PhraseProof (independent)
  evaluation/faults.py, experiment.py    measured evaluation
  cli.py  __main__.py
  web/                                   optional Flask interface (service.py, templates/, static/)
  webapp.py                              entry point for adjcheck-web
tests/        212 automated tests (55 for the web interface)
examples/     .adj scripts
data/         sample.txt (12 documents), no_gaps.txt (3 documents)
docs/         DESIGN.md
scripts/      demo.sh
```

## Measured results (summary)

From `python -m adjcheck faults` (full table in `docs/DESIGN.md`):

- **Both detect:** NOC-order pipeline, lost provenance, certifying untracked tokens.
- **Only AdjCheck:** NOC order on a corpus where it happens to fabricate nothing; one
  documented static false positive (`remove("zzzz")`).
- **Only PhraseProof:** executor ignoring gap markers, forgotten sentence boundaries,
  offsets computed on casefolded text, shifted offsets, duplicate certificate, inflated
  count, stale document hash, double counting through `merge`.
- **Neither:** silently dropped n-grams (completeness is out of scope).

From `python -m adjcheck experiment`: the NOC-order pipeline produced 173 occurrences, of
which PhraseProof rejected 28; the gap-aware and connector pipelines produced 0 rejections.
Corpus-level string matching accepted 2 fabricated occurrences, document-level 1,
PhraseProof 0 (on a hand-built corpus designed to contain such cases).

## Limitations

- One corpus file per script; documents are split at blank lines.
- `stem` is a small suffix stripper, not a lemmatiser; no spaCy/NLTK dependency.
- The static analysis does not know corpus contents (false positives possible) and trusts
  operator semantics (cannot see executor bugs).
- The checker validates the certificates it is given; it cannot detect missing output.
- `merge` concatenates per document; merging branches of the same corpus repeats phrases.
- The Python-code detector from earlier proposals is **not implemented** (future work).
- LDA is a small Gibbs sampler for demonstration; topic quality was not evaluated.
- Results come from a small hand-written corpus and illustrate behaviour, not real-world rates.
- Web interface: a local single-user tool on Flask's development server, with no
  authentication or rate limiting. Requests run synchronously; the limits keep a run to a
  few seconds. `run --fault` (fault injection) is deliberately not exposed on the web.
- Web interface: the browser shows at most 600 table rows at a time (search to narrow);
  all rows are in the downloads.

## Viva notes: each compiler component in two sentences

- **Lexer:** a hand-written scanner that groups characters into tokens using maximal munch
  and records line, column and offset for every token. Errors: LEX001/LEX002.
- **Parser:** recursive descent with one method per EBNF rule; it builds the AST and stops
  at the first syntax error with the expected token (SYN001).
- **AST:** dataclasses mirroring the grammar; `Call` keeps the offset of its `)` so the
  rewrite pass can patch the source exactly.
- **Semantic analysis:** a symbol table maps `let` names to IR nodes; it reports undefined
  and redefined streams, unknown operations, wrong arity/values and TEXT/TOKENS/GRAMS type
  mismatches.
- **IR:** a DAG of operations; definition-before-use makes creation order a topological
  order, which is why the analysis needs only one pass.
- **Data-flow analysis:** a forward may-analysis over a four-state chain lattice with join =
  max and monotone transfer functions; ngrams over BROKEN raises ADJ001 with severity chosen
  by the consuming sink.
- **Rewrite pass:** a source-to-source transformation that adds `keep_gaps` only where the
  path is supported, then re-compiles and re-checks; anything else is REW001.
- **Executor:** an interpreter over the IR whose tokens are spans of the original text with
  views; it enforces gaps and emits one certificate per occurrence.
- **PhraseProof:** a certificate checker that shares only `contract.py` with the executor; it
  re-reads the source and accepts, rejects (with the failed check) or marks uncertified.
- **Why both:** the analysis covers all inputs but may over-warn and trusts the executor;
  the checker is exact for one run but cannot see hazards that did not fire or output that
  is missing. The fault matrix measures this split.
