# AdjCheck — Design Document

AdjCheck has two halves that check the same property from opposite directions:

- **AdjCheck (static)** analyses a `.adj` pipeline *before* it runs and says whether an
  n-gram stage *may* join words that were not adjacent in the source.
- **PhraseProof (dynamic)** checks a run's *output*: every n-gram occurrence carries a
  where-provenance certificate, and an independent checker verifies it against the
  original text under a declared phrase policy.

Terminology used here, and the reason for it: PhraseProof makes the n-gram stage a
**certifying computation** (outputs come with witnesses that a simple checker verifies),
based on **where-provenance** (the source locations each output was copied from). It is
*not* translation validation, which checks a compiled program against its source program;
PhraseProof checks output data against input data.

---

## 1. Relationship to the NOC reference

The faculty's NOC document describes, in order: stop-word removal, n-gram token
identification, probability (relative frequency) calculation, and LDA. Its sample output
lists pairs such as *use term* and *devices such*. AdjCheck uses that **documented module
order** as the motivating example (`examples/unsafe.adj`). The reference *code* was not
available, so this project does **not** claim the reference implementation has the defect;
it shows that the documented order permits it.

## 2. Front end

| Phase | File | Technique |
| --- | --- | --- |
| Lexer | `lexer.py` | Hand-coded scanner (DFA), maximal munch, line/column/offset on every token |
| Parser | `parser.py` | Recursive descent, one method per grammar rule, first error stops (SYN001) |
| AST | `ast_nodes.py` | Dataclasses; `Call.rparen_offset` kept for source patching |
| Semantic analysis + lowering | `ir.py` | Symbol table (`env`), types TEXT/TOKENS/GRAMS, arity/value checks, IR construction |
| Data-flow analysis | `analysis.py` | Four-state lattice, monotone transfer functions, one topological pass |
| Rewrite | `rewrite.py` | Source patch `remove(x)` → `remove(x, keep_gaps)` + mandatory re-check |
| Driver | `compiler.py` | source → tokens → AST → IR → analysis |

### Grammar (EBNF)

```
program     = { stmt } EOF ;
stmt        = let_stmt | policy_stmt | sink_stmt ;
let_stmt    = "let" IDENT "=" pipe ";" ;
policy_stmt = "policy" IDENT [ "(" [ IDENT { "," IDENT } ] ")" ] ";" ;
sink_stmt   = IDENT "(" [ args ] ")" [ "->" STRING ] ";" ;
pipe        = primary { "|" op } ;
primary     = IDENT [ "(" [ args ] ")" ] ;     (* load(...), merge(a, b) or a stream name *)
op          = IDENT [ "(" [ args ] ")" ] ;
args        = arg { "," arg } ;
arg         = IDENT "=" value | value ;
value       = INT | FLOAT | STRING | IDENT ;
```

Comments start with `#`. This is the grammar the parser implements (`parser.GRAMMAR`).

### Operations and types

| Construct | Input → output | Arguments |
| --- | --- | --- |
| `load("path")` | — → TEXT | one string |
| `tokenize` | TEXT → TOKENS | none |
| `lower`, `stem` | TOKENS → TOKENS | none |
| `remove(set[, keep_gaps])` | TOKENS → TOKENS | `stopwords`, `numbers`, or `"w1 w2 ..."` |
| `expand_contractions` | TOKENS → TOKENS | none |
| `merge(a, b)` | TOKENS × TOKENS → TOKENS | two stream names |
| `ngrams(min[, max])` | TOKENS → GRAMS | 1 ≤ min ≤ max ≤ 6 |
| `topics(g, k = N[, iterations, seed, top])` | GRAMS → CSV | phrase-like sink |
| `phrases(g)` | GRAMS → CSV | phrase-like sink |
| `features(g)` | GRAMS → CSV | feature-only sink |
| `policy strict;` / `policy connectors(w, ...);` | — | at most once |

### Diagnostic codes

| Code | Meaning |
| --- | --- |
| LEX001, LEX002 | invalid character; unterminated string |
| SYN001 | unexpected token (with expected token in the message) |
| SEM001–SEM009 | undefined / redefined stream; unknown op or sink; wrong arity; type mismatch; bad value; unused stream (warning); duplicate policy; no sink (warning) |
| ADJ001 | n-grams over a stream whose adjacency may be broken (severity by sink) |
| ADJ002 | n-grams over a stream with untracked provenance (warning) |
| REW001 | hazard cannot be rewritten automatically |

## 3. Data-flow analysis

### Lattice

A four-element chain; join is `max`:

```
SAFE  ⊑  MARKED  ⊑  BROKEN  ⊑  UNTRACKED
```

| State | Meaning |
| --- | --- |
| SAFE | no word tokens removed; `tokenize` records punctuation and blank-line boundaries |
| MARKED | words were removed and every removal left a gap marker |
| BROKEN | words were removed without gap markers |
| UNTRACKED | tokens were changed or split without an offset mapping |

### Transfer functions

| Operation | SAFE | MARKED | BROKEN | UNTRACKED |
| --- | --- | --- | --- | --- |
| `tokenize` (from TEXT) | SAFE | | | |
| `lower`, `stem` | SAFE | MARKED | BROKEN | UNTRACKED |
| `remove(x)` | BROKEN | BROKEN | BROKEN | UNTRACKED |
| `remove(x, keep_gaps)` | MARKED | MARKED | BROKEN | UNTRACKED |
| `expand_contractions` | UNTRACKED | UNTRACKED | UNTRACKED | UNTRACKED |
| `merge(a, b)` | join(a, b) | | | |

Every row is monotone (checked by `test_transfer_is_monotone_over_all_ops`). The IR is a
DAG built in definition order, so one pass in that order computes the fixed point; no
iteration is needed.

### Checks and severity

`ngrams(min, max)` with `max ≥ 2`:

- input BROKEN → **ADJ001**. Severity: *error* if any consuming sink is `topics` or
  `phrases`; *info* if all consumers are `features` (skip-gram-like features may be
  intended); *warning* if unconsumed. Notes list each `remove(...)` without `keep_gaps`
  found by walking backwards.
- input UNTRACKED → **ADJ002** warning. Because UNTRACKED is the lattice top it hides a
  BROKEN input, so the notes also list unsafe removals on the path.

**Known imprecision (documented false positive):** the analysis does not know which words
occur in the corpus. `remove("zzzz")` without `keep_gaps` is flagged even if *zzzz* never
appears (fault matrix row *static-false-positive*).

### Rewrite pass

For each ngrams node flagged ADJ001/ADJ002 that has unsafe removals upstream, the pass
walks backwards (through `merge` too). If the path contains `expand_contractions`, it
reports REW001 and changes nothing. Otherwise it inserts `, keep_gaps` before the closing
parenthesis of each unsafe `remove(...)` — a textual patch at the recorded offset, so
comments and formatting survive — then **re-compiles and re-analyses** the result. The
rewrite is accepted only if the re-check has no errors and no ADJ001.

## 4. Executor semantics (`executor.py`)

- **Source representation (contract):** UTF-8, `\r\n` → `\n`, Unicode NFC, split into
  documents at blank lines, each stripped. Offsets are code-point offsets into that
  document text, half-open `[start, end)`.
- **Word:** a maximal match of `\w+(?:['’-]\w+)*` (so *state-of-the-art* and *don't* are
  single words).
- **Tokens** are spans of the original text plus a list of **views** (`casefold`, `stem`).
  Views never change offsets; offsets are never computed on lowercased text.
- **Boundaries:** `tokenize` inserts a boundary gap wherever the text between two words is
  not plain whitespace (punctuation) or contains a blank line.
- **Removal:** `remove(x)` deletes tokens; `remove(x, keep_gaps)` replaces each run of
  removed tokens with one *removed* gap that remembers them. Matching uses the casefolded
  view.
- **`expand_contractions`** splits *don't* → *do not* etc. The new tokens have **no**
  offsets (provenance lost); untouched tokens keep theirs.
- **`merge(a, b)`** concatenates per document with a boundary between the two parts.
  Merging two branches of the same corpus therefore repeats phrases — PhraseProof reports
  those as DUPLICATE (fault matrix row *merge-double-count*); AdjCheck does not model counts.
- **`ngrams`** never crosses a gap, with one exception under `connectors(...)`: a removed
  gap made *only* of connector words is bridged by re-inserting those words with their
  own spans. Under the connectors policy `n` counts non-connector words, and a phrase can
  neither start nor end with a connector.
- **LDA** (`lda.py`): a small collapsed Gibbs sampler, seeded, no dependencies.

### Phrase policies

| Policy | An occurrence is supported iff |
| --- | --- |
| `strict` (default) | its words are consecutive source words separated only by whitespace |
| `connectors(w1, ...)` | as strict, and additionally its first and last words are not connectors and at least one word is not a connector |

Elided forms are never accepted: under `connectors(of, the)` the supported phrase is *use
of the term*, never *use term*. Rejected occurrences are **reported**; the optional filter
`validator.verified_counts()` recounts using accepted occurrences only.

## 5. Certificates (`provenance.py`)

One certificate per n-gram **occurrence** (never per phrase type):

```json
{
  "id": 0,
  "phrase": ["use", "of", "the", "term"],
  "doc_id": "d1",
  "doc_sha256": "…64 hex…",
  "spans": [[4, 7], [8, 10], [11, 14], [15, 19]],
  "views": [["casefold"], ["casefold"], ["casefold"], ["casefold"]]
}
```

Each stream in the file also records its `policy`, `policy_sha256`, the pipeline's reported
`counts`, and an `uncertified` list for occurrences whose provenance was lost.

## 6. Validation algorithm (`validator.py`)

The checker imports only `contract.py` and the standard library (enforced by
`test_validator_does_not_import_executor_or_compiler`). It never sees the script.

For each certificate, first failing check wins:

| Check | Code | Rule |
| --- | --- | --- |
| C1 | UNKNOWN_DOC, HASH_MISMATCH | document exists in the supplied source; SHA-256 matches |
| C2 | BAD_SPANS | one span and one view list per word; in bounds; strictly increasing; non-overlapping |
| C3 | NOT_A_WORD | each span is exactly one source word |
| C4 | UNKNOWN_VIEW, TEXT_MISMATCH | `views(source[span]) == phrase word` |
| C5 | GAP_VIOLATION | text between consecutive spans is whitespace only (no punctuation, no skipped word, no blank line) |
| C6 | POLICY_VIOLATION | connectors policy edge rules |
| C7 | DUPLICATE | same (phrase, document, spans) already certified |
| per phrase | COUNT_MISMATCH | reported count ≠ certified + uncertified occurrences |

Statuses: **ACCEPTED**, **REJECTED**, **UNCERTIFIED** (emitted without a certificate).

**Trusted base** (must be reviewed by hand, shared by both sides): `contract.py` — source
canonicalisation and document splitting, the word regex, the view functions, the gap rule,
and the policy definitions.

**What the checker guarantees:** every ACCEPTED occurrence is a real, policy-conforming
span sequence in the stated, unmodified document under the declared views; reported counts
match the certified and uncertified occurrences.

**What it does not guarantee:** completeness (dropped n-grams go unnoticed — row
*drop-occurrences*), correctness of the trusted base, topic quality, or anything about
other inputs. A certificate that points at a *different* valid occurrence of the same
words (rather than the one actually used) is accepted; spans are built from token
positions, never by string search, to avoid producing such certificates.

## 7. Measured results

All numbers come from `python -m adjcheck faults` and `python -m adjcheck experiment`
on `data/sample.txt` (12 documents) and `data/no_gaps.txt`. Re-run them to reproduce.

### Fault-injection matrix

| Scenario | Defect in output | AdjCheck | PhraseProof | Static | Accepted / rejected / uncertified | Evidence |
| --- | --- | --- | --- | --- | --- | --- |
| clean-safe | no | misses | misses | – | 145 / 0 / 0 | – |
| noc-order (NOC module order) | yes | detects | detects | ADJ001 | 145 / 28 / 0 | GAP_VIOLATION=28 |
| noc-order-no-gaps-corpus | no (latent) | detects | misses | ADJ001 | 17 / 0 / 0 | – |
| ignore-gaps (executor bug, script correct) | yes | misses | detects | – | 145 / 37 / 0 | GAP_VIOLATION=37 |
| drop-boundaries | yes | misses | detects | – | 145 / 6 / 0 | GAP_VIOLATION=6 |
| casefold-offsets | yes | misses | detects | – | 130 / 15 / 0 | BAD_SPANS=2, NOT_A_WORD=13 |
| offset-shift | yes | misses | detects | – | 0 / 145 / 0 | NOT_A_WORD=145 |
| duplicate-certificate | yes | misses | detects | – | 145 / 1 / 0 | DUPLICATE=1 |
| inflate-count | yes | misses | detects | – | 145 / 0 / 0 | COUNT_MISMATCH=1 |
| stale-hash | yes | misses | detects | – | 0 / 145 / 0 | HASH_MISMATCH=145 |
| lost-provenance (no fault) | no (marked uncertified) | detects | detects | ADJ002 | 117 / 0 / 6 | UNCERTIFIED=6 |
| certify-untracked | yes | detects | detects | ADJ002 | 117 / 6 / 0 | BAD_SPANS=2, TEXT_MISMATCH=4 |
| merge-double-count | yes | misses | detects | – | 121 / 48 / 0 | DUPLICATE=48 |
| static-false-positive | no | detects | misses | ADJ001 | 263 / 0 / 0 | – |
| drop-occurrences (completeness) | yes | misses | misses | – | 98 / 0 / 0 | – |

Reading: the static analysis catches hazards that a particular run may not exhibit
(*noc-order-no-gaps-corpus*) at the cost of false positives; the checker catches
implementation bugs the analysis cannot see because it trusts operator semantics; neither
detects missing output.

### Policy experiment

| Pipeline | Static | Occurrences | Multi-word | Accepted | Rejected | Distinct multi-word | Distinct rejected |
| --- | --- | --- | --- | --- | --- | --- | --- |
| unsafe | ADJ001 | 173 | 76 | 145 | 28 | 69 | 25 |
| gap-aware (strict) | clean | 145 | 48 | 145 | 0 | 46 | 0 |
| connector (of, the) | clean | 159 | 62 | 159 | 0 | 58 | 0 |

Judging the unsafe run's 76 multi-word occurrences against an index-based oracle:

| Method | True accept | False accept | True reject | False reject |
| --- | --- | --- | --- | --- |
| corpus string match | 48 | 2 | 26 | 0 |
| document string match | 48 | 1 | 27 | 0 |
| PhraseProof | 48 | 0 | 28 | 0 |

The corpus-level false accepts are *use term* (d1; the words are adjacent in d2) and *read
reports* (d12; adjacent later in the same document, which also fools document-level
matching). The corpus was written by hand to contain these cases; the result shows the
mechanism, not a rate to expect on real data. Topic quality was not measured.
