import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from adjcheck.compiler import compile_source  # noqa: E402
from adjcheck.executor import Executor  # noqa: E402
from adjcheck.validator import verify  # noqa: E402


@pytest.fixture
def corpus(tmp_path):
    """Write a corpus (list of documents) to a file and return its path."""
    def make(*docs: str) -> Path:
        p = tmp_path / "corpus.txt"
        p.write_text("\n\n".join(docs) + "\n", encoding="utf-8")
        return p
    return make


def pipeline(corpus_path, ops="lower | remove(stopwords, keep_gaps)", grams="ngrams(1, 2)",
             policy="", sink="phrases"):
    return (f"{policy}\nlet raw = load(\"{corpus_path}\");\n"
            f"let toks = raw | tokenize | {ops};\n"
            f"let grams = toks | {grams};\n"
            f"{sink}(grams) -> \"out.csv\";\n")


def run(script, tmp_path, faults=()):
    res = compile_source(script)
    assert res.analysed, [d.render() for d in res.diagnostics]
    return Executor(res.module, base_dir=tmp_path, faults=set(faults)).run()


def run_and_verify(script, tmp_path, corpus_path, faults=()):
    result = run(script, tmp_path, faults)
    return result, verify(result.certificates, corpus_path)
