"""PhraseProof checker: tampering, duplicates, counts, policies, independence, baselines."""
import ast
import copy
import json
from pathlib import Path

import pytest
from conftest import pipeline, run, run_and_verify

from adjcheck.validator import ACCEPTED, REJECTED, verified_counts, verify

TEXT = "The use of the term improved clarity. Denial of service attacks hurt."


@pytest.fixture
def good(corpus, tmp_path):
    p = corpus(TEXT, "We use term frequency daily.")
    result = run(pipeline(p, policy="policy connectors(of, the);"), tmp_path)
    certs = result.certificates
    assert verify(certs, p).clean
    return certs, p


def first(certs, phrase):
    return next(c for c in certs["streams"][0]["occurrences"] if " ".join(c["phrase"]) == phrase)


def verdict(rep, phrase):
    return next(v for v in rep.verdicts if " ".join(v.phrase) == phrase)


def test_clean_certificates_are_all_accepted(good):
    certs, p = good
    rep = verify(certs, p)
    assert rep.clean and all(v.status == ACCEPTED for v in rep.verdicts)


def test_tampered_document_hash(good):
    certs, p = good
    first(certs, "use of the term")["doc_sha256"] = "0" * 64
    assert verdict(verify(certs, p), "use of the term").code == "HASH_MISMATCH"


def test_edited_source_document_is_detected(good, tmp_path):
    certs, p = good
    edited = tmp_path / "edited.txt"
    edited.write_text(Path(p).read_text().replace("clarity", "clarity a lot"), encoding="utf-8")
    rep = verify(certs, edited)
    assert rep.rejection_codes()["HASH_MISMATCH"] > 0


def test_unknown_document(good):
    certs, p = good
    first(certs, "use of the term")["doc_id"] = "d99"
    assert verdict(verify(certs, p), "use of the term").code == "UNKNOWN_DOC"


@pytest.mark.parametrize("spans,code", [
    ([[4, 7], [11, 14], [15, 19]], "BAD_SPANS"),                 # one span missing
    ([[4, 7], [8, 10], [11, 14], [500, 504]], "BAD_SPANS"),      # out of bounds
    ([[8, 10], [4, 7], [11, 14], [15, 19]], "BAD_SPANS"),        # out of order
    ([[5, 7], [8, 10], [11, 14], [15, 19]], "NOT_A_WORD"),       # partial word
    ([[4, 10], [8, 10], [11, 14], [15, 19]], "BAD_SPANS"),       # overlap
])
def test_tampered_offsets(good, spans, code):
    certs, p = good
    first(certs, "use of the term")["spans"] = spans
    assert verdict(verify(certs, p), "use of the term").code == code


def test_text_mismatch_and_unknown_view(good):
    certs, p = good
    c = first(certs, "use of the term")
    c2 = copy.deepcopy(c)
    c["phrase"] = ["usage", "of", "the", "term"]
    rep = verify(certs, p)
    assert verdict(rep, "usage of the term").code == "TEXT_MISMATCH"
    c.update(c2)
    c["views"][0] = ["uppercase"]
    assert verdict(verify(certs, p), "use of the term").code == "UNKNOWN_VIEW"


def test_gap_violation_for_fabricated_phrase(good):
    certs, p = good
    c = first(certs, "use of the term")
    c["phrase"], c["spans"], c["views"] = ["use", "term"], [c["spans"][0], c["spans"][3]], \
        [c["views"][0], c["views"][3]]
    v = verdict(verify(certs, p), "use term")
    assert v.code == "GAP_VIOLATION" and "of the" in v.detail


def test_gap_violation_across_sentence(corpus, tmp_path):
    p = corpus("Models need data. Data matters.")
    result = run(pipeline(p, ops="lower"), tmp_path, faults={"drop-boundaries"})
    rep = verify(result.certificates, p)
    v = verdict(rep, "data data")
    assert v.status == REJECTED and v.code == "GAP_VIOLATION" and "boundary" in v.detail


def test_connector_policy_edges(good):
    certs, p = good
    c = first(certs, "use of the term")
    c["phrase"], c["spans"], c["views"] = c["phrase"][:2], c["spans"][:2], c["views"][:2]
    assert verdict(verify(certs, p), "use of").code == "POLICY_VIOLATION"


def test_strict_policy_rejects_connector_bridging(good):
    certs, p = good
    certs["streams"][0]["policy"] = {"kind": "strict", "connectors": []}
    from adjcheck.contract import PhrasePolicy
    certs["streams"][0]["policy_sha256"] = PhrasePolicy("strict").sha256
    rep = verify(certs, p)
    assert verdict(rep, "use of the term").status == ACCEPTED   # contiguous in source anyway


def test_policy_hash_mismatch_is_a_file_issue(good):
    certs, p = good
    certs["streams"][0]["policy"]["connectors"].append("in")
    rep = verify(certs, p)
    assert rep.file_issues and not rep.clean


def test_duplicate_certificate(good):
    certs, p = good
    occs = certs["streams"][0]["occurrences"]
    occs.append(dict(first(certs, "denial of service"), id=len(occs)))
    certs["streams"][0]["counts"]["denial of service"] += 1
    rep = verify(certs, p)
    assert rep.rejection_codes() == {"DUPLICATE": 1} and not rep.count_issues


def test_inconsistent_counts(good):
    certs, p = good
    certs["streams"][0]["counts"]["denial of service"] = 7
    certs["streams"][0]["counts"]["phantom phrase"] = 1
    rep = verify(certs, p)
    assert {c["phrase"] for c in rep.count_issues} == {"denial of service", "phantom phrase"}


def test_bad_format(good):
    certs, p = good
    certs["format"] = "something-else"
    assert verify(certs, p).file_issues


def test_occurrence_level_beats_corpus_string_match(good):
    """'use term' is adjacent in d2 but fabricated in d1: only the d1 certificate is rejected."""
    certs, p = good
    occs = certs["streams"][0]["occurrences"]
    d2 = first(certs, "use term")
    assert d2["doc_id"] == "d2"
    c = first(certs, "use of the term")
    fab = {"id": len(occs), "phrase": ["use", "term"], "doc_id": "d1",
           "doc_sha256": c["doc_sha256"], "spans": [c["spans"][0], c["spans"][3]],
           "views": [c["views"][0], c["views"][3]]}
    occs.append(fab)
    certs["streams"][0]["counts"]["use term"] += 1
    rep = verify(certs, p)
    st = sorted((v.doc_id, v.status) for v in rep.verdicts if " ".join(v.phrase) == "use term")
    assert st == [("d1", REJECTED), ("d2", ACCEPTED)]
    assert verified_counts(rep)["grams"]["use term"] == 1


def test_checker_is_complete_only_for_supplied_certificates(corpus, tmp_path):
    """A pipeline that silently drops occurrences still verifies clean (documented limit)."""
    p = corpus("alpha beta gamma delta epsilon zeta")
    result, rep = run_and_verify(pipeline(p, ops="lower", grams="ngrams(1)"), tmp_path, p,
                                 faults={"drop-occurrences"})
    assert rep.clean and rep.summary()["ACCEPTED"] == 4      # 6 words, 2 silently dropped


def test_validator_does_not_import_executor_or_compiler():
    src = Path(__file__).resolve().parents[1] / "src/adjcheck/validator.py"
    tree = ast.parse(src.read_text())
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            imported.add((node.level, node.module))
        elif isinstance(node, ast.Import):
            imported.update((0, a.name) for a in node.names)
    internal = {m for lvl, m in imported if lvl > 0}
    assert internal <= {None, "contract"}, internal     # `from . import contract` / `.contract`


def test_report_json_roundtrip(good):
    certs, p = good
    rep = verify(certs, p)
    data = json.loads(json.dumps(rep.to_json()))
    assert data["summary"]["ACCEPTED"] == len(data["verdicts"])


def test_malformed_occurrence_does_not_crash_verifier(good):
    """A malformed occurrence is rejected instead of crashing verification."""
    certs, p = good

    # Add a malformed entry to the existing certificate list.
    certs["streams"][0]["occurrences"].append(None)

    rep = verify(certs, p)

    assert any(
        v.code == "MALFORMED_CERTIFICATE"
        for v in rep.verdicts
    )
    assert not any(
        v.status == ACCEPTED and v.phrase == []
        for v in rep.verdicts
    )

