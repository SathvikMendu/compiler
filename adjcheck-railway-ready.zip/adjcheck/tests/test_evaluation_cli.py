"""Fault matrix, experiment, randomised agreement with a brute-force oracle, and the CLI."""
import random
import re
import subprocess
import sys
from pathlib import Path

import pytest
from conftest import ROOT, pipeline, run_and_verify

from adjcheck.evaluation.experiment import run_experiment
from adjcheck.evaluation.faults import SCENARIOS, run_scenario
from adjcheck.validator import ACCEPTED

# Expected detection pattern: (AdjCheck detects, PhraseProof detects)
EXPECTED = {
    "clean-safe": (False, False),
    "noc-order": (True, True),
    "noc-order-no-gaps-corpus": (True, False),
    "ignore-gaps": (False, True),
    "drop-boundaries": (False, True),
    "casefold-offsets": (False, True),
    "offset-shift": (False, True),
    "duplicate-certificate": (False, True),
    "inflate-count": (False, True),
    "stale-hash": (False, True),
    "lost-provenance": (True, True),
    "certify-untracked": (True, True),
    "merge-double-count": (False, True),
    "static-false-positive": (True, False),
    "drop-occurrences": (False, False),
}


@pytest.mark.parametrize("sc", SCENARIOS, ids=lambda s: s.name)
def test_fault_matrix_row(sc):
    r = run_scenario(sc)
    assert (r["adjcheck"], r["phraseproof"]) == EXPECTED[sc.name]


def test_lost_provenance_reports_uncertified_not_rejected():
    r = run_scenario(next(s for s in SCENARIOS if s.name == "lost-provenance"))
    assert r["summary"]["REJECTED"] == 0 and r["summary"]["UNCERTIFIED"] > 0


def test_experiment_runs_and_reports_measured_tables():
    text = run_experiment(None)
    assert "| unsafe | ADJ001 |" in text and "| gap-aware | clean |" in text
    assert "*denial of service*" in text and "*use term* (d1)" in text


# -- randomised agreement with a brute-force oracle ----------------------------------

VOCAB = ["the", "of", "a", "data", "model", "attack", "server", "use", "term", "and", "to", "is"]
PUNCT = [" ", " ", " ", " ", ", ", ". ", "; "]
WORD = re.compile(r"\w+")


def oracle(text, spans):
    """Valid iff the spans are consecutive words separated only by spaces."""
    words = [m.span() for m in WORD.finditer(text)]
    idx = [words.index(tuple(s)) if tuple(s) in words else None for s in spans]
    if None in idx or any(b != a + 1 for a, b in zip(idx, idx[1:])):
        return False
    return all(text[e:s].strip() == "" for (_, e), (s, _) in zip(spans, spans[1:]))


@pytest.mark.parametrize("seed", range(40))
def test_checker_agrees_with_oracle_on_random_pipelines(seed, corpus, tmp_path):
    rng = random.Random(seed)
    docs = []
    for _ in range(3):
        n = rng.randint(4, 14)
        docs.append("".join(rng.choice(VOCAB) + rng.choice(PUNCT) for _ in range(n)).strip())
    p = corpus(*docs)
    ops = rng.choice(["lower", "lower | remove(stopwords)", "lower | remove(stopwords, keep_gaps)",
                      "remove(stopwords) | lower", "lower | remove(\"data\") | stem"])
    policy = rng.choice(["", "policy connectors(of, the);"])
    faults = rng.choice([set(), set(), {"ignore-gaps"}, {"drop-boundaries"}])
    result, rep = run_and_verify(pipeline(p, ops=ops, grams="ngrams(1, 3)", policy=policy),
                                 tmp_path, p, faults)
    texts = {d.doc_id: d.text for d in result.documents}
    certs = {c["id"]: c for c in result.certificates["streams"][0]["occurrences"]}
    for v in rep.verdicts:
        c = certs[v.occurrence_id]
        assert (v.status == ACCEPTED) == oracle(texts[c["doc_id"]], c["spans"]), (ops, c)
    if not faults and ("keep_gaps" in ops or ops == "lower"):
        assert rep.clean                     # correct executor + safe script => all accepted


# -- CLI ------------------------------------------------------------------------------

def cli(*args, cwd=ROOT):
    env = {"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin"}
    return subprocess.run([sys.executable, "-m", "adjcheck", *args], cwd=cwd, env=env,
                          capture_output=True, text=True)


def test_cli_parse_and_tokens():
    r = cli("parse", "examples/safe.adj")
    assert r.returncode == 0 and "Call ngrams(1, 2)" in r.stdout
    r = cli("parse", "--tokens", "examples/safe.adj")
    assert r.returncode == 0 and "LET('let')@4:1" in r.stdout


def test_cli_check_exit_codes():
    assert cli("check", "examples/unsafe.adj").returncode == 1
    r = cli("check", "examples/safe.adj")
    assert r.returncode == 0 and "MARKED" in r.stdout


def test_cli_fix_writes_clean_script(tmp_path):
    out = tmp_path / "fixed.adj"
    r = cli("fix", "examples/unsafe.adj", "-o", str(out))
    assert r.returncode == 0 and "keep_gaps" in out.read_text()
    assert cli("check", str(out)).returncode == 0


def test_cli_run_refuses_unsafe_and_verify_flags_it(tmp_path):
    assert cli("run", "examples/unsafe.adj").returncode == 2
    certs = tmp_path / "c.json"
    assert cli("run", "examples/unsafe.adj", "--allow-unsafe", "--certs", str(certs)).returncode == 0
    r = cli("verify", str(certs), "--source", "data/sample.txt")
    assert r.returncode == 1 and "GAP_VIOLATION" in r.stdout


def test_cli_run_and_verify_safe(tmp_path):
    certs = tmp_path / "c.json"
    assert cli("run", "examples/safe.adj", "--certs", str(certs)).returncode == 0
    r = cli("verify", str(certs), "--source", "data/sample.txt", "--json", str(tmp_path / "r.json"))
    assert r.returncode == 0 and "0 rejected" in r.stdout and (tmp_path / "r.json").exists()


def test_cli_faulty_executor_passes_static_check_but_fails_verification(tmp_path):
    certs = tmp_path / "c.json"
    assert cli("check", "examples/safe.adj").returncode == 0
    assert cli("run", "examples/safe.adj", "--fault", "ignore-gaps", "--certs", str(certs)).returncode == 0
    r = cli("verify", str(certs), "--source", "data/sample.txt")
    assert r.returncode == 1 and "rejected" in r.stdout
