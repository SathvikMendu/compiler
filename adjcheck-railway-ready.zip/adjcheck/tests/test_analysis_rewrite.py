"""Data-flow lattice, transfer rules, branches/merges, severities, rewrite."""
import pytest

from adjcheck.analysis import State, join
from adjcheck.compiler import compile_source
from adjcheck.diagnostics import Severity
from adjcheck.rewrite import rewrite

HEAD = 'let raw = load("data/sample.txt");\nlet toks = raw | tokenize | lower;\n'


def states(src):
    res = compile_source(src)
    assert res.analysed, [d.render() for d in res.diagnostics]
    return {n.label: res.states[n.id] for n in res.module.nodes if n.label and n.id in res.states}, res


def test_lattice_is_a_chain_with_max_join():
    assert State.SAFE < State.MARKED < State.BROKEN < State.UNTRACKED
    assert join(State.SAFE, State.BROKEN) is State.BROKEN
    assert join(State.MARKED, State.UNTRACKED) is State.UNTRACKED
    assert join() is State.SAFE


@pytest.mark.parametrize("ops,expected", [
    ("lower", State.SAFE),
    ("remove(stopwords, keep_gaps)", State.MARKED),
    ("remove(stopwords, keep_gaps) | remove(numbers, keep_gaps)", State.MARKED),
    ("remove(stopwords)", State.BROKEN),
    ("remove(stopwords) | remove(numbers, keep_gaps)", State.BROKEN),   # keep_gaps can't undo
    ("remove(stopwords, keep_gaps) | stem", State.MARKED),
    ("expand_contractions", State.UNTRACKED),
    ("expand_contractions | remove(stopwords, keep_gaps)", State.UNTRACKED),
])
def test_transfer_rules(ops, expected):
    st, _ = states(HEAD + f"let s = toks | {ops};\nlet g = s | ngrams(1);\nphrases(g);")
    assert st["s"] is expected


def test_transfer_is_monotone_over_all_ops():
    from adjcheck.analysis import transfer
    from adjcheck.ir import Node
    from adjcheck.diagnostics import Loc
    ops = [("lower", {}), ("stem", {}), ("remove", {"keep_gaps": True}),
           ("remove", {"keep_gaps": False}), ("expand_contractions", {}), ("merge", {})]
    for op, args in ops:
        node = Node(0, op, [], None, Loc(1, 1), args)
        outs = [transfer(node, [s]) for s in State]
        assert outs == sorted(outs), op


def test_unsafe_noc_pipeline_is_error_with_culprit_note():
    _, res = states(HEAD + "let c = toks | remove(stopwords);\nlet g = c | ngrams(1, 2);\n"
                    'topics(g, k = 3);')
    d = [d for d in res.diagnostics if d.code == "ADJ001"][0]
    assert d.severity is Severity.ERROR and (d.loc.line, d.loc.col) == (4, 13)
    assert any("remove(...) at 3:16" in n for n in d.notes) and "keep_gaps" in d.fix


def test_unigrams_only_are_not_flagged():
    _, res = states(HEAD + "let c = toks | remove(stopwords);\nlet g = c | ngrams(1);\nphrases(g);")
    assert "ADJ001" not in res.codes()


def test_feature_only_sink_lowers_severity_to_info():
    _, res = states(HEAD + "let c = toks | remove(stopwords);\nlet g = c | ngrams(2);\nfeatures(g);")
    d = [d for d in res.diagnostics if d.code == "ADJ001"][0]
    assert d.severity is Severity.INFO and res.ok


def test_phrase_and_feature_sinks_together_is_error():
    _, res = states(HEAD + "let c = toks | remove(stopwords);\nlet g = c | ngrams(2);\n"
                    "features(g);\nphrases(g);")
    assert [d.severity for d in res.diagnostics if d.code == "ADJ001"] == [Severity.ERROR]


def test_branches_and_merge_join():
    src = HEAD + ("let a = toks | remove(stopwords);\nlet b = toks | remove(numbers, keep_gaps);\n"
                  "let m = merge(a, b);\nlet gb = b | ngrams(2);\nlet gm = m | ngrams(2);\n"
                  "phrases(gb);\nphrases(gm);")
    st, res = states(src)
    assert (st["a"], st["b"], st["m"]) == (State.BROKEN, State.MARKED, State.BROKEN)
    flagged = [d.loc.line for d in res.diagnostics if d.code == "ADJ001"]
    assert flagged == [7]                         # only the merged branch


def test_merge_of_two_safe_branches_is_safe():
    src = HEAD + ("let a = toks | remove(stopwords, keep_gaps);\nlet b = toks | stem;\n"
                  "let m = merge(a, b);\nlet g = m | ngrams(2);\nphrases(g);")
    st, res = states(src)
    assert st["m"] is State.MARKED and "ADJ001" not in res.codes()


def test_untracked_gives_adj002_warning():
    _, res = states(HEAD + "let c = toks | expand_contractions;\nlet g = c | ngrams(2);\nphrases(g);")
    assert [(d.code, d.severity) for d in res.diagnostics] == [("ADJ002", Severity.WARNING)]


# -- rewrite -----------------------------------------------------------------------------

def test_rewrite_adds_keep_gaps_and_rechecks_clean():
    src = open("examples/unsafe.adj", encoding="utf-8").read()
    rw = rewrite(src)
    assert rw.ok and "remove(stopwords, keep_gaps)" in rw.rewritten
    assert "ADJ001" not in rw.recheck.codes()
    assert rw.rewritten.startswith("# NOC-style")           # comments preserved


def test_rewrite_handles_merges_and_multiple_removals():
    src = HEAD + ("let a = toks | remove(stopwords) | remove(numbers);\nlet b = toks | remove(\"x y\");\n"
                  "let m = merge(a, b);\nlet g = m | ngrams(2);\nphrases(g);")
    rw = rewrite(src)
    assert rw.ok and rw.rewritten.count("keep_gaps") == 3
    assert "ADJ001" not in rw.recheck.codes()


def test_rewrite_refuses_untracked_paths():
    src = HEAD + ("let c = toks | remove(stopwords) | expand_contractions;\n"
                  "let d = toks | remove(stopwords);\nlet m = merge(c, d);\n"
                  "let g = m | ngrams(2);\nphrases(g);")
    rw = rewrite(src)
    assert not rw.ok and rw.diagnostics[0].code == "REW001"


def test_rewrite_of_clean_script_is_identity():
    src = open("examples/safe.adj", encoding="utf-8").read()
    rw = rewrite(src)
    assert rw.ok and rw.rewritten == src


def test_rewrite_refuses_broken_scripts():
    rw = rewrite("let a = ;")
    assert not rw.ok and rw.diagnostics[0].code == "REW001"
