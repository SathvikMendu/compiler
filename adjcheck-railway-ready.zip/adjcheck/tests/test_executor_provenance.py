"""Executor semantics: offsets, Unicode, repeated words, boundaries, connectors, provenance."""
from conftest import pipeline, run, run_and_verify

from adjcheck import contract
from adjcheck.executor import ExecutionError, Executor
from adjcheck.compiler import compile_source
import pytest


def keys(result, stream="grams"):
    return [o.key for occs in result.grams[stream].values() for o in occs]


def test_offsets_refer_to_original_text(corpus, tmp_path):
    p = corpus("The use of the term improved clarity.")
    result = run(pipeline(p, grams="ngrams(1)"), tmp_path)
    doc = result.documents[0]
    for o in result.grams["grams"]["d1"]:
        t = o.toks[0]
        assert doc.text[t.start:t.end].casefold() == t.text and t.views == ("casefold",)
    use = next(o for o in result.grams["grams"]["d1"] if o.key == "use")
    assert (use.toks[0].start, use.toks[0].end) == (4, 7)


def test_unicode_casefold_keeps_original_offsets(corpus, tmp_path):
    p = corpus("Straße und Gärten. İstanbul hosts it.")
    result, rep = run_and_verify(pipeline(p, ops="lower"), tmp_path, p)
    doc = result.documents[0]
    ist = next(o for o in result.grams["grams"]["d1"] if o.key == "i̇stanbul")
    s, e = ist.toks[0].start, ist.toks[0].end
    assert doc.text[s:e] == "İstanbul"           # 8 chars; its casefold has 9
    assert rep.clean and rep.summary()["ACCEPTED"] == len(rep.verdicts)


def test_input_is_nfc_normalised(corpus, tmp_path):
    p = corpus("café menu")                    # decomposed é
    result = run(pipeline(p, ops="lower", grams="ngrams(2)"), tmp_path)
    assert keys(result) == ["café menu"] and len(result.documents[0].text) == 9


def test_repeated_words_get_distinct_spans(corpus, tmp_path):
    p = corpus("very very good results were very good")
    result, rep = run_and_verify(pipeline(p, ops="lower", grams="ngrams(2)"), tmp_path, p)
    vg = [o for o in result.grams["grams"]["d1"] if o.key == "very good"]
    assert len(vg) == 2 and vg[0].toks[0].start != vg[1].toks[0].start
    assert rep.clean


def test_punctuation_and_sentences_are_boundaries(corpus, tmp_path):
    p = corpus("Data, models and code. Code ships.")
    result = run(pipeline(p, ops="lower", grams="ngrams(2)"), tmp_path)
    ks = keys(result)
    assert "data models" not in ks and "code code" not in ks
    assert "models and" in ks and "code ships" in ks


def test_unsafe_removal_fabricates_and_gap_removal_does_not(corpus, tmp_path):
    p = corpus("The use of the term improved clarity.")
    unsafe = run(pipeline(p, ops="lower | remove(stopwords)"), tmp_path)
    safe = run(pipeline(p), tmp_path)
    assert "use term" in keys(unsafe) and "use term" not in keys(safe)


def test_connector_policy_reinserts_connectors_with_spans(corpus, tmp_path):
    p = corpus("Denial of service attacks. The use of the term helped.")
    result, rep = run_and_verify(pipeline(p, policy="policy connectors(of, the);"), tmp_path, p)
    ks = keys(result)
    assert "denial of service" in ks and "use of the term" in ks
    assert "denial service" not in ks and "use term" not in ks
    assert not any(k.split()[0] in ("of", "the") or k.split()[-1] in ("of", "the") for k in ks)
    assert rep.clean


def test_connector_gap_with_non_connector_is_not_bridged(corpus, tmp_path):
    p = corpus("attacks on a server")         # 'on' and 'a' are stop words, only 'on' is not a connector
    result = run(pipeline(p, policy="policy connectors(of, the);"), tmp_path)
    assert "attacks server" not in keys(result) and len(keys(result)) == 2


def test_lost_provenance_is_uncertified_not_accepted(corpus, tmp_path):
    p = corpus("Users don't trust it.")
    script = pipeline(p, ops="lower | expand_contractions", grams="ngrams(2)")
    result, rep = run_and_verify(script, tmp_path, p)
    s = rep.summary()
    assert s["UNCERTIFIED"] == 3 and s["REJECTED"] == 0   # users do / do not / not trust
    assert s["ACCEPTED"] == 1                              # "trust it" keeps its provenance
    unc = {" ".join(v.phrase) for v in rep.verdicts if v.status == "UNCERTIFIED"}
    assert unc == {"users do", "do not", "not trust"}


def test_merge_inserts_boundary(corpus, tmp_path):
    p = corpus("alpha beta")
    script = (f'let raw = load("{p}");\nlet t = raw | tokenize;\nlet a = t | lower;\n'
              'let b = t | stem;\nlet m = merge(a, b);\nlet g = m | ngrams(2);\nphrases(g);')
    result = run(script, tmp_path)
    assert keys(result, "g") == ["alpha beta", "alpha beta"]   # no "beta alpha" across the merge


def test_stem_view_is_verified_from_source(corpus, tmp_path):
    p = corpus("Attackers exploiting servers")
    result, rep = run_and_verify(pipeline(p, ops="lower | stem", grams="ngrams(2)"), tmp_path, p)
    assert keys(result) == ["attacker exploit", "exploit server"] and rep.clean


def test_sinks_write_files(corpus, tmp_path):
    p = corpus("buffer overflow bugs. buffer overflow fixed.", "denial of service attack")
    script = (pipeline(p, sink="phrases") + 'topics(grams, k = 2, iterations = 20) -> "t.csv";\n'
              'features(grams) -> "f.csv";\n')
    result = run(script, tmp_path)
    assert (tmp_path / "out.csv").read_text().startswith("phrase,words,count")
    assert "buffer overflow,2,2" in (tmp_path / "out.csv").read_text()
    assert (tmp_path / "t.csv").read_text().startswith("topic,rank,term,probability")
    assert "d2,denial,1" in (tmp_path / "f.csv").read_text()


def test_missing_corpus_and_unknown_fault_are_errors(tmp_path):
    res = compile_source(pipeline(tmp_path / "missing.txt"))
    with pytest.raises(ExecutionError):
        Executor(res.module, base_dir=tmp_path).run()
    with pytest.raises(ExecutionError):
        Executor(res.module, base_dir=tmp_path, faults={"nope"})


def test_contract_gap_rule():
    assert contract.classify_gap(" ") is None and contract.classify_gap(" \n ") is None
    assert "skips" in contract.classify_gap(" of the ")
    assert "boundary" in contract.classify_gap(", ")
    assert "blank line" in contract.classify_gap("\n\n")


def test_contract_documents_and_words():
    docs = contract.split_documents("a b\n\n\n c d \n")
    assert [(d.doc_id, d.text) for d in docs] == [("d1", "a b"), ("d2", "c d")]
    assert contract.word_spans("state-of-the-art don't") == {(0, 16), (17, 22)}
