"""Web interface: routes, input validation, sandboxing, and real (not mocked) results.

Skipped automatically if Flask is not installed (pip install -e ".[web]").
"""
import hashlib
import io
from pathlib import Path

import pytest

flask = pytest.importorskip("flask")

from conftest import ROOT  # noqa: E402

from adjcheck import contract  # noqa: E402
from adjcheck.compiler import compile_source  # noqa: E402
from adjcheck.validator import verify  # noqa: E402
from adjcheck.web import create_app  # noqa: E402
from adjcheck.web.service import EXAMPLES, LIMITS, SAMPLE_TEXT, Limits, analyze  # noqa: E402

SCRIPTS = {e["id"]: e["script"] for e in EXAMPLES}


@pytest.fixture
def client():
    app = create_app()
    app.testing = True
    return app.test_client()


def post(client, text, script="safe", allow=False):
    return client.post("/api/analyze", json={"text": text, "script": SCRIPTS.get(script, script),
                                             "allow_unsafe": allow})


def statuses(data, phrase):
    return sorted((o["doc_id"], o["status"]) for o in data["verification"]["occurrences"]
                  if " ".join(o["phrase"]) == phrase)


# -- pages and examples ------------------------------------------------------------------

def test_index_page_and_assets(client):
    r = client.get("/")
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and 'id="text"' in html and 'id="script"' in html
    assert 'type="file"' in html and "Run analysis" in html
    assert "Content-Security-Policy" in r.headers
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/static/app.css").status_code == 200


def test_examples_are_real_dsl_bound_to_input(client):
    data = client.get("/api/examples").get_json()
    ids = [e["id"] for e in data["examples"]]
    assert {"safe", "unsafe", "connectors"} <= set(ids)
    for ex in data["examples"]:
        res = compile_source(ex["script"])
        assert res.analysed, ex["id"]
        loads = [n for n in res.module.nodes if n.op == "load"]
        assert loads and all(n.args["path"] == "input.txt" for n in loads)
    assert data["sample_text"].strip()


def test_examples_match_project_example_files():
    """The web examples use the same operations as examples/*.adj (paths aside)."""
    def ops(src):
        res = compile_source(src)
        return [(n.op, tuple(sorted((k, str(v)) for k, v in n.args.items() if k != "path")))
                for n in res.module.nodes if n.op not in ("topics", "phrases", "features")]
    for ex in ("safe", "unsafe", "connectors", "branches", "untracked"):
        file_src = (ROOT / "examples" / f"{ex}.adj").read_text(encoding="utf-8")
        assert ops(SCRIPTS[ex]) == ops(file_src), ex


# -- real results on user text --------------------------------------------------------------

def test_safe_pipeline_processes_the_users_text(client):
    text = "Quantum zebra telemetry arrived late.\n\nThe zebra telemetry was corrupted."
    r = post(client, text)
    d = r.get_json()
    assert r.status_code == 200 and d["execution"]["executed"]
    # the documents the pipeline read are exactly the user's text, split at blank lines
    expected = contract.split_documents(contract.canonicalize(text))
    assert [(x["doc_id"], x["text"]) for x in d["documents"]] == \
        [(x.doc_id, x.text) for x in expected]
    phrases = {p["phrase"] for p in d["phrases"]}
    assert {"zebra telemetry", "quantum zebra", "quantum"} <= phrases
    assert not any("denial" in p for p in phrases)          # nothing from the sample corpus
    s = d["verification"]["summary"]
    assert s["ACCEPTED"] > 0 and s["REJECTED"] == 0 and s["UNCERTIFIED"] == 0
    assert d["verification"]["clean"]


def test_results_match_direct_compiler_executor_verifier(client, tmp_path):
    """The web result equals running the project components directly."""
    from adjcheck.executor import Executor
    text = SAMPLE_TEXT
    d = post(client, text, "unsafe", allow=True).get_json()
    corpus = tmp_path / "input.txt"
    corpus.write_bytes(text.encode("utf-8"))
    res = compile_source(SCRIPTS["unsafe"])
    direct = Executor(res.module, base_dir=tmp_path).run()
    rep = verify(direct.certificates, corpus)
    assert d["verification"]["summary"] == rep.summary()
    assert d["certificates"]["streams"][0]["counts"] == direct.certificates["streams"][0]["counts"]


def test_unsafe_pipeline_reports_adj001_and_is_not_run_by_default(client):
    d = post(client, SAMPLE_TEXT, "unsafe").get_json()
    codes = [(g["code"], g["severity"]) for g in d["static"]["diagnostics"]]
    assert ("ADJ001", "error") in codes
    assert not d["execution"]["executed"] and "not run" in d["execution"]["reason"]
    assert d["verification"] is None
    states = {s["stream"]: s["state"] for s in d["static"]["states"]}
    assert states["clean"] == "BROKEN" and states["grams"] == "BROKEN"
    fix = d["fix"]
    assert fix["ok"] and fix["changed"] and "remove(stopwords, keep_gaps)" in fix["script"]


def test_unsafe_pipeline_when_forced_shows_phraseproof_rejections(client):
    d = post(client, SAMPLE_TEXT, "unsafe", allow=True).get_json()
    assert d["execution"]["executed"]
    v = d["verification"]
    assert v["summary"]["REJECTED"] > 0 and "GAP_VIOLATION" in v["rejections_by_check"]
    assert statuses(d, "use term") == [("d1", "REJECTED"), ("d2", "ACCEPTED")]
    rej = next(o for o in v["occurrences"] if " ".join(o["phrase"]) == "use term"
               and o["status"] == "REJECTED")
    doc = next(x["text"] for x in d["documents"] if x["doc_id"] == "d1")
    assert [doc[s:e] for s, e in rej["spans"]] == ["use", "term"]


def test_repeated_phrase_gets_per_occurrence_verdicts(client):
    """Regression: the old page labelled every 'read reports' with the first verdict."""
    d = post(client, "Analysts read the reports and later read reports again.", "unsafe",
             allow=True).get_json()
    assert statuses(d, "read reports") == [("d1", "ACCEPTED"), ("d1", "REJECTED")]
    rows = [line for line in d["verification"]["verdicts_csv"].splitlines()
            if ",read reports," in line]
    assert sorted(r.split(",")[4] for r in rows) == ["ACCEPTED", "REJECTED"]
    agg = next(p for p in d["phrases"] if p["phrase"] == "read reports")
    assert (agg["reported"], agg["ACCEPTED"], agg["REJECTED"]) == (2, 1, 1)


def test_connector_pipeline_keeps_denial_of_service(client):
    d = post(client, SAMPLE_TEXT, "connectors").get_json()
    assert d["static"]["diagnostics"] == [] and d["verification"]["clean"]
    assert all(s == "ACCEPTED" for _, s in statuses(d, "denial of service"))
    assert statuses(d, "denial service") == []


def test_untracked_pipeline_reports_adj002_and_uncertified(client):
    d = post(client, SAMPLE_TEXT, "untracked").get_json()
    assert [g["code"] for g in d["static"]["diagnostics"]] == ["ADJ002"]
    s = d["verification"]["summary"]
    assert s["UNCERTIFIED"] > 0 and s["REJECTED"] == 0
    assert "do not" in {" ".join(o["phrase"]) for o in d["verification"]["occurrences"]
                        if o["status"] == "UNCERTIFIED"}


def test_branches_pipeline_shows_merge_and_feature_severity(client):
    d = post(client, SAMPLE_TEXT, "branches", allow=True).get_json()
    sev = [(g["code"], g["severity"]) for g in d["static"]["diagnostics"]]
    assert ("ADJ001", "error") in sev and ("ADJ001", "info") in sev
    states = {s["stream"]: s["state"] for s in d["static"]["states"]}
    assert states["both"] == "BROKEN" and states["b"] == "MARKED"
    assert {o["name"] for o in d["outputs"]} == {"phrases_line10.csv", "phrases_line11.csv",
                                                 "features_line12.csv"}


def test_outputs_and_certificates_are_downloadable_and_verifiable(client, tmp_path):
    d = post(client, SAMPLE_TEXT, "safe").get_json()
    names = {o["name"] for o in d["outputs"]}
    assert names == {"phrases_line7.csv", "topics_line8.csv"}
    phrases_csv = next(o["content"] for o in d["outputs"] if o["sink"] == "phrases")
    assert phrases_csv.startswith("phrase,words,count")
    assert d["topics"] and d["topics"][0]["topics"]
    # certificates from the page re-verify independently against the same text
    src = tmp_path / "input.txt"
    src.write_bytes(SAMPLE_TEXT.encode("utf-8"))
    assert verify(d["certificates"], src).summary() == d["verification"]["summary"]
    assert d["verification"]["report"]["summary"] == d["verification"]["summary"]


def test_unicode_offsets_are_code_points(client):
    text = "Emoji 🚀 launch control.\n\nİstanbul hosts the café summit."
    d = post(client, text, "safe").get_json()
    docs = {x["doc_id"]: x["text"] for x in d["documents"]}
    for o in d["verification"]["occurrences"]:
        words = [docs[o["doc_id"]][s:e].casefold() for s, e in o["spans"]]
        assert words == o["phrase"]
    assert d["verification"]["clean"]


# -- input validation ----------------------------------------------------------------------

@pytest.mark.parametrize("text,code", [("", "TEXT_EMPTY"), ("   \n\n  ", "TEXT_EMPTY"),
                                       (None, "TEXT_INVALID"), (42, "TEXT_INVALID"),
                                       ("bad\x00byte", "TEXT_BINARY")])
def test_bad_text_is_rejected(client, text, code):
    r = post(client, text)
    assert r.status_code == 400 and r.get_json()["error"]["code"] == code


def test_oversized_text_is_rejected(client):
    r = post(client, "word " * (LIMITS.max_text_chars // 5 + 10))
    assert r.status_code == 413 and r.get_json()["error"]["code"] == "TEXT_TOO_LARGE"


def test_oversized_request_body_is_rejected(client):
    r = client.post("/api/analyze", data=b"x" * (LIMITS.max_request_bytes + 10),
                    content_type="application/json")
    assert r.status_code == 413 and r.get_json()["error"]["code"] == "REQUEST_TOO_LARGE"


@pytest.mark.parametrize("body", [b"not json", b"[1, 2]", b'"text"'])
def test_malformed_json_is_rejected(client, body):
    r = client.post("/api/analyze", data=body, content_type="application/json")
    assert r.status_code == 400 and r.get_json()["error"]["code"] == "BAD_REQUEST"


def test_allow_unsafe_must_be_boolean(client):
    r = client.post("/api/analyze", json={"text": "a b", "script": SCRIPTS["safe"],
                                          "allow_unsafe": "yes"})
    assert r.status_code == 400


@pytest.mark.parametrize("script,code", [("", "SCRIPT_EMPTY"), (None, "SCRIPT_INVALID"),
                                         ("# x\n" * 2000, "SCRIPT_TOO_LARGE")],
                         ids=["empty", "none", "oversized"])
def test_bad_script_input_is_rejected(client, script, code):
    r = client.post("/api/analyze", json={"text": "a b", "script": script})
    assert r.get_json()["error"]["code"] == code and r.status_code in (400, 413)


@pytest.mark.parametrize("script,code", [
    ('let raw = load("input.txt")', "SYN001"),                       # missing ';'
    ('let raw = load("input.txt") | @;', "LEX001"),
    ('let g = load("input.txt") | ngrams(2);\nphrases(g);', "SEM005"),
    ('let g = nope | ngrams(2);\nphrases(g);', "SEM001"),
])
def test_invalid_dsl_returns_diagnostics_without_running(client, script, code):
    r = client.post("/api/analyze", json={"text": SAMPLE_TEXT, "script": script})
    d = r.get_json()
    assert r.status_code == 200 and code in [g["code"] for g in d["static"]["diagnostics"]]
    assert not d["static"]["analysed"] and not d["execution"]["executed"]
    assert d["verification"] is None and d["documents"] == []


# -- sandboxing -----------------------------------------------------------------------------

def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.mark.parametrize("path", ["data/sample.txt", "../data/sample.txt", "/etc/passwd",
                                  str(ROOT / "data" / "sample.txt")])
def test_load_cannot_read_other_files(client, path):
    script = SCRIPTS["safe"].replace('load("input.txt")', f'load("{path}")')
    d = client.post("/api/analyze", json={"text": "hello world", "script": script}).get_json()
    assert "WEB001" in [g["code"] for g in d["static"]["diagnostics"]]
    assert not d["execution"]["executed"] and d["documents"] == []


def test_sink_paths_cannot_write_outside_temp_dir(client, tmp_path):
    target = tmp_path / "evil.csv"
    project_target = ROOT / "outputs" / "web_should_not_exist.csv"
    script = SCRIPTS["safe"].replace('"phrases.csv"', f'"{target}"') \
        .replace('"topics.csv"', '"../outputs/web_should_not_exist.csv"')
    d = client.post("/api/analyze", json={"text": SAMPLE_TEXT, "script": script}).get_json()
    assert d["execution"]["executed"]
    assert not target.exists() and not project_target.exists()
    assert {o["name"] for o in d["outputs"]} == {"phrases_line7.csv", "topics_line8.csv"}


def test_project_corpus_and_outputs_are_untouched(client):
    watched = [ROOT / "data" / "sample.txt", ROOT / "data" / "no_gaps.txt"]
    watched += sorted((ROOT / "outputs").rglob("*.*")) if (ROOT / "outputs").exists() else []
    before = {p: _digest(p) for p in watched}
    for ex in EXAMPLES:
        post(client, "Totally different text about llamas and the use of the term.", ex["id"],
             allow=True)
    assert {p: _digest(p) for p in watched} == before


@pytest.mark.parametrize("tail,code", [
    ("topics(grams, k = 50);", "WEB002"),
    ("topics(grams, k = 3, iterations = 5000);", "WEB002"),
    ("topics(grams, k = 3, top = 100);", "WEB002"),
    ("\n".join(["phrases(grams);"] * 7), "WEB003"),
])
def test_cost_limits(client, tail, code):
    script = ('let raw = load("input.txt");\nlet t = raw | tokenize | lower;\n'
              "let grams = t | ngrams(1, 2);\n" + tail)
    d = client.post("/api/analyze", json={"text": "a b c", "script": script}).get_json()
    assert code in [g["code"] for g in d["static"]["diagnostics"]]
    assert not d["execution"]["executed"]


def test_no_state_is_shared_between_requests(client):
    a = post(client, "alpha beta gamma").get_json()
    b = post(client, "delta epsilon").get_json()
    assert {p["phrase"] for p in a["phrases"]}.isdisjoint({p["phrase"] for p in b["phrases"]})
    import adjcheck.web as web_pkg
    import adjcheck.web.service as svc
    import adjcheck.webapp as shim
    # the old interface kept downloads in a module-level LATEST dict shared by all users
    assert not any(hasattr(m, "LATEST") for m in (web_pkg, svc, shim))


def test_small_limits_are_enforced_by_service():
    with pytest.raises(Exception) as e:
        analyze("x" * 11, SCRIPTS["safe"], limits=Limits(max_text_chars=10))
    assert getattr(e.value, "code", "") == "TEXT_TOO_LARGE"


# -- upload ---------------------------------------------------------------------------------

def upload(client, name, data):
    return client.post("/api/upload", data={"file": (io.BytesIO(data), name)},
                       content_type="multipart/form-data")


def test_upload_txt(client):
    r = upload(client, "notes.TXT", "﻿Denial of service.\r\n\r\nSecond doc.".encode())
    d = r.get_json()
    assert r.status_code == 200 and d["text"].startswith("Denial") and d["filename"] == "notes.TXT"


@pytest.mark.parametrize("name,data,code,status", [
    ("notes.pdf", b"%PDF-1.4", "UPLOAD_TYPE", 400),
    ("notes.txt.exe", b"MZ", "UPLOAD_TYPE", 400),
    ("image.txt", b"\x89PNG\x00\x00", "UPLOAD_BINARY", 400),
    ("latin.txt", "café".encode("latin-1"), "UPLOAD_ENCODING", 400),
    ("empty.txt", b"   ", "TEXT_EMPTY", 400),
    ("big.txt", b"a" * (LIMITS.max_upload_bytes + 1), "UPLOAD_TOO_LARGE", 413),
], ids=["pdf", "exe", "binary", "latin-1", "blank", "oversized"])
# Explicit ids: pytest copies the test id into the PYTEST_CURRENT_TEST environment
# variable, and Windows rejects variables longer than 32,767 characters.
def test_upload_rejections(client, name, data, code, status):
    r = upload(client, name, data)
    assert r.status_code == status and r.get_json()["error"]["code"] == code


def test_upload_missing_file(client):
    r = client.post("/api/upload", data={}, content_type="multipart/form-data")
    assert r.status_code == 400 and r.get_json()["error"]["code"] == "UPLOAD_MISSING"


def test_upload_over_request_limit(client):
    r = upload(client, "huge.txt", b"a" * (LIMITS.max_request_bytes + 100))
    assert r.status_code == 413


# -- fix endpoint, errors, independence -----------------------------------------------------------

def test_fix_endpoint(client):
    d = client.post("/api/fix", json={"script": SCRIPTS["unsafe"]}).get_json()
    assert d["ok"] and d["changed"] and compile_source(d["script"]).ok
    d = client.post("/api/fix", json={"script": SCRIPTS["safe"]}).get_json()
    assert d["ok"] and not d["changed"]


def test_unknown_api_route_returns_json_404(client):
    r = client.get("/api/nope")
    assert r.status_code == 404 and r.get_json()["error"]["code"] == "HTTP_404"
    assert client.get("/api/analyze").status_code == 405


def test_validator_still_independent_of_web_layer():
    import ast
    src = (ROOT / "src/adjcheck/validator.py").read_text()
    mods = {n.module for n in ast.walk(ast.parse(src)) if isinstance(n, ast.ImportFrom)}
    assert not any(m and ("web" in m or "executor" in m or "compiler" in m) for m in mods)
