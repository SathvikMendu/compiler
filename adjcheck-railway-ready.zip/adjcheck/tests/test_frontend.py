"""Lexer, parser, semantic analysis."""
import pytest

from adjcheck.ast_nodes import Let, PolicyStmt, SinkStmt
from adjcheck.compiler import compile_source
from adjcheck.diagnostics import CompileError
from adjcheck.lexer import T, tokenize
from adjcheck.parser import parse

GOOD = '''# comment
policy connectors(of, the);
let raw = load("data/sample.txt");
let toks = raw | tokenize | lower;
let clean = toks | remove(stopwords, keep_gaps);
let grams = clean | ngrams(1, 2);
topics(grams, k = 5) -> "outputs/t.csv";
'''


def codes(src):
    return compile_source(src).codes()


# -- lexer ---------------------------------------------------------------------

def test_lexer_kinds_and_locations():
    toks = tokenize('let a = load("x.txt") | ngrams(1, 2);')
    kinds = [t.kind for t in toks]
    assert kinds[:6] == [T.LET, T.IDENT, T.EQ, T.IDENT, T.LPAREN, T.STRING]
    assert toks[5].value == "x.txt"
    assert (toks[0].loc.line, toks[0].loc.col) == (1, 1)
    assert toks[-1].kind is T.EOF


def test_lexer_tracks_lines_and_skips_comments():
    toks = tokenize("# c\n\n  let x")
    assert toks[0].kind is T.LET and (toks[0].loc.line, toks[0].loc.col) == (3, 3)


def test_lexer_numbers_and_arrow():
    toks = tokenize("k = 5 -> 2.5")
    assert [t.kind for t in toks[:5]] == [T.IDENT, T.EQ, T.INT, T.ARROW, T.FLOAT]
    assert toks[2].value == 5 and toks[4].value == 2.5


@pytest.mark.parametrize("src,code", [("let a = @;", "LEX001"), ('load("abc', "LEX002")])
def test_lexer_errors(src, code):
    with pytest.raises(CompileError) as e:
        tokenize(src)
    assert e.value.diagnostic.code == code


# -- parser ----------------------------------------------------------------------

def test_parse_valid_program():
    prog = parse(GOOD)
    kinds = [type(s) for s in prog.stmts]
    assert kinds == [PolicyStmt, Let, Let, Let, Let, SinkStmt]
    assert prog.stmts[0].words == ["of", "the"]
    pipe = prog.stmts[2].expr
    assert [op.name for op in pipe.ops] == ["tokenize", "lower"]
    sink = prog.stmts[-1]
    assert sink.output == "outputs/t.csv" and sink.call.args[1].keyword == "k"


@pytest.mark.parametrize("src,line,col", [
    ("let a = load(\"x\")", 1, 18),                 # missing ';'
    ("let = load(\"x\");", 1, 5),                   # missing name
    ("let a load(\"x\");", 1, 7),                   # missing '='
    ("let a = load(\"x\") | ;", 1, 21),             # missing op
    ("phrases g;", 1, 9),                           # sink without parens
    ("let a = b | f(1,);", 1, 17),                  # trailing comma
])
def test_syntax_errors_have_locations(src, line, col):
    res = compile_source(src)
    assert res.codes() == ["SYN001"]
    d = res.diagnostics[0]
    assert (d.loc.line, d.loc.col) == (line, col)


def test_records_rparen_offset_for_rewrite():
    src = 'let a = x | remove(stopwords);'
    call = parse(src).stmts[0].expr.ops[0]
    assert src[call.rparen_offset] == ")"


# -- semantic analysis -----------------------------------------------------------------

def test_good_program_has_no_errors():
    res = compile_source(GOOD)
    assert res.ok and res.analysed


def test_undefined_stream():
    assert "SEM001" in codes('let a = nope | lower;\nphrases(a);')


def test_redefined_stream():
    src = 'let a = load("x");\nlet a = load("y");\nlet t = a | tokenize | ngrams(1);\nphrases(t);'
    assert "SEM002" in codes(src)


def test_unknown_operation_and_sink():
    c = codes('let a = load("x") | tokenize | frobnicate;\nexport(a);')
    assert c.count("SEM003") == 2


def test_sink_used_as_pipe_stage_is_explained():
    res = compile_source('let a = load("x") | tokenize | ngrams(2) | phrases;')
    msg = [d.message for d in res.diagnostics if d.code == "SEM003"][0]
    assert "sinks must be statements" in msg


@pytest.mark.parametrize("src", [
    'let a = load("x") | ngrams(2);\nphrases(a);',                       # TEXT into ngrams
    'let a = load("x") | tokenize;\nphrases(a);',                        # TOKENS into sink
    'let a = load("x");\nlet b = merge(a, a);\nlet g = b | ngrams(2);\nphrases(g);',
])
def test_type_errors(src):
    assert "SEM005" in codes(src)


@pytest.mark.parametrize("src,code", [
    ('let a = load(1);', "SEM004"),
    ('let a = load("x") | tokenize | lower(3);', "SEM004"),
    ('let a = load("x") | tokenize | remove(verbs);', "SEM006"),
    ('let a = load("x") | tokenize | remove(stopwords, quickly);', "SEM006"),
    ('let a = load("x") | tokenize | ngrams(3, 2);', "SEM006"),
    ('let a = load("x") | tokenize | ngrams(1, 9);', "SEM006"),
    ('let a = load("x") | tokenize | ngrams("2");', "SEM006"),
    ('policy fuzzy;', "SEM006"),
    ('policy connectors;', "SEM006"),
    ('policy strict;\npolicy strict;', "SEM008"),
])
def test_argument_and_policy_errors(src, code):
    assert code in codes(src)


def test_topics_requires_k_and_rejects_unknown_keywords():
    base = 'let g = load("x") | tokenize | ngrams(1);\n'
    assert "SEM004" in codes(base + "topics(g);")
    assert "SEM004" in codes(base + "topics(g, k = 3, colour = 2);")
    assert "SEM006" in codes(base + "topics(g, k = 0);")


def test_unused_stream_and_missing_sink_are_warnings():
    res = compile_source('let a = load("x") | tokenize;')
    assert {"SEM007", "SEM009"} <= set(res.codes()) and res.ok


def test_analysis_skipped_on_semantic_errors():
    res = compile_source('let a = nope | remove(stopwords) | ngrams(2);\nphrases(a);')
    assert not res.analysed and "ADJ001" not in res.codes()
