"""WSGI entry point for production hosting (Railway/Gunicorn)."""
from adjcheck.web import create_app

app = create_app()
