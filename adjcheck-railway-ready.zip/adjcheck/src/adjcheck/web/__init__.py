"""Flask web interface for AdjCheck (optional: pip install -e ".[web]").

Routes
  GET  /              the single-page interface
  GET  /api/examples  example pipelines (actual DSL, bound to input.txt) + sample text
  POST /api/analyze   JSON {text, script, allow_unsafe} -> full analysis result
  POST /api/upload    multipart file=<.txt> -> {text, filename, chars}
  POST /api/fix       JSON {script} -> safe-rewrite suggestion

All analysis is done by `service.analyze`, which calls the project's compiler,
executor and PhraseProof verifier. The server keeps no per-user state.
"""
from __future__ import annotations

import argparse
import ipaddress
import sys

from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge

from .service import EXAMPLES, LIMITS, SAMPLE_TEXT, InputError, analyze, decode_upload, \
    suggest_fix


def create_app(limits=LIMITS) -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = limits.max_request_bytes
    app.json.ensure_ascii = False
    app.json.sort_keys = False

    def json_body() -> dict:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise InputError("BAD_REQUEST", "Send a JSON object.")
        return data

    @app.errorhandler(InputError)
    def _input_error(e: InputError):
        return jsonify(e.to_json()), e.status

    @app.errorhandler(RequestEntityTooLarge)
    def _too_large(_e):
        return jsonify({"error": {"code": "REQUEST_TOO_LARGE",
                                  "message": f"The request exceeds "
                                             f"{limits.max_request_bytes // 1024} KB."}}), 413

    @app.errorhandler(HTTPException)
    def _http_error(e: HTTPException):
        if request.path.startswith("/api/"):
            return jsonify({"error": {"code": f"HTTP_{e.code}", "message": e.description}}), e.code
        return e

    @app.get("/")
    def index():
        return render_template("index.html", limits=limits)

    @app.get("/api/examples")
    def examples():
        return jsonify({"examples": EXAMPLES, "sample_text": SAMPLE_TEXT,
                        "limits": limits.to_json()})

    @app.post("/api/analyze")
    def api_analyze():
        data = json_body()
        allow = data.get("allow_unsafe", False)
        if not isinstance(allow, bool):
            raise InputError("BAD_REQUEST", "allow_unsafe must be true or false.")
        return jsonify(analyze(data.get("text"), data.get("script"), allow, limits))

    @app.post("/api/upload")
    def api_upload():
        f = request.files.get("file")
        if f is None:
            raise InputError("UPLOAD_MISSING", "Choose a .txt file to upload.")
        data = f.stream.read(limits.max_upload_bytes + 1)
        text = decode_upload(f.filename or "", data, limits)
        return jsonify({"text": text, "filename": f.filename, "chars": len(text)})

    @app.post("/api/fix")
    def api_fix():
        return jsonify(suggest_fix(json_body().get("script")))

    @app.after_request
    def _headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        return resp

    return app


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="adjcheck-web",
                                description="Run the AdjCheck web interface locally.")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5000)
    a = p.parse_args(argv)
    try:
        local = ipaddress.ip_address(a.host).is_loopback
    except ValueError:
        local = a.host == "localhost"
    if not local:
        print("warning: serving beyond this computer. This is Flask's development server "
              "with no authentication; use it only on a trusted network.", file=sys.stderr)
    print(f"AdjCheck web interface: http://{a.host}:{a.port}  (Ctrl+C to stop)")
    create_app().run(host=a.host, port=a.port, debug=False, threaded=True)
    return 0
