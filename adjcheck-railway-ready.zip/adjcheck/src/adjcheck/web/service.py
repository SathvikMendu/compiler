"""Web service layer: runs the real AdjCheck pipeline on user-supplied text.

This module is deliberately free of Flask so it can be tested directly. It
uses the project's own components and nothing else:

    compile_source  (lexer -> parser -> semantic analysis -> IR -> data-flow)
    rewrite         (keep_gaps safe rewrite, for the suggested fix)
    Executor        (offset-carrying execution, certificate generation)
    verify          (PhraseProof; imports only contract.py)

Sandboxing rules for user scripts (the DSL has no eval, imports or shell
access, but `load` and sink paths name files):

  * every load(...) must read "input.txt"; that name is bound to a fresh
    temporary file containing exactly the text the user submitted (WEB001);
  * every sink's output path is replaced by a file inside the same temporary
    directory, so nothing outside it is read or written;
  * size and cost limits are enforced before anything runs (WEB002-WEB004).

Nothing is stored between requests: each call gets its own temporary
directory, and every result is returned in the response.
"""
from __future__ import annotations

import csv
import io
import tempfile
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from ..compiler import compile_source
from ..diagnostics import Diagnostic, Severity
from ..executor import ExecutionError, Executor
from ..ir import SINKS
from ..rewrite import rewrite
from ..validator import ACCEPTED, REJECTED, UNCERTIFIED, verify

INPUT_NAME = "input.txt"


@dataclass(frozen=True)
class Limits:
    max_text_chars: int = 50_000
    max_script_chars: int = 4_000
    max_upload_bytes: int = 200_000
    max_request_bytes: int = 512 * 1024
    max_sinks: int = 6
    max_topic_k: int = 10
    max_topic_iterations: int = 300
    max_topic_top: int = 20

    def to_json(self) -> dict:
        return dict(self.__dict__)


LIMITS = Limits()


class InputError(Exception):
    """Invalid user input; reported as HTTP 400 (or 413 for size)."""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status

    def to_json(self) -> dict:
        return {"error": {"code": self.code, "message": self.message}}


# -- example pipelines (the same DSL as examples/*.adj, bound to input.txt) ------------

EXAMPLES = [
    {
        "id": "safe",
        "title": "Gap-aware (recommended)",
        "summary": "Removed stop words leave gap markers, so no n-gram can span them.",
        "allow_unsafe": False,
        "script": (
            "# Gap-aware pipeline: removed stop words become phrase boundaries.\n"
            "policy strict;\n"
            'let raw = load("input.txt");\n'
            "let toks = raw | tokenize | lower;\n"
            "let clean = toks | remove(stopwords, keep_gaps);\n"
            "let grams = clean | ngrams(1, 2);\n"
            'phrases(grams) -> "phrases.csv";\n'
            'topics(grams, k = 3) -> "topics.csv";\n'
        ),
    },
    {
        "id": "unsafe",
        "title": "NOC order (unsafe)",
        "summary": "Stop words are removed before n-grams, as in the reference's documented "
                   "module order. The static check reports ADJ001.",
        "allow_unsafe": True,
        "script": (
            "# NOC-style order: stop words removed BEFORE n-grams, no gap markers.\n"
            'let raw = load("input.txt");\n'
            "let toks = raw | tokenize | lower;\n"
            "let clean = toks | remove(stopwords);\n"
            "let grams = clean | ngrams(1, 2);\n"
            'phrases(grams) -> "phrases.csv";\n'
            'topics(grams, k = 3) -> "topics.csv";\n'
        ),
    },
    {
        "id": "connectors",
        "title": "Connector-aware",
        "summary": "“of” and “the” may sit inside a phrase, so "
                   "“denial of service” is kept as written.",
        "allow_unsafe": False,
        "script": (
            "# Connector policy: listed words may appear inside a phrase, never at its ends.\n"
            "policy connectors(of, the);\n"
            'let raw = load("input.txt");\n'
            "let toks = raw | tokenize | lower;\n"
            "let clean = toks | remove(stopwords, keep_gaps);\n"
            "let grams = clean | ngrams(1, 2);\n"
            'phrases(grams) -> "phrases.csv";\n'
        ),
    },
    {
        "id": "branches",
        "title": "Branches and merge",
        "summary": "An unsafe and a safe branch are merged; the merge inherits BROKEN. "
                   "A features-only sink is reported at info level.",
        "allow_unsafe": True,
        "script": (
            "# Two branches joined by merge: the analysis joins their states (max).\n"
            'let raw = load("input.txt");\n'
            "let toks = raw | tokenize | lower;\n"
            "let a = toks | remove(stopwords);\n"
            "let b = toks | remove(numbers, keep_gaps);\n"
            "let both = merge(a, b);\n"
            "let g_safe = b | ngrams(2);\n"
            "let g_both = both | ngrams(2);\n"
            "let g_feat = a | ngrams(2);\n"
            'phrases(g_safe) -> "branch_safe.csv";\n'
            'phrases(g_both) -> "branch_merged.csv";\n'
            'features(g_feat) -> "branch_features.csv";\n'
        ),
    },
    {
        "id": "untracked",
        "title": "Lost provenance",
        "summary": "expand_contractions splits words without offsets. Affected n-grams are "
                   "reported as UNCERTIFIED, never accepted.",
        "allow_unsafe": False,
        "script": (
            "# expand_contractions has no offset mapping: the stream becomes UNTRACKED.\n"
            'let raw = load("input.txt");\n'
            "let toks = raw | tokenize | lower | expand_contractions;\n"
            "let grams = toks | ngrams(2);\n"
            'phrases(grams) -> "untracked.csv";\n'
        ),
    },
]

SAMPLE_TEXT = (
    "The use of the term improved clarity.\n\n"
    "We use term frequency to rank the documents.\n\n"
    "Denial of service attacks overwhelm a server. A denial of service attack can be "
    "distributed across many machines.\n\n"
    "Analysts read the reports and later read reports again.\n\n"
    "Users don't trust the system, and it's slow."
)


# -- input validation --------------------------------------------------------------------

_ALLOWED_CONTROLS = {"\n", "\r", "\t", "\f"}


def validate_text(text, limits: Limits = LIMITS) -> str:
    if not isinstance(text, str):
        raise InputError("TEXT_INVALID", "Text must be a string.")
    if not text.strip():
        raise InputError("TEXT_EMPTY", "Enter or upload some text to analyse.")
    if len(text) > limits.max_text_chars:
        raise InputError("TEXT_TOO_LARGE",
                         f"Text is {len(text):,} characters; the limit is "
                         f"{limits.max_text_chars:,}.", status=413)
    bad = next((c for c in text if unicodedata.category(c) == "Cc"
                and c not in _ALLOWED_CONTROLS), None)
    if bad is not None:
        raise InputError("TEXT_BINARY", f"Text contains a control character (U+{ord(bad):04X}); "
                                        "only plain text is accepted.")
    return text


def validate_script(script, limits: Limits = LIMITS) -> str:
    if not isinstance(script, str):
        raise InputError("SCRIPT_INVALID", "The pipeline script must be a string.")
    if not script.strip():
        raise InputError("SCRIPT_EMPTY", "Enter a pipeline script, or choose an example.")
    if len(script) > limits.max_script_chars:
        raise InputError("SCRIPT_TOO_LARGE",
                         f"Script is {len(script):,} characters; the limit is "
                         f"{limits.max_script_chars:,}.", status=413)
    return script


def decode_upload(filename: str, data: bytes, limits: Limits = LIMITS) -> str:
    """Accept only UTF-8 .txt files within the size limit; return their text."""
    name = (filename or "").strip()
    if not name:
        raise InputError("UPLOAD_MISSING", "Choose a .txt file to upload.")
    if Path(name).suffix.lower() != ".txt":
        raise InputError("UPLOAD_TYPE", "Only .txt files are accepted.")
    if len(data) > limits.max_upload_bytes:
        raise InputError("UPLOAD_TOO_LARGE",
                         f"File is {len(data):,} bytes; the limit is "
                         f"{limits.max_upload_bytes:,}.", status=413)
    if b"\x00" in data:
        raise InputError("UPLOAD_BINARY", "The file looks binary; upload plain UTF-8 text.")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise InputError("UPLOAD_ENCODING", "The file is not valid UTF-8 text.") from None
    return validate_text(text, limits)


# -- web-specific checks on a compiled module ---------------------------------------------

def _web_checks(module, limits: Limits) -> list[Diagnostic]:
    diags = []
    sinks = [n for n in module.nodes if n.op in SINKS]
    for node in module.nodes:
        if node.op == "load" and node.args.get("path") != INPUT_NAME:
            diags.append(Diagnostic(
                "WEB001", Severity.ERROR,
                f'in the web interface load(...) must read "{INPUT_NAME}", which is the text '
                f"you entered; got {node.args.get('path')!r}", node.loc,
                fix=f'load("{INPUT_NAME}")'))
        if node.op == "topics":
            k, it, top = (node.args.get("k", 0), node.args.get("iterations", 300),
                          node.args.get("top", 8))
            if k > limits.max_topic_k or it > limits.max_topic_iterations \
                    or top > limits.max_topic_top:
                diags.append(Diagnostic(
                    "WEB002", Severity.ERROR,
                    f"topics limits in the web interface: k <= {limits.max_topic_k}, "
                    f"iterations <= {limits.max_topic_iterations}, top <= "
                    f"{limits.max_topic_top}", node.loc))
    if len(sinks) > limits.max_sinks:
        diags.append(Diagnostic("WEB003", Severity.ERROR,
                                f"at most {limits.max_sinks} sinks per script in the web "
                                f"interface; this script has {len(sinks)}", sinks[0].loc))
    return diags


# -- serialisation helpers ------------------------------------------------------------------

def _diag_json(d: Diagnostic) -> dict:
    return {"code": d.code, "severity": d.severity.value, "message": d.message,
            "line": d.loc.line, "col": d.loc.col, "notes": list(d.notes), "fix": d.fix}


def _states_json(res) -> list[dict]:
    if not res.analysed:
        return []
    return [{"line": n.loc.line, "col": n.loc.col, "op": n.op, "stream": n.label or "",
             "state": res.states[n.id].name}
            for n in res.module.nodes if n.id in res.states]


def _verdicts_csv(rows: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["stream", "occurrence_id", "doc_id", "phrase", "status", "check", "spans",
                "detail"])
    for r in rows:
        spans = ";".join(f"{s}-{e}" for s, e in r["spans"]) if r["spans"] else ""
        w.writerow([r["stream"], "" if r["occurrence_id"] is None else r["occurrence_id"],
                    r["doc_id"], " ".join(r["phrase"]), r["status"], r["code"], spans,
                    r["detail"]])
    return buf.getvalue()


def _topics_table(csv_text: str) -> list[dict]:
    topics: dict[int, list] = defaultdict(list)
    for row in csv.DictReader(io.StringIO(csv_text)):
        topics[int(row["topic"])].append({"term": row["term"],
                                          "probability": float(row["probability"])})
    return [{"topic": t, "terms": terms} for t, terms in sorted(topics.items())]


# -- main entry points --------------------------------------------------------------------

def suggest_fix(script: str) -> dict:
    """Run the project's rewrite pass; return the rewritten script or the reason it can't."""
    validate_script(script)
    rw = rewrite(script)
    return {"ok": rw.ok, "changed": bool(rw.ok and rw.rewritten != script),
            "script": rw.rewritten if rw.ok else None, "changes": rw.changes,
            "diagnostics": [_diag_json(d) for d in rw.diagnostics]}


def analyze(text, script, allow_unsafe: bool = False, limits: Limits = LIMITS) -> dict:
    text = validate_text(text, limits)
    script = validate_script(script, limits)

    res = compile_source(script)
    diags = list(res.diagnostics)
    web_diags = _web_checks(res.module, limits) if res.analysed else []
    diags += web_diags
    diags.sort(key=lambda d: (d.loc.line, d.loc.col))

    static_errors = [d for d in res.diagnostics if d.severity is Severity.ERROR]
    out = {
        "static": {
            "analysed": res.analysed,
            "diagnostics": [_diag_json(d) for d in diags],
            "states": _states_json(res),
            "policy": res.module.policy.to_json() if res.analysed else None,
            "errors": sum(d.severity is Severity.ERROR for d in diags),
            "warnings": sum(d.severity is Severity.WARNING for d in diags),
            "hazards": sorted({d.code for d in diags if d.code.startswith("ADJ")}),
        },
        "fix": None,
        "execution": {"executed": False, "reason": ""},
        "documents": [],
        "verification": None,
        "phrases": [],
        "outputs": [],
        "topics": [],
        "certificates": None,
        "limits": limits.to_json(),
    }
    if out["static"]["hazards"]:
        out["fix"] = suggest_fix(script)

    # -- decide whether to execute ---------------------------------------------------
    if not res.analysed:
        out["execution"]["reason"] = ("The script has syntax or semantic errors, so it was "
                                      "not analysed or run. Fix the errors listed above.")
        return out
    if web_diags:
        out["execution"]["reason"] = ("The script breaks a web-interface rule (WEB codes "
                                      "above), so it was not run.")
        return out
    if static_errors and not allow_unsafe:
        out["execution"]["reason"] = ("The static check reported errors, so the pipeline was "
                                      "not run. Apply the suggested fix, or enable “Run even "
                                      "if the static check fails” to see what PhraseProof "
                                      "does with the output.")
        return out

    # -- execute in an isolated temporary directory -------------------------------------
    with tempfile.TemporaryDirectory(prefix="adjcheck-web-") as td:
        base = Path(td)
        corpus = base / INPUT_NAME
        corpus.write_bytes(text.encode("utf-8"))
        sink_names = {}
        for node in res.module.nodes:
            if node.op in SINKS:
                name = f"{node.op}_line{node.loc.line}.csv"
                node.output = name                      # never the user-supplied path
                sink_names[name] = (node.op, node.call.args[0].value.ident
                                    if node.call and node.call.args else "")
        try:
            result = Executor(res.module, base_dir=base).run()
        except (ExecutionError, OSError, ValueError) as exc:
            out["execution"]["reason"] = f"Execution failed: {exc}"
            return out
        report = verify(result.certificates, corpus)
        files = {}
        for name, (op, stream) in sink_names.items():
            content = (base / name).read_text(encoding="utf-8")
            files[name] = content
            out["outputs"].append({"name": name, "sink": op, "stream": stream,
                                   "content": content})
            if op == "topics":
                out["topics"].append({"stream": stream, "file": name,
                                      "topics": _topics_table(content)})

    out["execution"] = {"executed": True,
                        "reason": "Ran despite static errors (requested)." if static_errors
                        else ""}
    out["documents"] = [{"doc_id": d.doc_id, "text": d.text, "sha256": d.sha256,
                         "length": len(d.text)} for d in result.documents]
    out["certificates"] = result.certificates

    # -- occurrence verdicts, joined to certificates by (stream, occurrence id) ------------
    by_id = {(s["stream"], c["id"]): c for s in result.certificates["streams"]
             for c in s["occurrences"]}
    rows = []
    for v in report.verdicts:
        cert = by_id.get((v.stream, v.occurrence_id)) if v.occurrence_id is not None else None
        rows.append({"stream": v.stream, "occurrence_id": v.occurrence_id, "doc_id": v.doc_id,
                     "phrase": v.phrase, "status": v.status, "code": v.code,
                     "detail": v.detail, "spans": cert["spans"] if cert else []})
    summary = report.summary()
    out["verification"] = {
        "summary": summary,
        "clean": report.clean,
        "rejections_by_check": dict(sorted(report.rejection_codes().items())),
        "count_issues": report.count_issues,
        "file_issues": report.file_issues,
        "occurrences": rows,
        "verdicts_csv": _verdicts_csv(rows),
        "report": report.to_json(),
    }

    # -- per-phrase aggregation -----------------------------------------------------
    agg: dict[tuple, dict] = {}
    for s in result.certificates["streams"]:
        for phrase, n in s["counts"].items():
            agg[(s["stream"], phrase)] = {"stream": s["stream"], "phrase": phrase,
                                          "words": len(phrase.split()), "reported": n,
                                          ACCEPTED: 0, REJECTED: 0, UNCERTIFIED: 0}
    for r in rows:
        key = (r["stream"], " ".join(r["phrase"]))
        entry = agg.setdefault(key, {"stream": r["stream"], "phrase": key[1],
                                     "words": len(r["phrase"]), "reported": 0,
                                     ACCEPTED: 0, REJECTED: 0, UNCERTIFIED: 0})
        entry[r["status"]] += 1
    out["phrases"] = sorted(agg.values(),
                            key=lambda e: (e["stream"], -e["reported"], e["phrase"]))
    return out
