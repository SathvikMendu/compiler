/* AdjCheck web interface. All analysis happens on the server, in the project's
   own compiler, executor and PhraseProof verifier; this file only sends input
   and renders the response. User text is always inserted with textContent. */
"use strict";

(() => {
  const $ = (sel) => document.querySelector(sel);
  const body = document.body;
  const MAX_TEXT = Number(body.dataset.maxText);
  const MAX_UPLOAD = Number(body.dataset.maxUpload);
  const MAX_SCRIPT = Number(body.dataset.maxScript);
  const ROW_LIMIT = 600;

  const els = {
    form: $("#analyze-form"), text: $("#text"), script: $("#script"), example: $("#example"),
    summary: $("#example-summary"), allow: $("#allow-unsafe"), run: $("#run"), status: $("#status"),
    file: $("#file"), fileName: $("#file-name"), sample: $("#sample"), reset: $("#reset-script"),
    count: $("#text-count"), empty: $("#empty"), output: $("#output"), results: $("#results"),
  };
  let examples = [];
  let sampleText = "";
  let last = null;           // last analysis response
  let lastScript = "";
  let lastText = "";

  // ---------- small DOM helper ----------
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "text") el.textContent = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) {
      if (kid === null || kid === undefined || kid === false) continue;
      el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }
  const fmt = (n) => Number(n).toLocaleString("en");
  const plural = (n, one, many) => `${fmt(n)} ${n === 1 ? one : (many || one + "s")}`;

  function setStatus(msg, kind) {
    els.status.textContent = msg;
    els.status.className = "status" + (kind ? " " + kind : "");
  }

  // ---------- input side ----------
  function updateCount() {
    const n = els.text.value.length;
    els.count.textContent = `${fmt(n)} / ${fmt(MAX_TEXT)}`;
    const over = n > MAX_TEXT;
    els.count.classList.toggle("over", over);
    els.text.setAttribute("aria-invalid", over ? "true" : "false");
  }

  function currentExample() {
    return examples.find((e) => e.id === els.example.value);
  }

  function loadExample(id, keepText) {
    const ex = examples.find((e) => e.id === id);
    if (!ex) return;
    els.example.value = id;
    els.script.value = ex.script;
    els.summary.textContent = ex.summary;
    els.allow.checked = ex.allow_unsafe;
    if (!keepText && !els.text.value.trim()) els.text.value = sampleText;
    updateCount();
  }

  async function init() {
    try {
      const res = await fetch("/api/examples");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      examples = data.examples;
      sampleText = data.sample_text;
      for (const ex of examples) els.example.append(h("option", { value: ex.id, text: ex.title }));
      els.example.append(h("option", { value: "custom", text: "Custom (edited script)" }));
      loadExample("safe");
    } catch (err) {
      setStatus(`Could not load the example pipelines (${err.message}). Is the server running?`, "error");
    }
  }

  els.example.addEventListener("change", () => {
    if (els.example.value === "custom") return;
    loadExample(els.example.value, true);
  });
  els.script.addEventListener("input", () => {
    const ex = currentExample();
    if (ex && els.script.value !== ex.script) {
      els.example.value = "custom";
      els.summary.textContent = "Edited script. Choose an example to start over.";
    }
  });
  els.reset.addEventListener("click", () => {
    const id = els.example.value === "custom" ? "safe" : els.example.value;
    loadExample(id, true);
  });
  els.sample.addEventListener("click", () => {
    els.text.value = sampleText;
    els.fileName.textContent = "";
    updateCount();
    els.text.focus();
  });
  els.text.addEventListener("input", updateCount);

  els.file.addEventListener("change", async () => {
    const f = els.file.files[0];
    if (!f) return;
    els.fileName.textContent = "";
    if (!/\.txt$/i.test(f.name)) {
      setStatus("Only .txt files can be uploaded.", "error");
      els.file.value = "";
      return;
    }
    if (f.size > MAX_UPLOAD) {
      setStatus(`That file is ${fmt(f.size)} bytes; the limit is ${fmt(MAX_UPLOAD)}.`, "error");
      els.file.value = "";
      return;
    }
    const fd = new FormData();
    fd.append("file", f);
    setStatus("Reading file…", "busy");
    try {
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ? data.error.message : `HTTP ${res.status}`);
      els.text.value = data.text;
      els.fileName.textContent = `Loaded ${data.filename} (${plural(data.chars, "character")})`;
      updateCount();
      setStatus("File loaded. You can edit the text before running.", "done");
    } catch (err) {
      setStatus(`Upload failed: ${err.message}`, "error");
    } finally {
      els.file.value = "";
    }
  });

  els.form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const text = els.text.value;
    const script = els.script.value;
    if (!text.trim()) { setStatus("Enter or upload some text to analyse.", "error"); els.text.focus(); return; }
    if (text.length > MAX_TEXT) { setStatus(`Text is over the ${fmt(MAX_TEXT)}-character limit.`, "error"); els.text.focus(); return; }
    if (!script.trim()) { setStatus("Enter a pipeline script, or choose an example.", "error"); els.script.focus(); return; }
    if (script.length > MAX_SCRIPT) { setStatus(`Script is over the ${fmt(MAX_SCRIPT)}-character limit.`, "error"); return; }

    els.run.disabled = true;
    els.run.textContent = "Running…";
    els.results.setAttribute("aria-busy", "true");
    setStatus("Compiling, running and verifying…", "busy");
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, script, allow_unsafe: els.allow.checked }),
      });
      let data;
      try { data = await res.json(); } catch { throw new Error(`The server returned HTTP ${res.status}.`); }
      if (!res.ok) throw new Error(data.error ? data.error.message : `HTTP ${res.status}`);
      last = data; lastScript = script; lastText = text;
      render(data);
      const v = data.verification;
      setStatus(v ? `Done: ${plural(v.occurrences.length, "occurrence")} verified.`
                  : "Done: static check only (the pipeline was not run).", "done");
      if (window.matchMedia("(max-width: 1000px)").matches) els.results.focus();
    } catch (err) {
      setStatus(err.message, "error");
    } finally {
      els.run.disabled = false;
      els.run.textContent = "Run analysis";
      els.results.removeAttribute("aria-busy");
    }
  });

  // ---------- tabs ----------
  const tabs = Array.from(document.querySelectorAll('[role="tab"]'));
  function selectTab(tab, focus) {
    for (const t of tabs) {
      const on = t === tab;
      t.setAttribute("aria-selected", on ? "true" : "false");
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
    }
    if (focus) tab.focus();
  }
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => selectTab(t));
    t.addEventListener("keydown", (e) => {
      let j = null;
      if (e.key === "ArrowRight") j = (i + 1) % tabs.length;
      if (e.key === "ArrowLeft") j = (i - 1 + tabs.length) % tabs.length;
      if (e.key === "Home") j = 0;
      if (e.key === "End") j = tabs.length - 1;
      if (j !== null) { e.preventDefault(); selectTab(tabs[j], true); }
    });
  });
  function badge(tabId, n, bad) {
    const t = document.getElementById(tabId);
    t.querySelector(".badge")?.remove();
    if (n !== null && n !== undefined) t.append(h("span", { class: "badge" + (bad ? " bad" : ""), text: fmt(n) }));
  }

  // ---------- rendering ----------
  const STATE_CLASS = { SAFE: "s-safe", MARKED: "s-marked", BROKEN: "s-broken", UNTRACKED: "s-untracked" };
  const VERDICT_CLASS = { ACCEPTED: "v-accepted", REJECTED: "v-rejected", UNCERTIFIED: "v-uncertified" };
  const VERDICT_WORD = { ACCEPTED: "Accepted", REJECTED: "Rejected", UNCERTIFIED: "Uncertified" };
  const STATE_MEANING = {
    SAFE: "nothing removed",
    MARKED: "removals leave gap markers",
    BROKEN: "removals without gap markers",
    UNTRACKED: "word positions lost",
  };

  function render(d) {
    els.empty.hidden = true;
    els.output.hidden = false;
    renderSummary(d);
    renderStatic(d);
    renderOccurrences(d);
    renderPhrases(d);
    renderDocuments(d);
    renderTopics(d);
    renderDownloads(d);
    const hz = d.static.errors + d.static.warnings;
    badge("tab-static", hz || null, d.static.errors > 0);
    const v = d.verification;
    badge("tab-occ", v ? v.occurrences.length : null, v && v.summary.REJECTED > 0);
    badge("tab-phrases", d.phrases.length || null);
    badge("tab-docs", d.documents.length || null);
    badge("tab-topics", d.topics.reduce((a, t) => a + t.topics.length, 0) || null);
    selectTab(document.getElementById(v ? "tab-occ" : "tab-static"));
  }

  function renderSummary(d) {
    const box = $("#summary");
    box.replaceChildren();
    const s = d.static;
    let staticLine;
    if (!s.analysed) staticLine = h("p", { text: "The script did not compile. See Static check." });
    else if (s.errors) staticLine = h("p", { text: `${plural(s.errors, "error")} reported${s.hazards.length ? ` (${s.hazards.join(", ")})` : ""}.` });
    else if (s.warnings) staticLine = h("p", { text: `No errors, ${plural(s.warnings, "warning")}${s.hazards.length ? ` (${s.hazards.join(", ")})` : ""}.` });
    else staticLine = h("p", { text: "No hazards found." });
    box.append(h("div", { class: "verdict-line" }, h("h3", { text: "Static check" }), staticLine));

    const v = d.verification;
    if (!v) {
      box.append(h("div", { class: "notice warn" }, h("strong", { text: "Not run. " }), d.execution.reason));
      return;
    }
    const sm = v.summary;
    const cell = (cls, n, label) => h("div", { class: cls + (n === 0 ? " zero" : "") }, h("strong", { text: fmt(n) }), h("span", { text: label }));
    box.append(h("div", { class: "tally", role: "group", "aria-label": "Verification counts" },
      cell("t-accepted", sm.ACCEPTED, "Accepted"),
      cell("t-rejected", sm.REJECTED, "Rejected"),
      cell("t-uncertified", sm.UNCERTIFIED, "Uncertified"),
      cell("t-count", sm.count_mismatches, "Count mismatches")));

    let note;
    if (d.execution.reason) note = h("div", { class: "notice warn" }, h("strong", { text: "Note. " }), d.execution.reason);
    box.append(note || "");
    if (sm.REJECTED) {
      const codes = Object.entries(v.rejections_by_check).map(([c, n]) => `${c} ${fmt(n)}`).join(", ");
      box.append(h("div", { class: "notice bad" }, h("strong", { text: `${plural(sm.REJECTED, "occurrence")} rejected` }),
        ` (${codes}). These n-grams are not supported by your text. Open Occurrences and select one to see why.`));
    } else if (sm.UNCERTIFIED) {
      box.append(h("div", { class: "notice warn" }, h("strong", { text: `${plural(sm.UNCERTIFIED, "occurrence")} uncertified. ` }),
        "The pipeline lost track of where these words came from, so they could not be checked."));
    } else if (v.clean) {
      box.append(h("div", { class: "notice ok" }, h("strong", { text: "Every certificate checked out. " }),
        "Each reported occurrence points at adjacent words in your text. This does not show that no n-grams were left out."));
    }
    for (const f of v.file_issues) box.append(h("div", { class: "notice bad" }, h("strong", { text: "Certificate file issue: " }), f));
  }

  function renderStatic(d) {
    const p = $("#panel-static");
    p.replaceChildren();
    const s = d.static;
    p.append(h("h3", { text: "Diagnostics" }));
    if (!s.diagnostics.length) {
      p.append(h("p", { class: "help", text: "The compiler reported nothing: no syntax, type or adjacency problems." }));
    } else {
      p.append(h("ul", { class: "diags" }, s.diagnostics.map((g) => h("li", { class: "diag" },
        h("div", { class: "diag-head" },
          h("span", { class: `chip sev-${g.severity}`, text: g.severity }),
          h("span", { class: "diag-code", text: g.code }),
          h("span", { class: "diag-loc", text: `line ${g.line}, column ${g.col}` })),
        h("p", { text: g.message }),
        g.notes.length ? h("ul", {}, g.notes.map((n) => h("li", { text: n }))) : null,
        g.fix ? h("p", { class: "fix" }, h("strong", { text: "Fix: " }), g.fix) : null))));
    }

    if (d.fix) {
      const fx = d.fix;
      const box = h("div", { class: "fixbox" });
      if (fx.ok && fx.changed) {
        box.append(h("strong", { text: "AdjCheck rewrote the script and re-checked it: no hazards remain." }),
          h("p", { class: "help", text: fx.changes.join("; ") }),
          diffPre(lastScript, fx.script),
          h("button", { type: "button", class: "quiet", onclick: () => {
            els.script.value = fx.script;
            els.example.value = "custom";
            els.summary.textContent = "Rewritten by AdjCheck's safe-rewrite pass. Run again to check the result.";
            els.allow.checked = false;
            els.script.focus();
            setStatus("Fixed script loaded. Select Run analysis to check it.", "done");
          } }, "Use this script"));
      } else if (!fx.ok) {
        box.append(h("strong", { text: "No automatic fix" }),
          h("p", {}, fx.diagnostics.map((g) => g.message).join(" ") || "The rewrite pass does not support this case."));
      }
      if (box.childNodes.length) { p.append(h("h3", { text: "Suggested fix" }), box); }
    }

    p.append(h("h3", { text: "Stream states" }));
    if (!s.states.length) {
      p.append(h("p", { class: "help", text: "Not available: the data-flow analysis only runs on scripts without syntax or semantic errors." }));
      return;
    }
    p.append(h("p", { class: "help", text: "The state of each token stream after each operation, as computed by the data-flow analysis." }));
    p.append(h("div", { class: "table-wrap" }, h("table", { class: "data" },
      h("thead", {}, h("tr", {}, ["Location", "Operation", "Stream", "State"].map((t) => h("th", { scope: "col", text: t })))),
      h("tbody", {}, s.states.map((r) => h("tr", {},
        h("td", { class: "num", text: `${r.line}:${r.col}` }),
        h("td", {}, h("code", { text: r.op })),
        h("td", {}, r.stream ? h("code", { text: r.stream }) : h("span", { class: "zero-cell", text: "—" })),
        h("td", {}, h("span", { class: `chip ${STATE_CLASS[r.state]}`, text: r.state }), " ", h("span", { class: "help inline", text: STATE_MEANING[r.state] }))))))));
  }

  function diffPre(before, after) {
    // Mark inserted text (the rewrite only inserts ", keep_gaps").
    const pre = h("pre", {});
    let i = 0, j = 0;
    while (j < after.length) {
      if (before[i] === after[j]) {
        let k = j;
        while (k < after.length && before[i + (k - j)] === after[k]) k++;
        pre.append(after.slice(j, k)); i += k - j; j = k;
      } else {
        let k = j;
        while (k < after.length && before[i] !== after[k]) k++;
        pre.append(h("ins", { text: after.slice(j, k) })); j = k;
      }
    }
    return pre;
  }

  // ----- occurrences + proof view -----
  let occRows = [];
  let selectedKey = null;

  function renderOccurrences(d) {
    const v = d.verification;
    occRows = v ? v.occurrences.map((r, i) => ({ ...r, key: i, text: `${r.phrase.join(" ")} ${r.doc_id} ${r.code} ${r.detail}`.toLowerCase() })) : [];
    selectedKey = null;
    const streams = [...new Set(occRows.map((r) => r.stream))];
    const wrap = $("#occ-stream-wrap"), sel = $("#occ-stream");
    sel.replaceChildren(h("option", { value: "", text: "All streams" }), ...streams.map((s) => h("option", { value: s, text: s })));
    wrap.hidden = streams.length < 2;
    $("#occ-search").value = "";
    $("#occ-status").value = v && v.summary.REJECTED ? "REJECTED" : "";
    $("#proof").replaceChildren(h("p", { class: "help", text: v
      ? "Select a phrase in the table to see exactly where its words are in your text."
      : "The pipeline was not run, so there are no occurrences to show." }));
    drawOccurrences();
  }

  function drawOccurrences() {
    const q = $("#occ-search").value.trim().toLowerCase();
    const st = $("#occ-status").value;
    const sm = $("#occ-stream").value;
    const rows = occRows.filter((r) => (!st || r.status === st) && (!sm || r.stream === sm) && (!q || r.text.includes(q)));
    const tbody = $("#occ-table tbody");
    tbody.replaceChildren(...rows.slice(0, ROW_LIMIT).map((r) => h("tr", { class: r.key === selectedKey ? "selected" : "" },
      h("td", { class: "num", text: r.doc_id }),
      h("td", { class: "phrase" }, h("button", { type: "button", class: "phrase-btn", "aria-label": `Show ${r.phrase.join(" ")} in ${r.doc_id}`, onclick: (e) => selectOcc(r, e.currentTarget.closest("tr")) }, r.phrase.join(" "))),
      h("td", {}, h("span", { class: `chip ${VERDICT_CLASS[r.status]}`, text: VERDICT_WORD[r.status] })),
      h("td", {}, r.code ? h("span", { class: "code-cell", text: r.code }) : h("span", { class: "zero-cell", text: "All checks passed" }),
        r.detail ? h("span", { class: "why", text: r.detail }) : null))));
    const total = occRows.length;
    $("#occ-count").textContent = total === 0 ? "" :
      rows.length > ROW_LIMIT ? `Showing the first ${fmt(ROW_LIMIT)} of ${fmt(rows.length)} matching occurrences (${fmt(total)} in total). Refine the search to see more.`
      : `${fmt(rows.length)} of ${plural(total, "occurrence")}.`;
  }
  ["#occ-search", "#occ-status", "#occ-stream"].forEach((s) => $(s).addEventListener("input", drawOccurrences));

  function selectOcc(r, tr) {
    selectedKey = r.key;
    document.querySelectorAll("#occ-table tr.selected").forEach((x) => x.classList.remove("selected"));
    tr?.classList.add("selected");
    const doc = last.documents.find((x) => x.doc_id === r.doc_id);
    const proof = $("#proof");
    proof.replaceChildren(h("div", { class: "proof-head" },
      h("span", { class: "phrase-title", text: r.phrase.join(" ") }),
      h("span", { class: `chip ${VERDICT_CLASS[r.status]}`, text: VERDICT_WORD[r.status] }),
      h("span", { text: `document ${r.doc_id}` }),
      r.occurrence_id !== null ? h("span", { text: `occurrence #${r.occurrence_id}` }) : null));
    proof.append(galley(doc, r));
    proof.append(explain(r));
  }

  function galley(doc, r) {
    const g = h("p", { class: "galley" });
    if (!doc) { g.textContent = "Document not found."; return g; }
    const cps = Array.from(doc.text);          // code points, matching Python offsets
    const spans = r.spans || [];
    const valid = spans.length && spans.every(([s, e], i) => Number.isInteger(s) && Number.isInteger(e) && s >= 0 && s < e && e <= cps.length && (i === 0 || s >= spans[i - 1][1]));
    if (!valid) {
      g.append(h("span", { class: "ctx", text: spans.length ? "The certificate's positions are not valid for this document, so they cannot be shown." : "No positions recorded for this occurrence." }));
      return g;
    }
    const slice = (a, b) => cps.slice(a, b).join("");
    const CONTEXT = 160;
    const from = Math.max(0, spans[0][0] - CONTEXT), to = Math.min(cps.length, spans[spans.length - 1][1] + CONTEXT);
    if (from > 0) g.append(h("span", { class: "ctx", text: "…" + slice(from, spans[0][0]) }));
    else g.append(h("span", { class: "ctx", text: slice(0, spans[0][0]) }));
    const gapBad = r.status === "REJECTED" && r.code === "GAP_VIOLATION";
    const wordCls = r.status === "ACCEPTED" ? "w-ok" : r.status === "REJECTED" ? "w-bad" : "w-plain";
    spans.forEach(([s, e], i) => {
      g.append(h("mark", { class: wordCls, text: slice(s, e) }));
      if (i < spans.length - 1) {
        const gap = slice(e, spans[i + 1][0]);
        const bad = gapBad && gap.trim() !== "";
        g.append(bad ? h("span", { class: "gap-bad", title: "Not allowed between phrase words", text: gap }) : gap);
      }
    });
    g.append(h("span", { class: "ctx", text: slice(spans[spans.length - 1][1], to) + (to < cps.length ? "…" : "") }));
    return g;
  }

  function explain(r) {
    const p = h("p", { class: "proof-why" });
    if (r.status === "ACCEPTED") {
      p.append(h("strong", { text: "Accepted. " }), r.phrase.length > 1
        ? "These words are next to each other in your text, separated only by spaces, so the phrase really occurs here."
        : "This word occurs at the marked position in your text.");
    } else if (r.status === "REJECTED") {
      p.append(h("strong", { text: `Rejected (${r.code}). ` }), r.code === "GAP_VIOLATION"
        ? "The struck-through text sits between the phrase words in your text, so the pipeline joined words that were not adjacent. "
        : "", r.detail);
    } else {
      p.append(h("strong", { text: "Uncertified. " }), r.detail || "No certificate was produced for this occurrence.");
    }
    return p;
  }

  // ----- phrases -----
  let phraseRows = [];
  function renderPhrases(d) {
    phraseRows = d.phrases.map((p) => ({ ...p, lc: p.phrase.toLowerCase() }));
    $("#phrase-search").value = "";
    $("#phrase-len").value = "";
    $("#phrase-problem").checked = false;
    drawPhrases();
  }
  function drawPhrases() {
    const q = $("#phrase-search").value.trim().toLowerCase();
    const len = $("#phrase-len").value;
    const prob = $("#phrase-problem").checked;
    const multi = new Set(phraseRows.map((p) => p.stream)).size > 1;
    const rows = phraseRows.filter((p) => (!q || p.lc.includes(q)) && (!len || (len === "1" ? p.words === 1 : p.words > 1)) && (!prob || p.REJECTED || p.UNCERTIFIED || p.reported !== p.ACCEPTED + p.REJECTED + p.UNCERTIFIED));
    const n = (v, cls) => h("td", { class: "num " + (v ? cls : "zero-cell"), text: fmt(v) });
    $("#phrase-table tbody").replaceChildren(...rows.slice(0, ROW_LIMIT).map((p) => h("tr", {},
      h("td", { class: "phrase" }, p.phrase, multi ? h("span", { class: "help inline", text: `  ${p.stream}` }) : null),
      h("td", { class: "num", text: fmt(p.reported) }),
      n(p.ACCEPTED, ""), n(p.REJECTED, "bad-cell"), n(p.UNCERTIFIED, "amber-cell"))));
    $("#phrase-count").textContent = phraseRows.length === 0 ? "No phrases: the pipeline was not run." :
      rows.length > ROW_LIMIT ? `Showing the first ${fmt(ROW_LIMIT)} of ${fmt(rows.length)} matching phrases.` : `${fmt(rows.length)} of ${plural(phraseRows.length, "phrase")}.`;
  }
  ["#phrase-search", "#phrase-len", "#phrase-problem"].forEach((s) => $(s).addEventListener("input", drawPhrases));

  // ----- documents -----
  function renderDocuments(d) {
    const p = $("#panel-docs");
    p.replaceChildren();
    if (!d.documents.length) { p.append(h("p", { class: "help", text: "The pipeline was not run, so your text was not split into documents." })); return; }
    p.append(h("p", { class: "help", text: "Your text exactly as the pipeline and the verifier read it: line endings normalised, Unicode in NFC form, split at blank lines. Certificate positions count characters in these documents." }));
    p.append(h("div", { class: "docs" }, d.documents.map((doc) => h("article", { class: "doc" },
      h("div", { class: "doc-head" }, h("strong", { text: doc.doc_id }), h("span", { text: plural(doc.length, "character") }),
        h("span", { class: "hash", title: doc.sha256, text: `SHA-256 ${doc.sha256.slice(0, 16)}…` })),
      h("div", { class: "doc-body", text: doc.text })))));
  }

  // ----- topics -----
  function renderTopics(d) {
    const p = $("#panel-topics");
    p.replaceChildren();
    if (!d.topics.length) {
      p.append(h("p", { class: "help", text: d.verification ? "This script has no topics(...) sink." : "The pipeline was not run." }));
      return;
    }
    p.append(h("div", { class: "notice warn" }, h("strong", { text: "Not evaluated. " }),
      "These topics come from a small demonstration LDA sampler (fixed seed). Their quality has not been evaluated, and they include any rejected n-grams the pipeline produced."));
    for (const t of d.topics) {
      p.append(h("h3", { text: `Stream ${t.stream}` }));
      p.append(h("div", { class: "topics" }, t.topics.map((tp) => h("section", { class: "topic" },
        h("h4", { text: `Topic ${tp.topic + 1}` }),
        h("ol", {}, tp.terms.map((term) => h("li", {}, term.term, h("span", { class: "p", text: term.probability.toFixed(3) }))))))));
    }
  }

  // ----- downloads -----
  function download(name, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = h("a", { href: url, download: name });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function renderDownloads(d) {
    const p = $("#panel-downloads");
    p.replaceChildren();
    const items = [];
    const v = d.verification;
    for (const o of d.outputs) items.push([o.name, `${o.sink}(${o.stream}) output written by the pipeline`, () => o.content, "text/csv"]);
    if (d.certificates) items.push(["certificates.json", "Per-occurrence provenance certificates (input to PhraseProof)", () => JSON.stringify(d.certificates, null, 1), "application/json"]);
    if (v) {
      items.push(["verification-report.json", "PhraseProof's full verdict report", () => JSON.stringify(v.report, null, 1), "application/json"]);
      items.push(["occurrence-verdicts.csv", "One row per occurrence: verdict, check and character positions", () => v.verdicts_csv, "text/csv"]);
    }
    items.push(["pipeline.adj", "The script that was analysed", () => lastScript, "text/plain"]);
    items.push(["input.txt", "The text that was analysed", () => lastText, "text/plain"]);
    p.append(h("p", { class: "help", text: "Files are generated from this run in your browser. To re-check the certificates on the command line, save certificates.json and input.txt, then run: python -m adjcheck verify certificates.json --source input.txt" }));
    p.append(h("ul", { class: "downloads" }, items.map(([name, what, get, type]) => h("li", {},
      h("div", { class: "what" }, h("strong", { text: name }), h("span", { text: what })),
      h("button", { type: "button", class: "quiet", onclick: () => download(name, get(), type) }, "Download")))));
  }

  init();
  updateCount();
})();
