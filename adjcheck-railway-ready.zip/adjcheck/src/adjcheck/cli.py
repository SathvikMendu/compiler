"""Command-line interface: python -m adjcheck <command> ...

  parse   FILE [--tokens]          print tokens or the AST
  check   FILE                     static analysis; exit 1 if errors
  fix     FILE [-o OUT]            keep_gaps rewrite + re-check
  run     FILE [--certs PATH] [--allow-unsafe] [--fault NAME ...]
  verify  CERTS [--source PATH] [--json OUT] [--show N]
  faults  [--out PATH]             fault-injection matrix (measured)
  experiment [--out PATH]          unsafe vs gap-aware vs connector-aware
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .ast_nodes import dump
from .compiler import compile_source
from .diagnostics import CompileError, Severity
from .lexer import tokenize


def _read(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def _print_diags(diags, filename) -> None:
    for d in diags:
        print(d.render(filename))


def cmd_parse(a) -> int:
    src = _read(a.file)
    try:
        if a.tokens:
            for t in tokenize(src):
                print(repr(t))
            return 0
        res = compile_source(src)
    except CompileError as e:
        print(e.diagnostic.render(a.file))
        return 1
    if res.program is None:
        _print_diags(res.diagnostics, a.file)
        return 1
    print(dump(res.program))
    return 0


def cmd_check(a) -> int:
    res = compile_source(_read(a.file))
    _print_diags(res.diagnostics, a.file)
    if res.analysed:
        print("\nstream states (data-flow analysis):")
        for node in res.module.nodes:
            if node.id in res.states:
                name = node.label or ""
                print(f"  {node.loc!s:>6}  {node.op:<20} {res.states[node.id].name:<10} {name}")
    errors = sum(d.severity is Severity.ERROR for d in res.diagnostics)
    warns = sum(d.severity is Severity.WARNING for d in res.diagnostics)
    print(f"\n{a.file}: {errors} error(s), {warns} warning(s)")
    return 1 if errors else 0


def cmd_fix(a) -> int:
    from .rewrite import rewrite
    rw = rewrite(_read(a.file))
    _print_diags(rw.diagnostics, a.file)
    if not rw.ok:
        print("rewrite not applied")
        return 1
    for c in rw.changes:
        print(f"# {c}", file=sys.stderr)
    errors = [d for d in rw.recheck.diagnostics if d.severity is Severity.ERROR]
    print(f"# re-check: {len(errors)} error(s), "
          f"{sum(d.code == 'ADJ001' for d in rw.recheck.diagnostics)} ADJ001 hazard(s)",
          file=sys.stderr)
    if a.output:
        Path(a.output).parent.mkdir(parents=True, exist_ok=True)
        Path(a.output).write_text(rw.rewritten, encoding="utf-8")
        print(f"# written to {a.output}", file=sys.stderr)
    else:
        print(rw.rewritten, end="")
    return 0


def cmd_run(a) -> int:
    from .executor import ExecutionError, Executor
    from .provenance import write_certificates
    res = compile_source(_read(a.file))
    _print_diags(res.diagnostics, a.file)
    if not res.analysed:
        print("cannot run: fix syntax/semantic errors first")
        return 2
    if not res.ok and not a.allow_unsafe:
        print("refusing to run: static check reported errors (use --allow-unsafe to run anyway)")
        return 2
    try:
        result = Executor(res.module, base_dir=".", faults=set(a.fault or [])).run()
    except ExecutionError as e:
        print(f"execution error: {e}")
        return 2
    certs_path = a.certs or f"outputs/{Path(a.file).stem}_certificates.json"
    write_certificates(result.certificates, certs_path)
    if a.fault:
        print(f"[fault injection active: {', '.join(a.fault)}]")
    for s in result.certificates["streams"]:
        total = sum(s["counts"].values())
        print(f"stream {s['stream']}: {total} n-gram occurrence(s), "
              f"{len(s['occurrences'])} certificate(s), {len(s['uncertified'])} uncertified, "
              f"policy {s['policy']['kind']}")
    for o in result.outputs:
        print(f"wrote {o}")
    print(f"wrote {certs_path}")
    return 0


def cmd_verify(a) -> int:
    from .validator import ACCEPTED, REJECTED, load_certificates, verify
    certs = load_certificates(a.certs)
    source = a.source
    if source is None:
        source = certs.get("corpus", {}).get("path")
        print(f"note: using corpus path recorded in the certificate file ({source}); "
              "pass --source to verify against your own copy")
    rep = verify(certs, source)
    for issue in rep.file_issues:
        print(f"FILE ISSUE: {issue}")
    shown = 0
    for v in rep.verdicts:
        if v.status != ACCEPTED and shown < a.show:
            print(f"{v.status:<11} {v.code:<16} {v.doc_id:<4} {' '.join(v.phrase)!r}: {v.detail}")
            shown += 1
    for c in rep.count_issues[: a.show]:
        print(f"COUNT_MISMATCH   {c['stream']}: {c['phrase']!r} reported {c['reported']}, "
              f"occurrences {c['occurrences']}")
    s = rep.summary()
    print(f"\nsummary: {s['ACCEPTED']} accepted, {s['REJECTED']} rejected, "
          f"{s['UNCERTIFIED']} uncertified, {s['count_mismatches']} count mismatch(es), "
          f"{s['file_issues']} file issue(s)")
    if rep.rejection_codes():
        print("rejections by check: " + ", ".join(f"{k}={n}" for k, n in
                                                   sorted(rep.rejection_codes().items())))
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps(rep.to_json(), indent=1, ensure_ascii=False),
                                encoding="utf-8")
        print(f"wrote {a.json}")
    return 0 if rep.clean else 1


def cmd_faults(a) -> int:
    from .evaluation.faults import run_matrix
    print(run_matrix(a.out))
    return 0


def cmd_experiment(a) -> int:
    from .evaluation.experiment import run_experiment
    print(run_experiment(a.out))
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="adjcheck", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("parse"); s.add_argument("file"); s.add_argument("--tokens", action="store_true")
    s.set_defaults(fn=cmd_parse)
    s = sub.add_parser("check"); s.add_argument("file"); s.set_defaults(fn=cmd_check)
    s = sub.add_parser("fix"); s.add_argument("file"); s.add_argument("-o", "--output")
    s.set_defaults(fn=cmd_fix)
    s = sub.add_parser("run"); s.add_argument("file"); s.add_argument("--certs")
    s.add_argument("--allow-unsafe", action="store_true")
    s.add_argument("--fault", action="append", help="fault-injection name (testing only)")
    s.set_defaults(fn=cmd_run)
    s = sub.add_parser("verify"); s.add_argument("certs"); s.add_argument("--source")
    s.add_argument("--json"); s.add_argument("--show", type=int, default=15)
    s.set_defaults(fn=cmd_verify)
    s = sub.add_parser("faults"); s.add_argument("--out", default="outputs/fault_matrix.md")
    s.set_defaults(fn=cmd_faults)
    s = sub.add_parser("experiment"); s.add_argument("--out", default="outputs/experiment.md")
    s.set_defaults(fn=cmd_experiment)
    a = p.parse_args(argv)
    return a.fn(a)
