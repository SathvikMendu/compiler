"""Builds per-occurrence provenance certificates from executor output.

Certificate file schema (format "phraseproof-certificates/1"):

{
  "format": "phraseproof-certificates/1",
  "corpus": {"path": str, "documents": [{"doc_id", "sha256", "length"}]},
  "streams": [{
      "stream": str,                      # let-name of the ngrams node
      "policy": {"kind", "connectors"},
      "policy_sha256": str,
      "counts": {phrase: int},            # what the pipeline reports
      "occurrences": [{
          "id": int, "phrase": [str], "doc_id": str, "doc_sha256": str,
          "spans": [[start, end]], "views": [[str]]
      }],
      "uncertified": [{"phrase": [str], "doc_id": str, "reason": str}]
  }]
}
"""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from .contract import Document, PhrasePolicy, sha256_text

FORMAT = "phraseproof-certificates/1"


def build_certificates(corpus_path, documents: list[Document], grams: dict, policy: PhrasePolicy,
                       faults: set[str]) -> dict:
    hashes = {d.doc_id: d.sha256 for d in documents}
    streams = []
    for label, per_doc in grams.items():
        occs, uncert = [], []
        counts: Counter = Counter()
        for doc_id, occurrences in per_doc.items():
            for o in occurrences:
                counts[o.key] += 1
                toks = o.toks
                if not o.tracked:
                    if "certify-untracked" in faults and all(t.tracked or t.origin for t in toks):
                        spans = [[t.start, t.end] if t.tracked else list(t.origin) for t in toks]
                    else:
                        uncert.append({"phrase": o.phrase, "doc_id": doc_id,
                                       "reason": "provenance lost (token changed or split "
                                                 "without an offset mapping)"})
                        continue
                else:
                    spans = [[t.start, t.end] for t in toks]
                if "offset-shift" in faults:
                    spans = [[s + 1, e + 1] for s, e in spans]
                doc_hash = hashes[doc_id]
                if "stale-hash" in faults:
                    doc_hash = sha256_text(next(d.text for d in documents if d.doc_id == doc_id)
                                           + " (revised)")
                occs.append({"id": len(occs), "phrase": o.phrase, "doc_id": doc_id,
                             "doc_sha256": doc_hash, "spans": spans,
                             "views": [list(t.views) for t in toks]})
        if "duplicate-certificate" in faults and occs:
            dup = dict(occs[0], id=len(occs))
            occs.append(dup)
            counts[" ".join(dup["phrase"])] += 1
        if "inflate-count" in faults and counts:
            counts[sorted(counts)[0]] += 1
        streams.append({
            "stream": label,
            "policy": policy.to_json(),
            "policy_sha256": policy.sha256,
            "counts": dict(sorted(counts.items())),
            "occurrences": occs,
            "uncertified": uncert,
        })
    return {
        "format": FORMAT,
        "corpus": {"path": corpus_path,
                   "documents": [{"doc_id": d.doc_id, "sha256": d.sha256, "length": len(d.text)}
                                 for d in documents]},
        "streams": streams,
    }


def write_certificates(certs: dict, path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(certs, indent=1, ensure_ascii=False), encoding="utf-8")
    return p
