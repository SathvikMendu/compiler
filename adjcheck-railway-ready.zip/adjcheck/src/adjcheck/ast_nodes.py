"""Abstract syntax tree for the .adj language."""
from __future__ import annotations

from dataclasses import dataclass, field

from .diagnostics import Loc


@dataclass
class Arg:
    """A call argument: positional literal/identifier, or keyword=value."""

    loc: Loc
    value: object            # int | float | str (string literal) | Name
    keyword: str | None = None


@dataclass
class Name:
    """A bare identifier used as a value (stream reference or flag)."""

    ident: str
    loc: Loc


@dataclass
class Call:
    """name(args...) — an operation, a source (load/merge) or a sink."""

    name: str
    args: list[Arg]
    loc: Loc
    has_parens: bool = False
    rparen_offset: int | None = None   # script offset of ')' (used by rewrite)


@dataclass
class Pipe:
    """primary | op | op ..."""

    head: Call | Name
    ops: list[Call]
    loc: Loc


@dataclass
class Let:
    name: str
    expr: Pipe
    loc: Loc


@dataclass
class PolicyStmt:
    kind: str                # "strict" | "connectors"
    words: list[str]
    loc: Loc


@dataclass
class SinkStmt:
    call: Call
    output: str | None
    loc: Loc


@dataclass
class Program:
    stmts: list[Let | PolicyStmt | SinkStmt] = field(default_factory=list)


def dump(node, indent: int = 0) -> str:
    """Readable tree view used by `adjcheck parse`."""
    pad = "  " * indent
    if isinstance(node, Program):
        return "Program\n" + "\n".join(dump(s, indent + 1) for s in node.stmts)
    if isinstance(node, Let):
        return f"{pad}Let {node.name} @{node.loc}\n{dump(node.expr, indent + 1)}"
    if isinstance(node, PolicyStmt):
        words = f"({', '.join(node.words)})" if node.words else ""
        return f"{pad}Policy {node.kind}{words} @{node.loc}"
    if isinstance(node, SinkStmt):
        out = f" -> {node.output!r}" if node.output else ""
        return f"{pad}Sink{out} @{node.loc}\n{dump(node.call, indent + 1)}"
    if isinstance(node, Pipe):
        lines = [f"{pad}Pipe @{node.loc}", dump(node.head, indent + 1)]
        lines += [dump(op, indent + 1) for op in node.ops]
        return "\n".join(lines)
    if isinstance(node, Call):
        args = ", ".join(_arg_str(a) for a in node.args)
        return f"{pad}Call {node.name}({args}) @{node.loc}"
    if isinstance(node, Name):
        return f"{pad}Ref {node.ident} @{node.loc}"
    return f"{pad}{node!r}"


def _arg_str(a: Arg) -> str:
    v = a.value.ident if isinstance(a.value, Name) else repr(a.value)
    return f"{a.keyword}={v}" if a.keyword else v
