"""Compiler driver: source text -> tokens -> AST -> IR -> data-flow results."""
from __future__ import annotations

from dataclasses import dataclass, field

from .analysis import State, analyse
from .ast_nodes import Program
from .diagnostics import CompileError, Diagnostic, has_errors
from .ir import Module, lower
from .parser import parse


@dataclass
class CompileResult:
    source: str
    program: Program | None = None
    module: Module | None = None
    states: dict[int, State] = field(default_factory=dict)
    diagnostics: list[Diagnostic] = field(default_factory=list)
    analysed: bool = False

    @property
    def ok(self) -> bool:
        return not has_errors(self.diagnostics)

    def codes(self) -> list[str]:
        return [d.code for d in self.diagnostics]


def compile_source(source: str) -> CompileResult:
    res = CompileResult(source)
    try:
        res.program = parse(source)
    except CompileError as e:
        res.diagnostics.append(e.diagnostic)
        return res
    res.module, sem = lower(res.program)
    res.diagnostics.extend(sem)
    if has_errors(sem):
        # Data-flow analysis needs a well-formed graph; it is skipped otherwise.
        return res
    res.states, flow = analyse(res.module)
    res.diagnostics.extend(flow)
    res.analysed = True
    res.diagnostics.sort(key=lambda d: (d.loc.line, d.loc.col))
    return res
