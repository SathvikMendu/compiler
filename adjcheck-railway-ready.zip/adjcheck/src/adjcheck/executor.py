"""Executor: runs a checked IR over a corpus, carrying source offsets.

Every word token is a span [start, end) of the original document text plus
a list of views (casefold, stem) applied to that slice. Removal with
keep_gaps leaves a Gap item in the stream; tokenize leaves a boundary Gap
wherever punctuation or a blank line separates two words. ngrams(...) never
forms an n-gram across a Gap (except, under the connectors policy, a removed
gap that consists only of connector words, which are re-inserted with their
own spans).

`faults` is test instrumentation for the fault-injection study: each named
fault deliberately breaks one behaviour (see FAULTS). With no faults the
executor follows the documented semantics.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from . import contract
from .contract import WORD, Document, PhrasePolicy, apply_views
from .ir import Module, Node
from .lda import lda_topics

STOPWORDS = frozenset("""
a an the of to in on at by for from with about as into over under and or but nor
is are was were be been being am do does did done have has had it its this that
these those there here we you he she they i me my our your his her their them us
not no so than then too very can could will would shall should may might must
which who whom what when where why how all any both each few more most other some
such only own same just also if while because until again further once out up down
""".split())

NUMBER = re.compile(r"^[0-9]+(?:[.,][0-9]+)*$")

CONTRACTIONS = [
    (re.compile(r"^(wo)n['’]t$"), ["will", "not"]),
    (re.compile(r"^(ca)n['’]t$"), ["can", "not"]),
    (re.compile(r"^(\w+)n['’]t$"), [None, "not"]),
    (re.compile(r"^(\w+)['’]s$"), [None, "is"]),
    (re.compile(r"^(\w+)['’]re$"), [None, "are"]),
    (re.compile(r"^(\w+)['’]ll$"), [None, "will"]),
    (re.compile(r"^(\w+)['’]ve$"), [None, "have"]),
    (re.compile(r"^(\w+)['’]d$"), [None, "would"]),
    (re.compile(r"^(\w+)['’]m$"), [None, "am"]),
]

FAULTS = {
    "ignore-gaps": "ngrams() ignores gap markers and joins across them",
    "drop-boundaries": "tokenize() does not record punctuation/sentence boundaries",
    "casefold-offsets": "tokenize() computes offsets on casefolded text",
    "offset-shift": "certificates report every span shifted by +1",
    "duplicate-certificate": "one certificate is emitted twice (count adjusted to match)",
    "inflate-count": "one phrase's reported count is one higher than its occurrences",
    "stale-hash": "certificates carry the hash of a different document version",
    "certify-untracked": "split contraction tokens are certified with their parent's span",
    "drop-occurrences": "every third n-gram occurrence is silently dropped",
}


@dataclass
class Tok:
    text: str                      # current view of the word
    start: int | None              # None => provenance lost
    end: int | None
    views: tuple[str, ...] = ()
    origin: tuple[int, int] | None = None   # parent span (kept only for a fault)

    @property
    def tracked(self) -> bool:
        return self.start is not None


@dataclass
class Gap:
    kind: str                      # "boundary" | "removed"
    removed: list[Tok] = field(default_factory=list)


@dataclass
class Occurrence:
    doc_id: str
    toks: list[Tok]

    @property
    def phrase(self) -> list[str]:
        return [t.text for t in self.toks]

    @property
    def key(self) -> str:
        return " ".join(self.phrase)

    @property
    def tracked(self) -> bool:
        return all(t.tracked for t in self.toks)


class ExecutionError(Exception):
    pass


@dataclass
class RunResult:
    corpus_path: str
    documents: list[Document]
    grams: dict[str, dict[str, list[Occurrence]]]    # ngrams label -> doc -> occurrences
    outputs: list[str]
    certificates: dict


class Executor:
    def __init__(self, module: Module, base_dir: str | Path = ".", faults: set[str] | None = None,
                 policy: PhrasePolicy | None = None):
        self.module = module
        self.base = Path(base_dir)
        self.faults = set(faults or ())
        unknown = self.faults - set(FAULTS)
        if unknown:
            raise ExecutionError(f"unknown fault(s): {', '.join(sorted(unknown))}")
        p = module.policy
        self.policy = policy or PhrasePolicy(p.kind, tuple(p.connectors))
        self.values: dict[int, object] = {}
        self.corpus_path: str | None = None
        self.documents: list[Document] = []

    # -- driver ------------------------------------------------------------------
    def run(self) -> RunResult:
        outputs: list[str] = []
        for node in self.module.nodes:             # topological order
            ins = [self.values[i] for i in node.inputs]
            handler = getattr(self, "op_" + node.op)
            result = handler(node, *ins)
            if node.op in ("topics", "phrases", "features"):
                outputs.append(result)
            else:
                self.values[node.id] = result
        grams = {self.label(n): self.values[n.id] for n in self.module.nodes if n.op == "ngrams"}
        from .provenance import build_certificates
        certs = build_certificates(self.corpus_path, self.documents, grams, self.policy,
                                   self.faults)
        return RunResult(self.corpus_path, self.documents, grams, outputs, certs)

    def label(self, node: Node) -> str:
        return node.label or f"{node.op}@{node.loc}"

    # -- operations ----------------------------------------------------------------
    def op_load(self, node: Node):
        path = Path(node.args["path"])
        if not path.is_absolute():
            path = self.base / path
        if not path.exists():
            raise ExecutionError(f"load: file not found: {path}")
        if self.corpus_path not in (None, str(path)):
            raise ExecutionError("only one corpus per script is supported")
        self.corpus_path = str(path)
        self.documents = contract.load_corpus(path)
        return {d.doc_id: d for d in self.documents}

    def op_tokenize(self, node: Node, docs: dict[str, Document]):
        out = {}
        for doc_id, doc in docs.items():
            text = doc.text.casefold() if "casefold-offsets" in self.faults else doc.text
            items: list[Tok | Gap] = []
            prev_end = None
            for m in WORD.finditer(text):
                if prev_end is not None and "drop-boundaries" not in self.faults:
                    if contract.classify_gap(text[prev_end:m.start()]) is not None:
                        items.append(Gap("boundary"))
                # Correct behaviour: text is the original slice at original offsets.
                # Under the casefold-offsets fault both come from the casefolded copy.
                items.append(Tok(m.group(0), m.start(), m.end()))
                prev_end = m.end()
            out[doc_id] = items
        return out

    def _view(self, stream, view: str):
        out = {}
        for doc_id, items in stream.items():
            new = []
            for it in items:
                if isinstance(it, Tok):
                    views = it.views + (view,) if it.tracked else it.views
                    new.append(Tok(contract.VIEWS[view](it.text), it.start, it.end, views,
                                   it.origin))
                else:
                    new.append(it)
            out[doc_id] = new
        return out

    def op_lower(self, node: Node, stream):
        return self._view(stream, "casefold")

    def op_stem(self, node: Node, stream):
        return self._view(stream, "stem")

    def op_remove(self, node: Node, stream):
        kind, words, keep = node.args["set"], set(node.args["words"]), node.args["keep_gaps"]

        def drop(tok: Tok) -> bool:
            w = tok.text.casefold()
            if kind == "stopwords":
                return w in STOPWORDS
            if kind == "numbers":
                return bool(NUMBER.match(w))
            return w in words

        out = {}
        for doc_id, items in stream.items():
            new: list[Tok | Gap] = []
            for it in items:
                if isinstance(it, Tok) and drop(it):
                    if keep:
                        if new and isinstance(new[-1], Gap) and new[-1].kind == "removed":
                            new[-1].removed.append(it)
                        else:
                            new.append(Gap("removed", [it]))
                    continue
                new.append(it)
            out[doc_id] = new
        return out

    def op_expand_contractions(self, node: Node, stream):
        out = {}
        for doc_id, items in stream.items():
            new: list[Tok | Gap] = []
            for it in items:
                parts = _expand(it.text) if isinstance(it, Tok) else None
                if parts is None:
                    new.append(it)
                    continue
                origin = (it.start, it.end) if it.tracked else it.origin
                for p in parts:                      # provenance is not mapped: lost
                    new.append(Tok(p, None, None, (), origin))
            out[doc_id] = new
        return out

    def op_merge(self, node: Node, a, b):
        out = {}
        for doc_id in a:
            out[doc_id] = list(a[doc_id]) + [Gap("boundary")] + list(b.get(doc_id, []))
        return out

    def op_ngrams(self, node: Node, stream):
        lo, hi = node.args["min"], node.args["max"]
        out: dict[str, list[Occurrence]] = {}
        for doc_id, items in stream.items():
            if "ignore-gaps" in self.faults:
                items = [it for it in items if isinstance(it, Tok)]
            occs: list[Occurrence] = []
            for seg in self._segments(items):
                occs.extend(self._grams(doc_id, seg, lo, hi))
            if "drop-occurrences" in self.faults:
                occs = [o for i, o in enumerate(occs) if i % 3 != 2]
            out[doc_id] = occs
        return out

    def _segments(self, items: list[Tok | Gap]) -> list[list[tuple[Tok, bool]]]:
        """Split a stream into gap-free segments of (token, is_connector)."""
        pol = self.policy
        segs: list[list[tuple[Tok, bool]]] = [[]]
        for it in items:
            if isinstance(it, Tok):
                segs[-1].append((it, pol.is_connector(it.text)))
            elif (pol.kind == "connectors" and it.kind == "removed"
                  and all(pol.is_connector(t.text) for t in it.removed)):
                segs[-1].extend((t, True) for t in it.removed)     # bridge connector-only gap
            else:
                segs.append([])
        return [s for s in segs if s]

    def _grams(self, doc_id: str, seg: list[tuple[Tok, bool]], lo: int, hi: int):
        occs = []
        for i, (tok, conn) in enumerate(seg):
            if conn:
                continue                      # a phrase never starts with a connector
            content = 0
            for j in range(i, len(seg)):
                if not seg[j][1]:
                    content += 1
                    if content > hi:
                        break
                    if content >= lo:
                        occs.append(Occurrence(doc_id, [t for t, _ in seg[i:j + 1]]))
        return occs

    # -- sinks ---------------------------------------------------------------------
    def _counts(self, grams) -> Counter:
        c = Counter()
        for occs in grams.values():
            for o in occs:
                c[o.key] += 1
        return c

    def _out_path(self, node: Node) -> Path:
        p = Path(node.output)
        p = p if p.is_absolute() else self.base / p
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def op_phrases(self, node: Node, grams):
        path = self._out_path(node)
        rows = sorted(self._counts(grams).items(), key=lambda kv: (-kv[1], kv[0]))
        with path.open("w", encoding="utf-8") as f:
            f.write("phrase,words,count\n")
            for key, n in rows:
                f.write(f"{_csv(key)},{len(key.split())},{n}\n")
        return str(path)

    def op_features(self, node: Node, grams):
        path = self._out_path(node)
        with path.open("w", encoding="utf-8") as f:
            f.write("doc_id,phrase,count\n")
            for doc_id, occs in grams.items():
                for key, n in sorted(Counter(o.key for o in occs).items()):
                    f.write(f"{doc_id},{_csv(key)},{n}\n")
        return str(path)

    def op_topics(self, node: Node, grams):
        path = self._out_path(node)
        docs = [[o.key for o in occs] for occs in grams.values()]
        topics = lda_topics(docs, k=node.args["k"], iterations=node.args.get("iterations", 300),
                            seed=node.args.get("seed", 0), top=node.args.get("top", 8))
        with path.open("w", encoding="utf-8") as f:
            f.write("topic,rank,term,probability\n")
            for t, terms in enumerate(topics):
                for r, (term, prob) in enumerate(terms, 1):
                    f.write(f"{t},{r},{_csv(term)},{prob:.4f}\n")
        return str(path)


def _expand(word: str) -> list[str] | None:
    for pat, parts in CONTRACTIONS:
        m = pat.match(word)
        if m:
            return [m.group(1) if p is None else p for p in parts]
    return None


def _csv(s: str) -> str:
    return '"' + s.replace('"', '""') + '"' if any(c in s for c in ',"\n') else s
