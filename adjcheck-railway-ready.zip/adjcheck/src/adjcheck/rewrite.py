"""Safe-rewrite pass: remove(x) -> remove(x, keep_gaps) for supported hazards.

Supported case: an ADJ001 hazard whose backward path from ngrams(...) to
load(...) contains only tokenize, lower, stem, remove and merge. For each
remove(...) on that path without keep_gaps, the pass inserts `, keep_gaps`
before its closing parenthesis (a textual patch at the exact source offset,
so formatting and comments are preserved).

Unsupported (reported as REW001, never rewritten): paths through
expand_contractions (provenance already lost), and any hazard that remains
after the rewrite. The rewritten script is accepted only if re-checking it
reports no ADJ001 hazard.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .analysis import blocks_rewrite, unsafe_removals
from .compiler import CompileResult, compile_source
from .diagnostics import Diagnostic, Severity


@dataclass
class RewriteResult:
    original: str
    rewritten: str | None
    changes: list[str] = field(default_factory=list)
    diagnostics: list[Diagnostic] = field(default_factory=list)
    recheck: CompileResult | None = None

    @property
    def ok(self) -> bool:
        return self.rewritten is not None


def rewrite(source: str) -> RewriteResult:
    first = compile_source(source)
    out = RewriteResult(source, None)
    if not first.analysed:
        out.diagnostics.append(Diagnostic(
            "REW001", Severity.ERROR,
            "script has syntax or semantic errors; fix those before rewriting",
            first.diagnostics[0].loc if first.diagnostics else _origin()))
        return out
    module = first.module
    hazard_locs = {d.loc for d in first.diagnostics if d.code in ("ADJ001", "ADJ002")}
    targets = [n for n in module.nodes
               if n.op == "ngrams" and n.loc in hazard_locs and unsafe_removals(module, n)]
    hazards = [d for d in first.diagnostics if d.code == "ADJ001"]
    if not hazards and not targets:
        out.rewritten = source
        out.changes.append("no ADJ001 hazards: nothing to rewrite")
        out.recheck = first
        return out
    patch_offsets: dict[int, str] = {}
    for node in targets:
        blocker = blocks_rewrite(module, node)
        if blocker is not None:
            out.diagnostics.append(Diagnostic(
                "REW001", Severity.ERROR,
                f"cannot rewrite hazard at {node.loc}: path passes through "
                f"{blocker.op} at {blocker.loc}, which loses provenance", node.loc))
            continue
        for rm in unsafe_removals(module, node):
            if rm.call is None or rm.call.rparen_offset is None:
                continue
            patch_offsets[rm.call.rparen_offset] = f"remove at {rm.loc}"
    if any(d.code == "REW001" for d in out.diagnostics):
        return out
    text = source
    for off in sorted(patch_offsets, reverse=True):
        text = text[:off] + ", keep_gaps" + text[off:]
    for off in sorted(patch_offsets):
        out.changes.append(f"{patch_offsets[off]}: added keep_gaps")
    out.recheck = compile_source(text)
    if any(d.code == "ADJ001" for d in out.recheck.diagnostics) or not out.recheck.ok:
        out.diagnostics.append(Diagnostic(
            "REW001", Severity.ERROR,
            "rewritten script still has errors or hazards; rewrite rejected", _origin()))
        return out
    out.rewritten = text
    return out


def _origin():
    from .diagnostics import Loc
    return Loc(1, 1, 0)
