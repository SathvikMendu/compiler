"""Small, dependency-free LDA (collapsed Gibbs sampling) for the topics sink.

Deterministic for a given seed. Intended for the small demo corpus; it is a
plain textbook sampler, not an optimised implementation.
"""
from __future__ import annotations

import random


def lda_topics(docs: list[list[str]], k: int, iterations: int = 300, seed: int = 0,
               alpha: float = 0.1, beta: float = 0.01, top: int = 8):
    rng = random.Random(seed)
    vocab = sorted({w for d in docs for w in d})
    if not vocab:
        return [[] for _ in range(k)]
    index = {w: i for i, w in enumerate(vocab)}
    V = len(vocab)
    n_dk = [[0] * k for _ in docs]
    n_kw = [[0] * V for _ in range(k)]
    n_k = [0] * k
    z: list[list[int]] = []
    for d, doc in enumerate(docs):
        zd = []
        for w in doc:
            t = rng.randrange(k)
            zd.append(t)
            n_dk[d][t] += 1
            n_kw[t][index[w]] += 1
            n_k[t] += 1
        z.append(zd)
    for _ in range(iterations):
        for d, doc in enumerate(docs):
            for i, w in enumerate(doc):
                wi, t = index[w], z[d][i]
                n_dk[d][t] -= 1
                n_kw[t][wi] -= 1
                n_k[t] -= 1
                weights = [(n_dk[d][j] + alpha) * (n_kw[j][wi] + beta) / (n_k[j] + V * beta)
                           for j in range(k)]
                r = rng.random() * sum(weights)
                acc, t = 0.0, k - 1
                for j, wgt in enumerate(weights):
                    acc += wgt
                    if r < acc:
                        t = j
                        break
                z[d][i] = t
                n_dk[d][t] += 1
                n_kw[t][wi] += 1
                n_k[t] += 1
    topics = []
    for t in range(k):
        probs = [((n_kw[t][i] + beta) / (n_k[t] + V * beta), vocab[i]) for i in range(V)]
        probs.sort(key=lambda p: (-p[0], p[1]))
        topics.append([(w, p) for p, w in probs[:top]])
    return topics
