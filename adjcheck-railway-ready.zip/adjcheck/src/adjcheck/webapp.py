"""Backwards-compatible entry point; the web interface lives in `adjcheck.web`.

    adjcheck-web            (console script)
    python -m adjcheck.webapp
"""
from __future__ import annotations

import sys

from .web import create_app, main

__all__ = ["create_app", "main"]

if __name__ == "__main__":
    sys.exit(main())
