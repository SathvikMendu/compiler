"""Measured evaluation: fault-injection matrix and policy experiment."""
