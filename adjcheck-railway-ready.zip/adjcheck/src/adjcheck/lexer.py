"""Handwritten lexer for the .adj pipeline language.

The lexer is a single left-to-right scan (a hand-coded DFA): it looks at the
current character, decides which token class it starts, and consumes the
longest valid lexeme (maximal munch). Every token records its line, column
and character offset so later phases can report precise diagnostics.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .diagnostics import CompileError, Diagnostic, Loc, Severity


class T(str, Enum):
    LET = "let"
    POLICY = "policy"
    IDENT = "identifier"
    INT = "integer"
    FLOAT = "float"
    STRING = "string"
    PIPE = "'|'"
    ARROW = "'->'"
    LPAREN = "'('"
    RPAREN = "')'"
    COMMA = "','"
    SEMI = "';'"
    EQ = "'='"
    EOF = "end of file"


KEYWORDS = {"let": T.LET, "policy": T.POLICY}
SINGLE = {"|": T.PIPE, "(": T.LPAREN, ")": T.RPAREN, ",": T.COMMA, ";": T.SEMI, "=": T.EQ}


@dataclass(frozen=True)
class Token:
    kind: T
    text: str
    loc: Loc
    value: object = None

    def __repr__(self) -> str:  # compact form used by `parse --tokens`
        return f"{self.kind.name}({self.text!r})@{self.loc}"


def tokenize(source: str) -> list[Token]:
    tokens: list[Token] = []
    i, line, col = 0, 1, 1
    n = len(source)

    def loc_at() -> Loc:
        return Loc(line, col, i)

    while i < n:
        ch = source[i]
        # whitespace
        if ch in " \t\r":
            i += 1
            col += 1
            continue
        if ch == "\n":
            i += 1
            line += 1
            col = 1
            continue
        # comment to end of line
        if ch == "#":
            while i < n and source[i] != "\n":
                i += 1
                col += 1
            continue
        start = loc_at()
        # identifiers / keywords
        if ch.isalpha() or ch == "_":
            j = i
            while j < n and (source[j].isalnum() or source[j] == "_"):
                j += 1
            text = source[i:j]
            kind = KEYWORDS.get(text, T.IDENT)
            tokens.append(Token(kind, text, start))
            col += j - i
            i = j
            continue
        # numbers: INT or FLOAT (digits '.' digits). "1..2" is not used by the grammar.
        if ch.isdigit():
            j = i
            while j < n and source[j].isdigit():
                j += 1
            if j + 1 < n and source[j] == "." and source[j + 1].isdigit():
                j += 1
                while j < n and source[j].isdigit():
                    j += 1
                text = source[i:j]
                tokens.append(Token(T.FLOAT, text, start, float(text)))
            else:
                text = source[i:j]
                tokens.append(Token(T.INT, text, start, int(text)))
            col += j - i
            i = j
            continue
        # strings: double quoted, backslash escapes \" and \\ only
        if ch == '"':
            j = i + 1
            buf = []
            while j < n and source[j] != '"':
                if source[j] == "\n":
                    break
                if source[j] == "\\" and j + 1 < n and source[j + 1] in '"\\':
                    buf.append(source[j + 1])
                    j += 2
                    continue
                buf.append(source[j])
                j += 1
            if j >= n or source[j] != '"':
                raise CompileError(Diagnostic("LEX002", Severity.ERROR,
                                              "unterminated string literal", start))
            j += 1
            tokens.append(Token(T.STRING, source[i:j], start, "".join(buf)))
            col += j - i
            i = j
            continue
        if ch == "-" and i + 1 < n and source[i + 1] == ">":
            tokens.append(Token(T.ARROW, "->", start))
            i += 2
            col += 2
            continue
        if ch in SINGLE:
            tokens.append(Token(SINGLE[ch], ch, start))
            i += 1
            col += 1
            continue
        raise CompileError(Diagnostic("LEX001", Severity.ERROR,
                                      f"invalid character {ch!r}", start))
    tokens.append(Token(T.EOF, "", Loc(line, col, i)))
    return tokens
