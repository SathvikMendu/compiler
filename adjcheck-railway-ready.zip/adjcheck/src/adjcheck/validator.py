
"""PhraseProof: independent checker for n-gram provenance certificates.

The checker validates each occurrence against the original source document.
It does not import the executor, IR, or static analysis modules.

Guarantees are limited to supplied certificates and the declared phrase
policy. It does not prove that every expected n-gram was generated.
"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import contract
from .contract import PhrasePolicy

ACCEPTED = "ACCEPTED"
REJECTED = "REJECTED"
UNCERTIFIED = "UNCERTIFIED"


@dataclass
class Verdict:
    stream: str
    phrase: list[str]
    doc_id: str
    status: str
    code: str = ""
    detail: str = ""
    occurrence_id: int | None = None


@dataclass
class Report:
    verdicts: list[Verdict] = field(default_factory=list)
    count_issues: list[dict] = field(default_factory=list)
    file_issues: list[str] = field(default_factory=list)

    def summary(self) -> dict:
        counts = Counter(v.status for v in self.verdicts)
        return {
            ACCEPTED: counts[ACCEPTED],
            REJECTED: counts[REJECTED],
            UNCERTIFIED: counts[UNCERTIFIED],
            "count_mismatches": len(self.count_issues),
            "file_issues": len(self.file_issues),
        }

    @property
    def clean(self) -> bool:
        summary = self.summary()
        return (
            summary[REJECTED] == 0
            and summary[UNCERTIFIED] == 0
            and not self.count_issues
            and not self.file_issues
        )

    def rejection_codes(self) -> Counter:
        return Counter(
            verdict.code
            for verdict in self.verdicts
            if verdict.status == REJECTED
        )

    def to_json(self) -> dict:
        return {
            "summary": self.summary(),
            "file_issues": self.file_issues,
            "count_issues": self.count_issues,
            "verdicts": [
                {
                    "stream": v.stream,
                    "phrase": v.phrase,
                    "doc_id": v.doc_id,
                    "status": v.status,
                    "code": v.code,
                    "detail": v.detail,
                    "occurrence_id": v.occurrence_id,
                }
                for v in self.verdicts
            ],
        }


def _is_string_list(value: Any) -> bool:
    """True only for a list containing strings."""
    return isinstance(value, list) and all(
        isinstance(item, str) for item in value
    )


def _safe_phrase(value: Any) -> list[str]:
    """Return a display-safe phrase without trusting certificate input."""
    if _is_string_list(value):
        return value
    return []


def _reject_malformed(
    stream_name: str,
    occurrence: Any,
    detail: str,
) -> Verdict:
    """Create a rejection for a malformed occurrence record."""
    phrase = _safe_phrase(
        occurrence.get("phrase")
        if isinstance(occurrence, dict)
        else None
    )
    doc_id = (
        occurrence.get("doc_id", "?")
        if isinstance(occurrence, dict)
        else "?"
    )
    if not isinstance(doc_id, str):
        doc_id = "?"

    occurrence_id = (
        occurrence.get("id")
        if isinstance(occurrence, dict)
        else None
    )
    if not isinstance(occurrence_id, int):
        occurrence_id = None

    return Verdict(
        stream=stream_name,
        phrase=phrase,
        doc_id=doc_id,
        status=REJECTED,
        code="MALFORMED_CERTIFICATE",
        detail=detail,
        occurrence_id=occurrence_id,
    )


def check_occurrence(
    cert: dict,
    docs: dict[str, contract.Document],
    policy: PhrasePolicy,
    word_cache: dict,
) -> tuple[str, str]:
    """Return (code, detail); an empty code means the occurrence passed."""
    if not isinstance(cert, dict):
        return "MALFORMED_CERTIFICATE", "occurrence must be a JSON object"

    phrase = cert.get("phrase")
    spans = cert.get("spans")
    views = cert.get("views")
    doc_id = cert.get("doc_id")

    if not isinstance(doc_id, str):
        return "MALFORMED_CERTIFICATE", "doc_id must be a string"

    doc = docs.get(doc_id)
    if doc is None:
        return "UNKNOWN_DOC", f"no document {doc_id!r} in supplied source"

    if cert.get("doc_sha256") != doc.sha256:
        return "HASH_MISMATCH", "certificate hash does not match the source document"

    if not _is_string_list(phrase) or not phrase:
        return "BAD_SPANS", "phrase must be a non-empty list of strings"

    if not isinstance(spans, list) or not isinstance(views, list):
        return "BAD_SPANS", "spans and views must be lists"

    if len(spans) != len(phrase) or len(views) != len(phrase):
        return "BAD_SPANS", (
            "need exactly one span and one view list per phrase word"
        )

    # Validate every span before unpacking it.
    text = doc.text
    validated_spans: list[tuple[int, int]] = []
    previous_end = -1

    for span in spans:
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(position) is not int for position in span)
        ):
            return "BAD_SPANS", f"invalid span representation: {span!r}"

        start, end = span

        if not (0 <= start < end <= len(text)):
            return "BAD_SPANS", f"span {span!r} is out of bounds or empty"

        if start < previous_end:
            return "BAD_SPANS", (
                f"span {span!r} overlaps or is out of order"
            )

        validated_spans.append((start, end))
        previous_end = end

    if doc.doc_id not in word_cache:
        word_cache[doc.doc_id] = contract.word_spans(text)

    known_words = word_cache[doc.doc_id]

    # Each span must point to exactly one word in the source.
    for start, end in validated_spans:
        if (start, end) not in known_words:
            return "NOT_A_WORD", (
                f"[{start}, {end}) = {text[start:end]!r} "
                "is not exactly one source word"
            )

    # Validate the declared transformations for each source word.
    for (start, end), expected_word, view_list in zip(
        validated_spans, phrase, views
    ):
        if not _is_string_list(view_list):
            return "UNKNOWN_VIEW", "each view entry must be a list of strings"

        if any(view not in contract.VIEWS for view in view_list):
            return "UNKNOWN_VIEW", f"unknown view in {view_list!r}"

        actual_word = contract.apply_views(text[start:end], view_list)

        if actual_word != expected_word:
            return "TEXT_MISMATCH", (
                f"source {text[start:end]!r} under "
                f"{view_list or ['none']} is {actual_word!r}, "
                f"certificate says {expected_word!r}"
            )

    # Validate the source text between consecutive word occurrences.
    for (_, previous_end), (next_start, _) in zip(
        validated_spans, validated_spans[1:]
    ):
        gap = text[previous_end:next_start]
        reason = contract.classify_gap(gap)

        if reason:
            return "GAP_VIOLATION", (
                f"gap {gap!r} between source spans is not allowed: {reason}"
            )

    # Apply connector policy restrictions.
    if policy.kind == "connectors":
        connector_flags = [
            policy.is_connector(word) for word in phrase
        ]

        if connector_flags[0] or connector_flags[-1]:
            return "POLICY_VIOLATION", (
                "a phrase may not start or end with a connector word"
            )

        if all(connector_flags):
            return "POLICY_VIOLATION", (
                "a phrase needs at least one non-connector word"
            )

    return "", ""


def verify(certs: dict, source_path: str | Path) -> Report:
    """Validate a certificate document against its source corpus."""
    report = Report()

    # Validate the outermost JSON structure first.
    if not isinstance(certs, dict):
        report.file_issues.append(
            "certificate file must contain a JSON object"
        )
        return report

    if certs.get("format") != "phraseproof-certificates/1":
        report.file_issues.append(
            f"unsupported certificate format {certs.get('format')!r}"
        )
        return report

    raw_streams = certs.get("streams")
    if not isinstance(raw_streams, list):
        report.file_issues.append("'streams' must be a list")
        return report

    try:
        documents = contract.load_corpus(source_path)
    except (OSError, ValueError, TypeError) as exc:
        report.file_issues.append(
            f"could not load source corpus: {exc}"
        )
        return report

    docs = {document.doc_id: document for document in documents}
    word_cache: dict = {}

    for stream_index, stream in enumerate(raw_streams):
        if not isinstance(stream, dict):
            report.file_issues.append(
                f"stream at index {stream_index} must be a JSON object"
            )
            continue

        name = stream.get("stream", "?")
        if not isinstance(name, str):
            name = "?"

        # Parse and validate the policy.
        try:
            policy = PhrasePolicy.from_json(stream.get("policy", {}))
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            report.file_issues.append(
                f"{name}: invalid policy: {exc}"
            )
            continue

        if policy.kind not in ("strict", "connectors"):
            report.file_issues.append(
                f"{name}: unknown policy {policy.kind!r}"
            )
            continue

        # Fail closed: no occurrence is accepted under a mismatched policy.
        expected_policy_hash = policy.sha256
        supplied_policy_hash = stream.get("policy_sha256")

        if supplied_policy_hash != expected_policy_hash:
            report.file_issues.append(
                f"{name}: policy hash does not match the declared policy"
            )
            continue

        occurrences = stream.get("occurrences", [])
        uncertified = stream.get("uncertified", [])
        reported_counts = stream.get("counts", {})

        if not isinstance(occurrences, list):
            report.file_issues.append(
                f"{name}: 'occurrences' must be a list"
            )
            continue

        if not isinstance(uncertified, list):
            report.file_issues.append(
                f"{name}: 'uncertified' must be a list"
            )
            continue

        if not isinstance(reported_counts, dict) or any(
            not isinstance(key, str)
            or type(value) is not int
            or value < 0
            for key, value in reported_counts.items()
        ):
            report.file_issues.append(
                f"{name}: 'counts' must map phrase strings to "
                "non-negative integers"
            )
            continue

        seen: set[tuple] = set()
        per_phrase: Counter = Counter()

        for occurrence_index, cert in enumerate(occurrences):
            if not isinstance(cert, dict):
                report.verdicts.append(
                    _reject_malformed(
                        name,
                        cert,
                        f"occurrence at index {occurrence_index} "
                        "must be a JSON object",
                    )
                )
                continue

            phrase = cert.get("phrase")
            if not _is_string_list(phrase) or not phrase:
                report.verdicts.append(
                    _reject_malformed(
                        name,
                        cert,
                        "phrase must be a non-empty list of strings",
                    )
                )
                continue

            phrase_key = " ".join(phrase)
            per_phrase[phrase_key] += 1

            code, detail = check_occurrence(
                cert, docs, policy, word_cache
            )

            # Duplicate identity is occurrence-based, not phrase-only.
            spans = cert.get("spans")
            if isinstance(spans, list):
                try:
                    spans_key = json.dumps(
                        spans, sort_keys=True, separators=(",", ":")
                    )
                except (TypeError, ValueError):
                    spans_key = repr(spans)
            else:
                spans_key = repr(spans)

            identity = (
                phrase_key,
                cert.get("doc_id"),
                spans_key,
            )

            if not code and identity in seen:
                code = "DUPLICATE"
                detail = "the same occurrence is certified more than once"

            seen.add(identity)

            occurrence_id = cert.get("id")
            if not isinstance(occurrence_id, int):
                occurrence_id = None

            report.verdicts.append(
                Verdict(
                    stream=name,
                    phrase=phrase,
                    doc_id=(
                        cert.get("doc_id")
                        if isinstance(cert.get("doc_id"), str)
                        else "?"
                    ),
                    status=REJECTED if code else ACCEPTED,
                    code=code,
                    detail=detail,
                    occurrence_id=occurrence_id,
                )
            )

        for index, item in enumerate(uncertified):
            if not isinstance(item, dict):
                report.verdicts.append(
                    _reject_malformed(
                        name,
                        item,
                        f"uncertified entry at index {index} "
                        "must be a JSON object",
                    )
                )
                continue

            phrase = item.get("phrase")
            if not _is_string_list(phrase) or not phrase:
                report.verdicts.append(
                    _reject_malformed(
                        name,
                        item,
                        "uncertified phrase must be a non-empty "
                        "list of strings",
                    )
                )
                continue

            phrase_key = " ".join(phrase)
            per_phrase[phrase_key] += 1

            doc_id = item.get("doc_id", "?")
            if not isinstance(doc_id, str):
                doc_id = "?"

            report.verdicts.append(
                Verdict(
                    stream=name,
                    phrase=phrase,
                    doc_id=doc_id,
                    status=UNCERTIFIED,
                    code="NO_CERTIFICATE",
                    detail=(
                        item.get("reason", "")
                        if isinstance(item.get("reason", ""), str)
                        else "invalid uncertified reason"
                    ),
                )
            )

        # Compare reported totals with all supplied occurrence records.
        for phrase_key in sorted(
            set(reported_counts) | set(per_phrase)
        ):
            reported = reported_counts.get(phrase_key, 0)
            actual = per_phrase.get(phrase_key, 0)

            if reported != actual:
                report.count_issues.append(
                    {
                        "stream": name,
                        "phrase": phrase_key,
                        "reported": reported,
                        "occurrences": actual,
                    }
                )

    return report


def verified_counts(report: Report) -> dict[str, dict[str, int]]:
    """Count ACCEPTED occurrences only."""
    output: dict[str, Counter] = defaultdict(Counter)

    for verdict in report.verdicts:
        if verdict.status == ACCEPTED:
            output[verdict.stream][" ".join(verdict.phrase)] += 1

    return {
        stream: dict(counts)
        for stream, counts in output.items()
    }


def load_certificates(path: str | Path) -> dict:
    """Load certificate JSON, raising a clear error for invalid input."""
    try:
        data = json.loads(
            Path(path).read_text(encoding="utf-8")
        )
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"invalid certificate JSON at line {exc.lineno}, "
            f"column {exc.colno}: {exc.msg}"
        ) from exc

    if not isinstance(data, dict):
        raise ValueError(
            "certificate JSON must contain a top-level object"
        )

    return data
