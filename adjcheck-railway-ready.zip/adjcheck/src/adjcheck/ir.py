"""Semantic analysis and lowering of the AST into a stream-graph IR.

The IR is a DAG: each node is one operation, edges are data flow between
streams. `let` names are bound in a symbol table (env) to the node that
produced the stream. Because a stream must be defined before it is used,
node creation order is already a topological order of the DAG.

Stream types:
  TEXT   - documents as text (produced by load)
  TOKENS - per-document token streams (with gap markers)
  GRAMS  - per-document n-gram occurrences
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .ast_nodes import Arg, Call, Let, Name, Pipe, PolicyStmt, Program, SinkStmt
from .diagnostics import Diagnostic, Loc, Severity

TEXT, TOKENS, GRAMS = "TEXT", "TOKENS", "GRAMS"

TOKEN_SETS = {"stopwords", "numbers"}
PHRASE_SINKS = {"topics", "phrases"}       # n-grams are read as phrases
FEATURE_SINKS = {"features"}               # n-grams used only as features
SINKS = PHRASE_SINKS | FEATURE_SINKS


@dataclass
class Node:
    id: int
    op: str
    inputs: list[int]
    type: str | None
    loc: Loc
    args: dict = field(default_factory=dict)
    label: str | None = None          # let-name bound to this node, if any
    call: Call | None = None          # AST node (used by the rewrite pass)
    output: str | None = None         # sink output path


@dataclass
class Policy:
    kind: str = "strict"
    connectors: tuple[str, ...] = ()
    loc: Loc | None = None

    def to_json(self) -> dict:
        return {"kind": self.kind, "connectors": list(self.connectors)}


@dataclass
class Module:
    nodes: list[Node]
    policy: Policy
    env: dict[str, int]

    def consumers(self) -> dict[int, list[int]]:
        out: dict[int, list[int]] = {n.id: [] for n in self.nodes}
        for n in self.nodes:
            for i in n.inputs:
                out[i].append(n.id)
        return out


class Lowerer:
    def __init__(self) -> None:
        self.nodes: list[Node] = []
        self.env: dict[str, int] = {}
        self.env_loc: dict[str, Loc] = {}
        self.used: set[str] = set()
        self.diags: list[Diagnostic] = []
        self.policy = Policy()
        self.policy_seen = False

    # -- helpers -------------------------------------------------------------
    def err(self, code: str, msg: str, loc: Loc, fix: str | None = None) -> None:
        self.diags.append(Diagnostic(code, Severity.ERROR, msg, loc, fix))

    def new(self, op: str, inputs: list[int], typ: str | None, loc: Loc, **kw) -> Node:
        node = Node(len(self.nodes), op, inputs, typ, loc, **kw)
        self.nodes.append(node)
        return node

    def type_of(self, node_id: int | None) -> str | None:
        return None if node_id is None else self.nodes[node_id].type

    def ref(self, name: Name) -> int | None:
        if name.ident not in self.env:
            self.err("SEM001", f"undefined stream {name.ident!r}", name.loc,
                     "define it with `let " + name.ident + " = ...;` before this use")
            return None
        self.used.add(name.ident)
        return self.env[name.ident]

    def need_type(self, got: str | None, want: str, what: str, loc: Loc) -> None:
        if got is not None and got != want:
            self.err("SEM005", f"{what} expects a {want} stream, got {got}", loc)

    # -- program ------------------------------------------------------------
    def lower(self, prog: Program) -> Module:
        for st in prog.stmts:
            if isinstance(st, Let):
                self.let(st)
            elif isinstance(st, PolicyStmt):
                self.policy_stmt(st)
            elif isinstance(st, SinkStmt):
                self.sink(st)
        for name, loc in self.env_loc.items():
            if name not in self.used:
                self.diags.append(Diagnostic("SEM007", Severity.WARNING,
                                             f"stream {name!r} is defined but never used", loc))
        if not any(n.op in SINKS for n in self.nodes):
            self.diags.append(Diagnostic("SEM009", Severity.WARNING,
                                         "pipeline has no sink; nothing will be produced",
                                         Loc(1, 1, 0)))
        return Module(self.nodes, self.policy, dict(self.env))

    def let(self, st: Let) -> None:
        if st.name in self.env:
            self.err("SEM002", f"stream {st.name!r} is already defined at "
                     f"{self.env_loc[st.name]}", st.loc, "use a new name")
        node_id = self.pipe(st.expr)
        if node_id is not None:
            self.nodes[node_id].label = st.name
            self.env[st.name] = node_id
            self.env_loc.setdefault(st.name, st.loc)

    def policy_stmt(self, st: PolicyStmt) -> None:
        if self.policy_seen:
            self.err("SEM008", "policy declared more than once", st.loc)
            return
        self.policy_seen = True
        if st.kind == "strict":
            if st.words:
                self.err("SEM006", "policy strict takes no word list", st.loc)
            self.policy = Policy("strict", (), st.loc)
        elif st.kind == "connectors":
            if not st.words:
                self.err("SEM006", "policy connectors(...) needs at least one word", st.loc)
            self.policy = Policy("connectors", tuple(w.casefold() for w in st.words), st.loc)
        else:
            self.err("SEM006", f"unknown policy {st.kind!r} (expected strict or connectors)",
                     st.loc)

    # -- expressions ----------------------------------------------------------
    def pipe(self, p: Pipe) -> int | None:
        cur = self.head(p.head)
        for op in p.ops:
            cur = self.op(op, cur)
        return cur

    def head(self, h: Call | Name) -> int | None:
        if isinstance(h, Name):
            return self.ref(h)
        if h.name == "load":
            path = self.positional(h, 1, 1)
            if path and not isinstance(path[0].value, str):
                self.err("SEM004", "load expects one string path, e.g. load(\"data/x.txt\")",
                         h.loc)
                return self.new("load", [], TEXT, h.loc, call=h).id
            return self.new("load", [], TEXT, h.loc, args={"path": path[0].value if path else None},
                            call=h).id
        if h.name == "merge":
            pos = self.positional(h, 2, 2)
            ids = []
            for a in pos:
                if not isinstance(a.value, Name):
                    self.err("SEM004", "merge expects two stream names", a.loc)
                    continue
                ids.append(self.ref(a.value))
            for i in ids:
                self.need_type(self.type_of(i), TOKENS, "merge", h.loc)
            return self.new("merge", [i for i in ids if i is not None], TOKENS, h.loc, call=h).id
        if h.name in OPS:
            self.err("SEM003", f"{h.name!r} is an operation, not a source; "
                     "start a pipeline with load(...), merge(...) or a stream name", h.loc)
        else:
            self.err("SEM003", f"unknown source {h.name!r}", h.loc)
        return None

    def positional(self, call: Call, lo: int, hi: int) -> list[Arg]:
        pos = [a for a in call.args if a.keyword is None]
        if not lo <= len(pos) <= hi:
            want = str(lo) if lo == hi else f"{lo}-{hi}"
            self.err("SEM004", f"{call.name} takes {want} positional argument(s), "
                     f"got {len(pos)}", call.loc)
        return pos

    def op(self, call: Call, inp: int | None) -> int | None:
        spec = OPS.get(call.name)
        if spec is None:
            hint = " (sinks must be statements, not pipe stages)" if call.name in SINKS else ""
            self.err("SEM003", f"unknown operation {call.name!r}{hint}", call.loc)
            return None
        in_type, out_type, check = spec
        self.need_type(self.type_of(inp), in_type, call.name, call.loc)
        args = check(self, call)
        return self.new(call.name, [inp] if inp is not None else [], out_type, call.loc,
                        args=args, call=call).id

    def sink(self, st: SinkStmt) -> None:
        call = st.call
        if call.name not in SINKS:
            self.err("SEM003", f"unknown sink {call.name!r} "
                     f"(expected one of {', '.join(sorted(SINKS))})", call.loc)
            return
        pos = self.positional(call, 1, 1)
        src = None
        if pos:
            if isinstance(pos[0].value, Name):
                src = self.ref(pos[0].value)
                self.need_type(self.type_of(src), GRAMS, call.name, call.loc)
            else:
                self.err("SEM004", f"{call.name} expects a stream name as first argument",
                         pos[0].loc)
        kw = {a.keyword: a for a in call.args if a.keyword}
        args: dict = {}
        allowed = {"topics": {"k", "iterations", "seed", "top"}}.get(call.name, set())
        for key, a in kw.items():
            if key not in allowed:
                self.err("SEM004", f"{call.name} has no argument {key!r}", a.loc)
            elif not isinstance(a.value, int) or a.value < 1:
                self.err("SEM006", f"{key} must be a positive integer", a.loc)
            else:
                args[key] = a.value
        if call.name == "topics" and "k" not in args and "k" not in kw:
            self.err("SEM004", "topics needs k = <number of topics>", call.loc)
        output = st.output or f"outputs/{call.name}_{call.loc.line}.csv"
        self.new(call.name, [src] if src is not None else [], None, call.loc,
                 args=args, call=call, output=output)


# -- per-operation argument checkers -------------------------------------------

def _no_args(lw: Lowerer, call: Call) -> dict:
    if call.args:
        lw.err("SEM004", f"{call.name} takes no arguments", call.loc)
    return {}


def _remove_args(lw: Lowerer, call: Call) -> dict:
    pos = lw.positional(call, 1, 2)
    if any(a.keyword for a in call.args):
        lw.err("SEM004", "remove takes no keyword arguments", call.loc)
    args: dict = {"set": None, "words": (), "keep_gaps": False}
    if pos:
        first = pos[0].value
        if isinstance(first, Name) and first.ident in TOKEN_SETS:
            args["set"] = first.ident
        elif isinstance(first, str):
            words = tuple(w.casefold() for w in first.split())
            if not words:
                lw.err("SEM006", "remove(\"...\") needs at least one word", pos[0].loc)
            args["set"], args["words"] = "words", words
        else:
            shown = first.ident if isinstance(first, Name) else first
            lw.err("SEM006", f"remove expects stopwords, numbers or a quoted word list, "
                   f"got {shown!r}", pos[0].loc)
    if len(pos) == 2:
        flag = pos[1].value
        if isinstance(flag, Name) and flag.ident == "keep_gaps":
            args["keep_gaps"] = True
        else:
            lw.err("SEM006", "the only option for remove is keep_gaps", pos[1].loc)
    return args


def _ngrams_args(lw: Lowerer, call: Call) -> dict:
    pos = lw.positional(call, 1, 2)
    vals = [a.value for a in pos]
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in vals):
        lw.err("SEM006", "ngrams expects integers: ngrams(min, max)", call.loc)
        return {"min": 1, "max": 1}
    if not vals:
        return {"min": 1, "max": 1}
    lo = vals[0]
    hi = vals[1] if len(vals) > 1 else lo
    if lo < 1 or hi < lo:
        lw.err("SEM006", f"invalid n-gram range ({lo}, {hi}); need 1 <= min <= max", call.loc)
    if hi > 6:
        lw.err("SEM006", "ngrams max is limited to 6", call.loc)
    return {"min": lo, "max": hi}


OPS = {
    # name: (input type, output type, argument checker)
    "tokenize": (TEXT, TOKENS, _no_args),
    "lower": (TOKENS, TOKENS, _no_args),
    "stem": (TOKENS, TOKENS, _no_args),
    "remove": (TOKENS, TOKENS, _remove_args),
    "expand_contractions": (TOKENS, TOKENS, _no_args),
    "ngrams": (TOKENS, GRAMS, _ngrams_args),
}


def lower(prog: Program) -> tuple[Module, list[Diagnostic]]:
    lw = Lowerer()
    module = lw.lower(prog)
    return module, lw.diags
