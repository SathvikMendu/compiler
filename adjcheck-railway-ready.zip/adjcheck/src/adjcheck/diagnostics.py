"""Diagnostics shared by every compiler phase.

Every message has a stable code, a severity and a source location, so tests
and the viva demo can refer to exact error codes (e.g. ADJ001).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass(frozen=True)
class Loc:
    """1-based line/column plus 0-based character offset into the script."""

    line: int
    col: int
    offset: int = 0

    def __str__(self) -> str:
        return f"{self.line}:{self.col}"


@dataclass
class Diagnostic:
    code: str
    severity: Severity
    message: str
    loc: Loc
    fix: str | None = None
    notes: list[str] = field(default_factory=list)

    def render(self, filename: str = "<input>") -> str:
        out = f"{filename}:{self.loc}: {self.severity.value}[{self.code}]: {self.message}"
        for note in self.notes:
            out += f"\n  note: {note}"
        if self.fix:
            out += f"\n  fix: {self.fix}"
        return out


class CompileError(Exception):
    """Raised by the lexer/parser for errors that stop compilation."""

    def __init__(self, diagnostic: Diagnostic):
        super().__init__(diagnostic.message)
        self.diagnostic = diagnostic


def has_errors(diags: list[Diagnostic]) -> bool:
    return any(d.severity is Severity.ERROR for d in diags)


# Stable code table (documented in README / DESIGN.md).
CODES = {
    "LEX001": "invalid character",
    "LEX002": "unterminated string literal",
    "SYN001": "unexpected token",
    "SEM001": "undefined stream",
    "SEM002": "stream redefined",
    "SEM003": "unknown operation or sink",
    "SEM004": "wrong number or kind of arguments",
    "SEM005": "stream type mismatch",
    "SEM006": "invalid argument value",
    "SEM007": "stream defined but never used",
    "SEM008": "policy declared more than once",
    "SEM009": "pipeline has no sink",
    "ADJ001": "n-grams formed on a stream whose adjacency may be broken",
    "ADJ002": "n-grams formed on a stream whose provenance is untracked",
    "REW001": "hazard cannot be rewritten automatically",
}
