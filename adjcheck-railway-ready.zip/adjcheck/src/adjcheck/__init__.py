"""AdjCheck: static adjacency analysis and certified n-gram provenance."""

__version__ = "0.1.0"
