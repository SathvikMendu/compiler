"""The shared contract (trusted base) between the executor and the checker.

Both sides must agree on a few definitions, and these are deliberately kept
small and in one file so they can be reviewed by hand:

1. Source representation: a corpus file is decoded as UTF-8, line endings
   are normalised to "\n", the text is normalised to Unicode NFC, and it is
   split into documents at blank lines. Each document is stripped of
   leading/trailing whitespace. Offsets are 0-based character (code point)
   offsets into that document text; [start, end) half-open.
2. What a word is: a maximal match of WORD below.
3. Views: deterministic functions applied to the original slice of a word
   (casefold, stem). A view never changes offsets.
4. Gap rule: two consecutive phrase words are adjacent iff the text between
   them is whitespace only and contains no blank line.
5. Policies: strict and connectors(...), as described in DESIGN.md.

Nothing else is shared. The checker (validator.py) imports only this module.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

WORD = re.compile(r"\w+(?:['’-]\w+)*")
BLANK_LINE = re.compile(r"\n[ \t]*\n")


@dataclass(frozen=True)
class Document:
    doc_id: str
    text: str

    @property
    def sha256(self) -> str:
        return sha256_text(self.text)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonicalize(raw: str) -> str:
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    return unicodedata.normalize("NFC", raw)


def split_documents(text: str) -> list[Document]:
    docs = []
    for part in BLANK_LINE.split(text):
        part = part.strip()
        if part:
            docs.append(Document(f"d{len(docs) + 1}", part))
    return docs


def load_corpus(path: str | Path) -> list[Document]:
    raw = Path(path).read_bytes().decode("utf-8")
    return split_documents(canonicalize(raw))


# -- views ---------------------------------------------------------------------

_SUFFIXES = ("ingly", "edly", "ing", "ies", "ed", "es", "ly", "s")


def light_stem(word: str) -> str:
    """A small, deterministic suffix stripper (NOT a linguistic lemmatiser).

    Strips the first matching suffix if at least 3 characters remain;
    'ies' becomes 'y'. Used only to demonstrate many-to-one views.
    """
    for suf in _SUFFIXES:
        if word.endswith(suf) and len(word) - len(suf) >= 3:
            stem = word[: -len(suf)]
            return stem + "y" if suf == "ies" else stem
    return word


VIEWS = {"casefold": str.casefold, "stem": light_stem}


def apply_views(text: str, views: list[str] | tuple[str, ...]) -> str:
    for v in views:
        text = VIEWS[v](text)
    return text


# -- gaps ------------------------------------------------------------------------

def classify_gap(gap: str) -> str | None:
    """None if the two words are adjacent; otherwise a short reason."""
    if gap.strip() == "" and not BLANK_LINE.search(gap):
        return None
    if WORD.search(gap):
        skipped = " ".join(m.group(0) for m in WORD.finditer(gap))
        return f"skips word(s): {skipped!r}"
    return f"crosses boundary {gap.strip()!r}" if gap.strip() else "crosses a blank line"


def word_spans(text: str) -> set[tuple[int, int]]:
    return {(m.start(), m.end()) for m in WORD.finditer(text)}


# -- policy ----------------------------------------------------------------------

@dataclass(frozen=True)
class PhrasePolicy:
    kind: str = "strict"
    connectors: tuple[str, ...] = ()

    def to_json(self) -> dict:
        return {"kind": self.kind, "connectors": list(self.connectors)}

    @staticmethod
    def from_json(obj: dict) -> "PhrasePolicy":
        return PhrasePolicy(obj.get("kind", ""), tuple(obj.get("connectors", ())))

    @property
    def sha256(self) -> str:
        canon = self.kind + "|" + ",".join(sorted(self.connectors))
        return sha256_text(canon)

    def is_connector(self, word_view: str) -> bool:
        return self.kind == "connectors" and word_view.casefold() in self.connectors
