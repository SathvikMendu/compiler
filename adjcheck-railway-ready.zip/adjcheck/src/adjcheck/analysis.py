"""Forward data-flow analysis of token adjacency over the stream-graph IR.

Lattice (a chain, so join = max):

    SAFE  <=  MARKED  <=  BROKEN  <=  UNTRACKED

  SAFE      no word tokens were removed; punctuation/sentence boundaries are
            recorded by `tokenize` as boundary markers.
  MARKED    word tokens were removed, and every removal left a gap marker.
  BROKEN    word tokens were removed without a gap marker: tokens that are
            now neighbours may not have been neighbours in the source.
  UNTRACKED an operation changed or split tokens without a provenance
            mapping; nothing can be said about adjacency or offsets.

Transfer functions are monotone (each maps a higher input to an equal or
higher output) and the IR is acyclic, so a single pass in topological order
(node creation order) computes the fixed point.

The analysis trusts the declared semantics of each operation. It cannot see
implementation bugs in the executor — that is PhraseProof's job.
"""
from __future__ import annotations

from enum import IntEnum

from .diagnostics import Diagnostic, Severity
from .ir import FEATURE_SINKS, PHRASE_SINKS, TOKENS, Module, Node


class State(IntEnum):
    SAFE = 0
    MARKED = 1
    BROKEN = 2
    UNTRACKED = 3


def join(*states: State) -> State:
    return max(states) if states else State.SAFE


def transfer(node: Node, inputs: list[State]) -> State | None:
    """Abstract semantics of one operation (documented in DESIGN.md)."""
    op = node.op
    s = join(*inputs) if inputs else State.SAFE
    if op == "load":
        return None                      # TEXT has no adjacency state
    if op == "tokenize":
        return State.SAFE
    if op in ("lower", "stem"):
        return s                         # 1:1 views; offsets unchanged
    if op == "remove":
        if s is State.UNTRACKED:
            return s
        if node.args.get("keep_gaps"):
            return max(s, State.MARKED)  # SAFE->MARKED, MARKED->MARKED, BROKEN->BROKEN
        return State.BROKEN
    if op == "expand_contractions":
        return State.UNTRACKED
    if op == "merge":
        return s                         # join of both inputs
    if op == "ngrams":
        return s                         # GRAMS inherit the state they were built from
    return None                          # sinks


def analyse(module: Module) -> tuple[dict[int, State], list[Diagnostic]]:
    states: dict[int, State] = {}
    diags: list[Diagnostic] = []
    consumers = module.consumers()
    for node in module.nodes:           # creation order == topological order
        ins = [states[i] for i in node.inputs if i in states]
        st = transfer(node, ins)
        if st is not None:
            states[node.id] = st
        if node.op == "ngrams" and node.args.get("max", 1) >= 2 and ins:
            diag = check_ngrams(module, node, join(*ins), consumers)
            if diag:
                diags.append(diag)
    return states, diags


def sink_severity(module: Module, node: Node, consumers) -> tuple[Severity, list[str]]:
    sinks = [module.nodes[c].op for c in consumers[node.id]]
    if any(s in PHRASE_SINKS for s in sinks):
        return Severity.ERROR, sinks
    if sinks and all(s in FEATURE_SINKS for s in sinks):
        return Severity.INFO, sinks
    return Severity.WARNING, sinks


def check_ngrams(module: Module, node: Node, state: State, consumers) -> Diagnostic | None:
    if state is State.BROKEN:
        sev, sinks = sink_severity(module, node, consumers)
        culprits = unsafe_removals(module, node)
        notes = [f"adjacency broken by {c.op}(...) at {c.loc} (removes tokens without gap markers)"
                 for c in culprits]
        if sev is Severity.ERROR:
            notes.append(f"sink(s) {', '.join(sorted(set(sinks)))} read n-grams as phrases, "
                         "so n-grams that never occur in the source would be reported")
        elif sev is Severity.INFO:
            notes.append("n-grams only feed features(...): skip-gram-like features may be "
                         "intended; reported for information")
        else:
            notes.append("n-grams are not consumed by any sink")
        return Diagnostic(
            "ADJ001", sev,
            f"ngrams({node.args['min']}, {node.args['max']}) reads a stream whose "
            "adjacency may be broken", node.loc,
            fix="use remove(..., keep_gaps) so removed positions become phrase boundaries "
                "(try `adjcheck fix`)",
            notes=notes)
    if state is State.UNTRACKED:
        notes = ["an earlier operation changes or splits tokens without an offset mapping "
                 "(e.g. expand_contractions); PhraseProof will report them as UNCERTIFIED"]
        # UNTRACKED is the lattice top, so it hides a BROKEN input; say so explicitly.
        notes += [f"adjacency may also be broken by {c.op}(...) at {c.loc} (no keep_gaps)"
                  for c in unsafe_removals(module, node)]
        return Diagnostic(
            "ADJ002", Severity.WARNING,
            f"ngrams({node.args['min']}, {node.args['max']}) reads a stream with untracked "
            "provenance; affected n-grams cannot be certified", node.loc, notes=notes)
    return None


def unsafe_removals(module: Module, node: Node) -> list[Node]:
    """Walk backwards from `node` and collect remove(...) nodes without keep_gaps."""
    found: list[Node] = []
    seen: set[int] = set()
    stack = list(node.inputs)
    while stack:
        nid = stack.pop()
        if nid in seen:
            continue
        seen.add(nid)
        n = module.nodes[nid]
        if n.op == "remove" and not n.args.get("keep_gaps"):
            found.append(n)
        if n.type == TOKENS or n.op == "load":
            stack.extend(n.inputs)
    return sorted(found, key=lambda n: n.id)


def blocks_rewrite(module: Module, node: Node) -> Node | None:
    """Return a node on the path that makes an automatic rewrite unsafe, if any."""
    seen: set[int] = set()
    stack = list(node.inputs)
    while stack:
        nid = stack.pop()
        if nid in seen:
            continue
        seen.add(nid)
        n = module.nodes[nid]
        if n.op == "expand_contractions":
            return n
        stack.extend(n.inputs)
    return None
