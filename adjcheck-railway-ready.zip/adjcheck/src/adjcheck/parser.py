"""Recursive-descent parser: one method per grammar rule (see GRAMMAR).

The parser stops at the first syntax error and reports it with the location
of the offending token (code SYN001).
"""
from __future__ import annotations

from .ast_nodes import Arg, Call, Let, Name, Pipe, PolicyStmt, Program, SinkStmt
from .diagnostics import CompileError, Diagnostic, Severity
from .lexer import T, Token, tokenize

GRAMMAR = r"""
program  = { stmt } EOF ;
stmt     = let_stmt | policy_stmt | sink_stmt ;
let_stmt = "let" IDENT "=" pipe ";" ;
policy_stmt = "policy" IDENT [ "(" [ IDENT { "," IDENT } ] ")" ] ";" ;
sink_stmt   = IDENT "(" [ args ] ")" [ "->" STRING ] ";" ;
pipe     = primary { "|" op } ;
primary  = IDENT [ "(" [ args ] ")" ] ;        (* load(...), merge(a, b) or a stream name *)
op       = IDENT [ "(" [ args ] ")" ] ;
args     = arg { "," arg } ;
arg      = IDENT "=" value | value ;
value    = INT | FLOAT | STRING | IDENT ;
"""


class Parser:
    def __init__(self, source: str):
        self.tokens = tokenize(source)
        self.pos = 0

    # -- helpers -----------------------------------------------------------
    @property
    def cur(self) -> Token:
        return self.tokens[self.pos]

    def peek(self, k: int = 1) -> Token:
        return self.tokens[min(self.pos + k, len(self.tokens) - 1)]

    def advance(self) -> Token:
        tok = self.cur
        self.pos += 1
        return tok

    def expect(self, kind: T, context: str) -> Token:
        if self.cur.kind is not kind:
            got = self.cur.text or self.cur.kind.value
            raise CompileError(Diagnostic(
                "SYN001", Severity.ERROR,
                f"expected {kind.value} {context}, found {got!r}", self.cur.loc))
        return self.advance()

    # -- rules ---------------------------------------------------------------
    def program(self) -> Program:
        prog = Program()
        while self.cur.kind is not T.EOF:
            prog.stmts.append(self.stmt())
        return prog

    def stmt(self):
        if self.cur.kind is T.LET:
            return self.let_stmt()
        if self.cur.kind is T.POLICY:
            return self.policy_stmt()
        if self.cur.kind is T.IDENT:
            return self.sink_stmt()
        got = self.cur.text or self.cur.kind.value
        raise CompileError(Diagnostic(
            "SYN001", Severity.ERROR,
            f"expected 'let', 'policy' or a sink call, found {got!r}", self.cur.loc))

    def let_stmt(self) -> Let:
        start = self.expect(T.LET, "at start of statement")
        name = self.expect(T.IDENT, "after 'let'")
        self.expect(T.EQ, f"after 'let {name.text}'")
        expr = self.pipe()
        self.expect(T.SEMI, "at end of 'let' statement")
        return Let(name.text, expr, start.loc)

    def policy_stmt(self) -> PolicyStmt:
        start = self.expect(T.POLICY, "at start of statement")
        kind = self.expect(T.IDENT, "after 'policy'")
        words: list[str] = []
        if self.cur.kind is T.LPAREN:
            self.advance()
            if self.cur.kind is not T.RPAREN:
                words.append(self.expect(T.IDENT, "in policy word list").text)
                while self.cur.kind is T.COMMA:
                    self.advance()
                    words.append(self.expect(T.IDENT, "in policy word list").text)
            self.expect(T.RPAREN, "to close policy word list")
        self.expect(T.SEMI, "at end of 'policy' statement")
        return PolicyStmt(kind.text, words, start.loc)

    def sink_stmt(self) -> SinkStmt:
        call = self.call(require_parens=True, context="sink")
        output = None
        if self.cur.kind is T.ARROW:
            self.advance()
            output = self.expect(T.STRING, "after '->'").value
        self.expect(T.SEMI, "at end of sink statement")
        return SinkStmt(call, output, call.loc)

    def pipe(self) -> Pipe:
        start = self.cur.loc
        head = self.primary()
        ops: list[Call] = []
        while self.cur.kind is T.PIPE:
            self.advance()
            ops.append(self.call(require_parens=False, context="operation"))
        return Pipe(head, ops, start)

    def primary(self) -> Call | Name:
        ident = self.expect(T.IDENT, "at start of expression")
        if self.cur.kind is T.LPAREN:
            self.pos -= 1
            return self.call(require_parens=True, context="call")
        return Name(ident.text, ident.loc)

    def call(self, require_parens: bool, context: str) -> Call:
        ident = self.expect(T.IDENT, f"as {context} name")
        call = Call(ident.text, [], ident.loc)
        if self.cur.kind is T.LPAREN:
            self.advance()
            call.has_parens = True
            if self.cur.kind is not T.RPAREN:
                call.args.append(self.arg())
                while self.cur.kind is T.COMMA:
                    self.advance()
                    call.args.append(self.arg())
            rp = self.expect(T.RPAREN, f"to close {ident.text}(...)")
            call.rparen_offset = rp.loc.offset
        elif require_parens:
            self.expect(T.LPAREN, f"after {context} name {ident.text!r}")
        return call

    def arg(self) -> Arg:
        tok = self.cur
        if tok.kind is T.IDENT and self.peek().kind is T.EQ:
            self.advance()
            self.advance()
            return Arg(tok.loc, self.value(), keyword=tok.text)
        return Arg(tok.loc, self.value())

    def value(self):
        tok = self.cur
        if tok.kind in (T.INT, T.FLOAT, T.STRING):
            self.advance()
            return tok.value
        if tok.kind is T.IDENT:
            self.advance()
            return Name(tok.text, tok.loc)
        got = tok.text or tok.kind.value
        raise CompileError(Diagnostic("SYN001", Severity.ERROR,
                                      f"expected a value, found {got!r}", tok.loc))


def parse(source: str) -> Program:
    return Parser(source).program()
